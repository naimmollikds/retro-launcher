# Daymate Assistant — Android starter app

## Updated meal tracker
- Shows every date in the selected month.
- Each date has Lunch and Dinner checkboxes.
- Check a meal when it is taken; uncheck it to revoke the entry.
- Meal count, meal cost, remaining meal count, total spending, and remaining budget recalculate automatically.
- Defaults: ৳3,500 monthly meal budget and 60 planned meals (৳58.33 per meal).
- Previous/next month navigation.
- Meal selections are saved locally on the phone.
- Add and delete extra expenses; expenses are saved locally.
- Change the monthly budget and planned meal count in Settings.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Requirements:
- JDK 17
- Android SDK 35
- Android Gradle Plugin 8.6.1
- Gradle 8.7

The Gradle wrapper properties are included and specify Gradle 8.7. If your repository has the Gradle wrapper scripts/JAR, use `./gradlew assembleDebug`. Otherwise use Android Studio's installed Gradle or install Gradle 8.7 and run `gradle assembleDebug`.

## GitHub Actions
The included workflow installs Gradle 8.7 and builds the debug APK. It uploads the APK as a workflow artifact.

## Important scope note
This version implements the offline meal checklist and expense tracker. Voice conversations, AI/API integration, WhatsApp/calling automation, Windows control, cloud sync, and autonomous background actions are not included yet.
