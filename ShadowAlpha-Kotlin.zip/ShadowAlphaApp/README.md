# Shadow Alpha (native Android / Kotlin + Jetpack Compose)

Native rebuild of the SHADOW_V200_SILENT web app. Same layout, colours, sizes, texts,
XP/SP/level rules, shop, contracts, tasbih/salah, archive, and Gemini prompts.

## What works offline
Everything except the Gemini calls: XP/levels/SP, hydration, quests, shop + skins,
timer + contracts, tasbih, salah, notes + attachments, logs, midnight reset,
battery/clock, spoken logs (Android TTS), voice input (phone recognizer),
3D head (built-in wireframe, no download needed).

## What needs internet (and only this)
Neural Link chat, AI task generation, 10-log summary, quest-photo / screen-time verification.
When offline the app says so in the log and keeps working.

## Setup
1. Build (GitHub Actions workflow included, or Android Studio).
2. Open the app -> gear icon -> paste your Gemini API key(s) -> Save.
   (No keys are bundled in the app.)
3. Optional: add the original fonts, see app/src/main/assets/fonts/README.txt
