package com.shadow.alpha

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.*

/**
 * Rotating red wireframe head, drawn 100% offline with a built-in mesh
 * (the web version downloaded a 3D model from the internet).
 */
private const val LAT = 22
private const val LON = 40

private class Mesh(val x: FloatArray, val y: FloatArray, val z: FloatArray)

private fun buildMesh(): Mesh {
    val n = (LAT + 1) * LON
    val xs = FloatArray(n); val ys = FloatArray(n); val zs = FloatArray(n)
    for (i in 0..LAT) {
        val th = (-PI / 2 + PI * i / LAT).toFloat()
        for (j in 0 until LON) {
            val ph = (-PI + 2 * PI * j / LON).toFloat()
            val ct = cos(th); val st = sin(th)
            var x = 0.62f * ct * sin(ph)
            var y = 0.92f * st
            var z = 0.72f * ct * cos(ph)
            // jaw / chin taper
            if (y < -0.1f) {
                val k = ((-0.1f - y) / 0.82f).coerceIn(0f, 1f)
                x *= (1f - 0.38f * k); z *= (1f - 0.18f * k)
            }
            if (z > 0f) {
                // nose
                val dn = exp(-((x / 0.11f).pow(2) + ((y + 0.04f) / 0.22f).pow(2)))
                z += 0.24f * dn
                // eye sockets
                for (sx in floatArrayOf(-0.27f, 0.27f)) {
                    val de = exp(-(((x - sx) / 0.13f).pow(2) + ((y - 0.20f) / 0.08f).pow(2)))
                    z -= 0.07f * de
                }
                // brow ridge
                z += 0.05f * exp(-((y - 0.32f) / 0.06f).pow(2))
                // lips
                z += 0.05f * exp(-(((x) / 0.22f).pow(2) + ((y + 0.34f) / 0.05f).pow(2)))
            }
            val idx = i * LON + j
            xs[idx] = x; ys[idx] = y; zs[idx] = z
        }
    }
    return Mesh(xs, ys, zs)
}

@Composable
fun Head3D(skin: String, modifier: Modifier = Modifier) {
    val mesh = remember { buildMesh() }
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { t ->
                if (last != 0L) angle += 0.003f * ((t - last) / 16_666_667f)
                last = t
            }
        }
    }
    val base = when (skin) {
        "gold" -> Color(0xFFFFD700)
        "diamond" -> Color(0xFF00FFFF)
        "platinum" -> Color(0xFFE5E4E2)
        else -> Color(0xFFFF0000)
    }
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val cx = w / 2f; val cy = h / 2f
        val camZ = 4.5f
        val f = (h / 2f) / tan(Math.toRadians(20.0)).toFloat()
        val scale = 1.45f
        val ca = cos(angle); val sa = sin(angle)
        val px = FloatArray(mesh.x.size); val py = FloatArray(mesh.x.size); val pz = FloatArray(mesh.x.size)
        for (k in mesh.x.indices) {
            val x = mesh.x[k] * scale; val y = mesh.y[k] * scale - 0.05f; val z = mesh.z[k] * scale
            val xr = x * ca + z * sa
            val zr = -x * sa + z * ca
            val d = camZ - zr
            px[k] = cx + xr * f / d
            py[k] = cy - y * f / d
            pz[k] = zr
        }
        val stroke = Stroke(width = 1.1f * density)
        fun seg(a: Int, b: Int) {
            val front = (pz[a] + pz[b]) / 2f > 0f
            drawLine(base.copy(alpha = if (front) 0.85f else 0.22f), Offset(px[a], py[a]), Offset(px[b], py[b]), stroke.width)
        }
        for (i in 0..LAT) for (j in 0 until LON) {
            val a = i * LON + j
            seg(a, i * LON + (j + 1) % LON)          // ring
            if (i < LAT) seg(a, (i + 1) * LON + j)   // meridian
        }
    }
}
