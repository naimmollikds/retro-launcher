package com.shadow.alpha

import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class Actions(
    val pickAttach: () -> Unit,
    val pickStInit: () -> Unit,
    val pickStProof: () -> Unit,
    val pickTaskProof: () -> Unit,
    val pickContext: () -> Unit,
    val startVoice: () -> Unit,
    val startGhostVoice: () -> Unit,
    val openFile: (AttachedFile) -> Unit
)

// ======================= HEADER =======================
@Composable
fun Header(vm: ShadowVM) {
    val s = vm.s
    Box(
        Modifier.fillMaxWidth().height(320.dp).background(Color.Black)
            .drawBehind { drawLine(C.Line, Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 2.dp.toPx()) }
    ) {
        Head3D(s.activeSkin, Modifier.padding(top = 50.dp).fillMaxWidth().height(180.dp))

        // ---- title row ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column {
                T("SHADOW_ALPHA", 14f, title = true, spacing = 2f)
                SignalLine()
                T("LEVEL_${s.lvl}", 8f, bold = true, alpha = 0.4f, modifier = Modifier.padding(top = 8.dp))
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Ico(Icons.Filled.PhoneAndroid, 12f, C.Amber500, Modifier.tap { vm.openScreenTimeProof() }, 0.7f)
                    Ico(Icons.Filled.HelpOutline, 12f, C.Cyan400, Modifier.tap { vm.guideOpen = !vm.guideOpen }, 0.7f)
                    Ico(Icons.Filled.Settings, 12f, C.Red500, Modifier.tap { vm.toggleSettings() }, 0.7f)
                    T(vm.clock, 9f, bold = true, alpha = 0.5f)
                }
                T("PWR: ${if (vm.battery >= 0) "${vm.battery}%" else "--%"}", 9f, C.Red600, bold = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ico(if (vm.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryStd, 8f, Color.White)
                    Spacer(Modifier.width(3.dp))
                    T(if (vm.charging) "CHARGING" else "DISCHARGING", 7f, bold = true)
                }
            }
        }

        // ---- XP / SP / HYD ----
        Column(Modifier.align(Alignment.TopEnd).padding(top = 65.dp, end = 15.dp).width(110.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val sp = vm.calculateSP()
            StatBar("XP", "${Math.floor(s.xp).toInt()}/${xpLimit(s.lvl)}", (s.xp / xpLimit(s.lvl)).toFloat(), C.Gold)
            StatBar("SP", "${String.format(Locale.US, "%.1f", sp)}/${spLimit(s.lvl)}", (sp / spLimit(s.lvl)).toFloat(), C.ShadowBlue)
            StatBar("HYD", "${s.water}/4000 ML", s.water / HYD_LIMIT.toFloat(), Color(0xFF00F2FF))
        }

        // ---- chrono ----
        Row(
            Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 20.dp, bottom = 35.dp)
                .fillMaxWidth().height(45.dp).background(Color(0xFF050505)).border(1.dp, C.Line)
                .padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.width(85.dp).fillMaxHeight()) {
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    T("%02d:%02d".format(vm.timerSeconds / 60, vm.timerSeconds % 60), 18f, C.Blood, title = true, spacing = 1f)
                }
                Box(Modifier.width(1.dp).fillMaxHeight().background(C.Line))
            }
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.width(45.dp).height(28.dp).background(Color.Black).border(1.dp, Color(0xFF333333)), contentAlignment = Alignment.Center) {
                    Field(vm.tInput, { v -> vm.tInput = v.filter { it.isDigit() } }, "MINS", Modifier.fillMaxWidth().padding(horizontal = 2.dp), size = 10f, number = true, center = true)
                }
                Box(
                    Modifier.weight(1f).height(28.dp).background(Color.Black).border(1.dp, C.Blood).tap { vm.igniteTimer() },
                    contentAlignment = Alignment.Center
                ) {
                    T(if (vm.timerActive) "PAUSE" else if (vm.timerSeconds > 0) "RESUME" else "IGNITE", 9f, C.Blood, title = true)
                }
                Ico(Icons.Filled.Refresh, 10f, Color.White, Modifier.tap { vm.resetTimer() }, 0.3f)
            }
        }

        // ---- HP segments ----
        Row(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 20.dp, bottom = 10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0 until 10) {
                val on = i < s.hp / 10
                Box(
                    Modifier.weight(1f).height(5.dp)
                        .then(if (on) Modifier.drawBehind {
                            drawRect(Brush.radialGradient(listOf(C.Blood.copy(alpha = 0.5f), Color.Transparent), center, size.maxDimension * 1.6f))
                        } else Modifier)
                        .background(if (on) C.Blood else Color(0xFF111111))
                )
            }
        }
    }
}

@Composable
private fun SignalLine() {
    val t = rememberInfiniteTransition(label = "sweep")
    val x by t.animateFloat(-100f, 100f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "x")
    Box(
        Modifier.padding(top = 4.dp).width(100.dp).height(1.dp)
            .background(Brush.horizontalGradient(listOf(Color.Transparent, C.Blood, Color.Transparent)))
            .clip(RoundedCornerShape(0.dp))
    ) {
        Box(Modifier.offset(x = x.dp).width(50.dp).height(1.dp).background(Color.White))
    }
}

@Composable
private fun StatBar(label: String, value: String, frac: Float, color: Color) {
    Column {
        Row { T(label, 7f, bold = true, alpha = 0.8f); Spacer(Modifier.width(3.dp)); T(value, 7f, bold = true, alpha = 0.8f) }
        Spacer(Modifier.height(1.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF111111)).border(1.dp, C.Line, RoundedCornerShape(2.dp))) {
            Box(
                Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color)
            )
        }
    }
}

// ======================= NAV =======================
@Composable
fun Nav(vm: ShadowVM) {
    Row(
        Modifier.fillMaxWidth().height(70.dp).background(Color.Black)
            .drawBehind { drawLine(C.Line, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx()) }
    ) {
        val icons = listOf(ShadowIcons.Ghost, Icons.Filled.WaterDrop, Icons.Filled.GpsFixed, Icons.Filled.Bolt, ShadowIcons.Skull)
        icons.forEachIndexed { i, ic ->
            Box(Modifier.weight(1f).fillMaxHeight().tap { vm.haptic(10); vm.tab = i }, contentAlignment = Alignment.Center) {
                Ico(ic, 16f, if (vm.tab == i) C.Blood else Color(0xFF333333))
            }
        }
    }
}

// ======================= PANES =======================
@Composable
fun NeuralPane(vm: ShadowVM, a: Actions) {
    Mod {
        Tag("Neural_Link")
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(50))
                .border(1.dp, C.Z900, RoundedCornerShape(50)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Field(vm.aiQuery, { vm.aiQuery = it }, "Signal thought...", Modifier.weight(1f).padding(horizontal = 8.dp), size = 11f, onSend = { vm.askGhost() })
            val pulse = rememberInfiniteTransition(label = "ghost").animateFloat(1f, 1.3f, infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "g")
            Ico(
                ShadowIcons.Ghost, 14f, if (vm.ghostMicActive) C.Blood else Color.White,
                Modifier.padding(4.dp).scale(if (vm.ghostMicActive) pulse.value else 1f).tap { a.startGhostVoice() },
                if (vm.ghostMicActive) 1f else 0.5f
            )
            Box(Modifier.padding(end = 8.dp).tap { vm.askGhost() }) { Ico(Icons.Filled.Send, 14f, C.Red600) }
        }
        Tag("System_Logs")
        Row(Modifier.fillMaxWidth().height(160.dp)) {
            Box(Modifier.width(1.dp).fillMaxHeight().background(C.Line))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                vm.s.logs.forEach { l ->
                    Column(Modifier.fillMaxWidth().drawBehind { drawLine(Color(0xFF111111), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx()) }.padding(bottom = 2.dp)) {
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(color = C.Blood.copy(alpha = 0.7f))) { append("[${l.ts}] ") }
                                append(l.text)
                            },
                            fontSize = 9.sp, fontFamily = Fonts.body, color = Color(0xFF555555)
                        )
                    }
                }
            }
        }
    }
    Box(Modifier.fillMaxWidth().background(C.Blood).tap { vm.triggerPing() }.padding(14.dp), contentAlignment = Alignment.Center) {
        T("PING SECONDARY NODE", 11f, Color.Black, title = true)
    }
}

@Composable
fun VitalsPane(vm: ShadowVM) {
    Mod(center = true) {
        Tag("Hydration Intake")
        T("${vm.s.water}ML", 30f, weight = FontWeight.Black, modifier = Modifier.padding(bottom = 16.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (ml in listOf(250, 500)) {
                Box(Modifier.weight(1f).background(C.Z900).tap { vm.logW(ml) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    T("+${ml}ML", 10f, bold = true)
                }
            }
        }
        Box(Modifier.fillMaxWidth().border(1.dp, C.Z800).tap { vm.undoW() }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            T("UNDO LAST DRINK", 8f, C.Z500, bold = true)
        }
    }
    Mod {
        Tag("Nutrient Intake")
        Field(vm.mealInput, { vm.mealInput = it }, "Describe intake...", Modifier.fillMaxWidth().padding(bottom = 8.dp).background(Color.Black).border(1.dp, C.Z800).padding(8.dp))
        OutBtn("Commit (+50 XP)", C.Red900, C.Red600, { vm.logMeal() }, Modifier.fillMaxWidth())
    }
}

@Composable
fun QuestsPane(vm: ShadowVM) {
    Mod {
        Tag("Daily Objectives")
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(vm.taskInput, { vm.taskInput = it }, "Target objective...", Modifier.weight(1f).background(Color.Black).border(1.dp, C.Z800).padding(8.dp))
            Field(vm.taskXpInput, { vm.taskXpInput = it.filter { c -> c.isDigit() } }, "XP", Modifier.width(64.dp).background(Color.Black).border(1.dp, C.Z800).padding(8.dp), color = C.Yellow500, number = true, center = true, bold = true)
        }
        OutBtn("Deploy Custom Task", C.Red900, C.Red600, { vm.addTask() }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutBtn("Deploy Dynamic AI Tasks (Gemini)", C.Cyan900, C.Cyan500, { vm.generateAITasks() }, Modifier.fillMaxWidth(), icon = Icons.Filled.AutoFixHigh)
    }
    Column(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        vm.s.tasks.forEachIndexed { i, t ->
            Row(
                Modifier.fillMaxWidth().background(C.Panel).border(1.dp, C.Line).padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(color = C.Red500, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)) { append("#${i + 1} ") }
                                append(t.text.uppercase())
                            },
                            fontSize = 10.sp, fontFamily = Fonts.body, fontWeight = FontWeight.Bold, color = Color.White,
                            modifier = Modifier.alpha(if (t.done) 0.3f else 1f),
                            textDecoration = if (t.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                        )
                        if (t.requiresProof) {
                            Ico(Icons.Filled.PhotoCamera, 10f, C.Cyan400, Modifier.padding(start = 6.dp))
                            Ico(Icons.Filled.Info, 10f, C.Cyan400, Modifier.padding(start = 4.dp).tap { vm.taskInfoIdx = i })
                        }
                    }
                    Row(Modifier.padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ico(Icons.Filled.Bolt, 8f, C.Yellow500); Spacer(Modifier.width(3.dp))
                        T("+${t.xp} XP", 8f, C.Yellow500, bold = true)
                    }
                }
                Box(Modifier.padding(horizontal = 8.dp).tap { vm.completeTask(i) }) {
                    Ico(if (t.done) Icons.Filled.Refresh else Icons.Filled.Check, 14f, C.Red600, alpha = if (t.done) 0.2f else 1f)
                }
            }
        }
    }
}

@Composable
private fun ShopRow(name: String, nameColor: Color, info: String, infoColor: Color? = null, first: Boolean = false, bg: Color = Color.Transparent, right: @Composable () -> Unit, tagId: String = "") {
    Row(
        Modifier.fillMaxWidth().background(bg)
            .drawBehind {
                if (!first) drawLine(C.Z900, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx())
                drawLine(Color(0xFF111111), Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
            }.padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T(name, 10f, nameColor, bold = true)
            T(info, 8f, infoColor ?: Color.White, alpha = 0.3f)
        }
        right()
    }
}

@Composable
private fun BuyBtn(text: String, border: Color, color: Color, onClick: () -> Unit) {
    Box(Modifier.border(1.dp, border).tap(onClick).padding(horizontal = 8.dp, vertical = 4.dp)) { T(text.uppercase(), 8f, color, title = true) }
}

@Composable
fun BoltPane(vm: ShadowVM) {
    val s = vm.s
    Mod {
        Tag("Active_Contracts", icon = Icons.Filled.Link)
        T(
            if (s.activeContract != null) "BOND ACTIVE: ${s.activeContract.type.uppercase()} | ${s.activeContract.cost} SP STAKED | REWARD ${s.activeContract.reward} XP ON TIMER COMPLETE"
            else "No active bonds. Risk SP to gain XP.",
            9f, alpha = 0.5f, italic = true
        )
    }
    Mod {
        Tag("Black_Market", color = C.Red500, icon = Icons.Filled.ShoppingCart)
        Column(Modifier.padding(top = 8.dp)) {
            val skins = listOf(Triple("gold", "Gold Skin" to C.Yellow500, Triple(50, 2, "")), Triple("diamond", "Diamond Skin" to C.Cyan400, Triple(100, 3, "")), Triple("platinum", "Platinum Skin" to C.Z300, Triple(200, 4, "")))
            skins.forEachIndexed { idx, (id, nameCol, cm) ->
                val (cost, mult, _) = cm
                val active = s.activeSkin == id
                val info = if (active) {
                    val rem = maxOf(0L, s.skinExpiry - vm.nowMs)
                    if (rem > 0) "XP x${s.xpMult} | ${rem / 60000}m ${(rem % 60000) / 1000}s / 30m" else "XP x$mult | 30 MINS"
                } else "XP x$mult | 30 MINS"
                ShopRow(nameCol.first, nameCol.second, info, if (active && s.skinExpiry - vm.nowMs > 0) C.Blood else null, first = idx == 0, right = {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("$cost SP", 10f, C.ShadowBlue, bold = true)
                        BuyBtn("Apply", C.Blood, C.Blood) { vm.buySkin(id, cost, mult) }
                    }
                })
            }
            ShopRow("Focus Contract", C.Amber500, "BOND 50 SP | REWARD 100 XP", bg = C.Z950, right = { BuyBtn("STAKE", C.Amber600, C.Amber600) { vm.initStake("Focus", 50, 100) } })
            ShopRow("Physical Contract", C.Blue500, "BOND 50 SP | REWARD 100 XP", bg = C.Z950, right = { BuyBtn("STAKE", C.Blue600, C.Blue600) { vm.initStake("Physical", 50, 100) } })
        }
    }
}

@Composable
fun CharPane(vm: ShadowVM, a: Actions) {
    val s = vm.s
    Column(Modifier.fillMaxWidth().padding(bottom = 15.dp).background(Color(0xFF050505)).border(1.dp, Color(0xFF1A1A1A)).padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Tag("Tasbih_Protocol")
        T("${s.tasbih}", 32f, C.Gold, title = true, modifier = Modifier.padding(bottom = 5.dp))
        val src = remember { MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val sc by animateFloatAsState(if (pressed) 0.9f else 1f, tween(100), label = "tb")
        Box(
            Modifier.padding(bottom = 10.dp).size(80.dp).scale(sc).clip(CircleShape)
                .background(if (pressed) C.Gold.copy(alpha = 0.1f) else Color.Transparent, CircleShape)
                .border(2.dp, C.Gold, CircleShape)
                .clickable(interactionSource = src, indication = null) { vm.incTasbih() },
            contentAlignment = Alignment.Center
        ) { Ico(Icons.Filled.Fingerprint, 24f, C.Gold) }
        Ico(Icons.Filled.Replay, 12f, Color.White, Modifier.tap { vm.resetTasbih() }, 0.3f)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha").forEachIndexed { i, n ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    T(n.uppercase(), 7f, Color(0xFF555555), bold = true)
                    val on = s.salah.getOrElse(i) { false }
                    Box(
                        Modifier.size(20.dp).background(if (on) C.Blood else Color.Black).border(1.dp, if (on) C.Blood else Color(0xFF333333))
                            .tap { vm.markSalah(i, !on) },
                        contentAlignment = Alignment.Center
                    ) { if (on) Ico(Icons.Filled.Check, 10f, Color.Black) }
                }
            }
        }
    }

    Mod {
        Tag("Neural_Archive")
        Field(vm.noteInput, { vm.noteInput = it }, "Record entry...", Modifier.fillMaxWidth().height(96.dp).padding(bottom = 4.dp).background(Color.Black).border(1.dp, C.Z900).padding(8.dp), size = 12f, singleLine = false)
        vm.pendingFile?.let { f ->
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp).background(C.Z950).border(1.dp, C.Z800).padding(4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                T("ATTACHED: ${f.name.uppercase()}", 8f, C.Cyan400, maxLines = 1, modifier = Modifier.weight(1f))
                Ico(Icons.Filled.Close, 8f, C.Red500, Modifier.tap { vm.clearAttachedFile() })
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 0.5f, infiniteRepeatable(tween(750), RepeatMode.Reverse), label = "pp")
            CtrlBtn(Icons.Filled.Mic, vm.micActive, pulse, Modifier.weight(1f)) { a.startVoice() }
            CtrlBtn(Icons.Filled.AttachFile, vm.pendingFile != null, pulse, Modifier.weight(1f)) { a.pickAttach() }
            Box(Modifier.weight(4f).height(35.dp).background(Color.Black).border(1.dp, Color(0xFF0044FF)).tap { vm.archiveNote() }, contentAlignment = Alignment.Center) {
                T("ARCHIVE DATA", 9f, Color(0xFF0044FF), title = true)
            }
        }
        Column(Modifier.padding(top = 16.dp)) {
            s.noteArchive.forEach { n -> NoteEntry(n, vm, a) }
        }
    }
    Box(Modifier.fillMaxWidth().background(Color(0xFF1A0000)).border(1.dp, C.Blood).tap { vm.purgeCode = ""; vm.purgeOpen = true }.padding(15.dp), contentAlignment = Alignment.Center) {
        T("WIPE SYSTEM DATA", 10f, C.Blood, title = true)
    }
}

@Composable
private fun CtrlBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, pulse: Float, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(35.dp).background(Color(0xFF111111)).border(1.dp, if (active) C.Blood else C.Line).tap(onClick),
        contentAlignment = Alignment.Center
    ) { Ico(icon, 12f, if (active) C.Blood else Color(0xFF444444), alpha = if (active) pulse else 1f) }
}

@Composable
private fun NoteEntry(n: Note, vm: ShadowVM, a: Actions) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).height(IntrinsicSize.Min).background(Color(0xFF050505))) {
        Box(Modifier.width(2.dp).fillMaxHeight().background(C.Blood))
        Row(Modifier.weight(1f).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                T(n.date, 7f, alpha = 0.3f)
                T(n.text, 10f)
                n.file?.let { f ->
                    val mime = f.type
                    if (mime.startsWith("image/")) {
                        val bmp = remember(f.path) {
                            try {
                                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                                BitmapFactory.decodeFile(f.path, o)?.asImageBitmap()
                            } catch (_: Throwable) { null }
                        }
                        if (bmp != null) Image(bmp, null, Modifier.padding(top = 8.dp).fillMaxWidth().heightIn(max = 192.dp).clip(RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
                    } else {
                        Row(Modifier.padding(top = 8.dp).fillMaxWidth().border(1.dp, C.Z800).padding(4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Ico(if (mime.startsWith("audio/")) Icons.Filled.Mic else Icons.Filled.InsertDriveFile, 8f, C.Cyan400)
                                Spacer(Modifier.width(4.dp))
                                T(f.name, 8f, C.Cyan400, maxLines = 1)
                            }
                            T(if (mime.startsWith("audio/") || mime.startsWith("video/")) "PLAY" else "OPEN", 8f, C.Red500, modifier = Modifier.padding(start = 8.dp).tap { a.openFile(f) })
                        }
                    }
                }
            }
            Ico(Icons.Filled.Delete, 10f, Color(0xFF333333), Modifier.tap { vm.deleteNote(n.id) })
        }
    }
}
