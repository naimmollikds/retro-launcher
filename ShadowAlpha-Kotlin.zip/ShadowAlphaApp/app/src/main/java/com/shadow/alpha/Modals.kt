package com.shadow.alpha

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import java.util.Locale

@Composable
fun Modals(vm: ShadowVM, a: Actions) {
    if (vm.stInitOpen) StInitModal(vm, a)
    if (vm.stProofOpen) StProofModal(vm, a)
    if (vm.taskProofIdx != null) TaskProofModal(vm, a)
    if (vm.taskInfoIdx != null) TaskInfoModal(vm)
    if (vm.purgeOpen) PurgeModal(vm)
    if (vm.settingsOpen) SettingsModal(vm, a)
    if (vm.guideOpen) GuideModal(vm)
}

@Composable
private fun FullBtn(text: String, bg: Color, border: Color, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier, bold: Boolean = true) {
    Box(modifier.background(bg).border(1.dp, border).tap(onClick).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        T(text.uppercase(), 9f, color, bold = bold)
    }
}

@Composable
private fun StInitModal(vm: ShadowVM, a: Actions) = ModalBox(C.Amber600) {
    Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Ico(Icons.Filled.PhoneAndroid, 14f, C.Amber500); Spacer(Modifier.width(4.dp))
        T("SCREEN TIME INITIALIZATION", 14f, C.Amber500, title = true)
    }
    Text(
        buildAnnotatedString {
            append("Upload a screenshot showing phone app usage, digital wellbeing, or device activity covering ")
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("at least 5 days") }
            append(" to initialize monitoring.")
        }, fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp)
    )
    FilePickRow(vm.stInitName) { a.pickStInit() }
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.Z900)); Spacer(Modifier.height(8.dp))
        T("OPTIONAL API KEY (INSTANT SETUP):", 8f, C.Cyan400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
        Field(vm.stInitKey, { vm.stInitKey = it }, "Paste Gemini API Key (or leave blank to use stored)...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(6.dp), size = 9f, password = true)
    }
    FullBtn("Verify History & Initialize", C.Amber600, C.Amber400, Color.Black, { vm.verifyInitialScreenTime() }, Modifier.fillMaxWidth())
}

@Composable
private fun StProofModal(vm: ShadowVM, a: Actions) = ModalBox(C.Amber600) {
    ModalHeader("Daily Screen Time Proof", C.Amber500, Icons.Filled.Image, { vm.stProofOpen = false })
    val hrs = if (vm.s.targetMaxScreenTimeHours != 0.0) vm.s.targetMaxScreenTimeHours.toString()
        else if (vm.s.targetMaxScreenTimeMinutes != 0) String.format(Locale.US, "%.1f", vm.s.targetMaxScreenTimeMinutes / 60.0) else "4.0"
    val mins = if (vm.s.targetMaxScreenTimeMinutes != 0) vm.s.targetMaxScreenTimeMinutes else Math.round(hrs.toDouble() * 60).toInt()
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Amber900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("ASSIGNED DAILY LIMIT:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T("$hrs Hours ($mins Mins)", 12f, C.Amber500, bold = true)
    }
    Text("Submit today's usage/screen time screenshot to prove you stayed within your limit.", fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
    FilePickRow(vm.stProofName) { a.pickStProof() }
    FullBtn("Submit Proof For Verification", C.Amber600, C.Amber400, Color.Black, { vm.submitScreenTimeProof() }, Modifier.fillMaxWidth())
}

@Composable
private fun TaskProofModal(vm: ShadowVM, a: Actions) = ModalBox(C.Cyan600) {
    val idx = vm.taskProofIdx ?: return@ModalBox
    val task = vm.s.tasks.getOrNull(idx)
    ModalHeader("Quest Proof Required", C.Cyan400, Icons.Filled.PhotoCamera, { vm.closeTaskProof() })
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Cyan900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("TARGET QUEST:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T(if (task != null) "#${idx + 1}: ${task.text}" else "--", 12f, C.Cyan400, bold = true)
    }
    if (task != null && task.proofInstruction.isNotBlank()) {
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(C.Z900, RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)).padding(8.dp)) {
            Row(Modifier.padding(bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Ico(Icons.Filled.Info, 8f, C.Yellow500); Spacer(Modifier.width(4.dp))
                T("REQUIRED PROOF:", 8f, C.Yellow500, bold = true)
            }
            T(task.proofInstruction, 9f, C.Z300)
        }
    }
    Text("Upload image evidence proving you completed this quest. The Neural System will verify its authenticity before awarding XP.", fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
    FilePickRow(vm.taskProofName) { a.pickTaskProof() }
    FullBtn("Verify Image & Complete Quest", C.Cyan600, C.Cyan400, Color.Black, { vm.submitTaskProof() }, Modifier.fillMaxWidth())
}

@Composable
private fun TaskInfoModal(vm: ShadowVM) = ModalBox(C.Cyan500) {
    val idx = vm.taskInfoIdx ?: return@ModalBox
    val task = vm.s.tasks.getOrNull(idx)
    ModalHeader("Quest Requirements", C.Cyan400, Icons.Filled.Info, { vm.taskInfoIdx = null })
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Cyan900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("TARGET QUEST:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T(if (task != null) "#${idx + 1}: ${task.text}" else "--", 12f, C.Cyan400, bold = true)
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(C.Z900, RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)).padding(12.dp)) {
        Row(Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico(Icons.Filled.Checklist, 8f, C.Yellow500); Spacer(Modifier.width(4.dp))
            T("CAPTURE INSTRUCTIONS:", 8f, C.Yellow500, bold = true)
        }
        Text(
            task?.proofInstruction?.ifBlank { null } ?: "Capture clear image evidence proving completion of this task.",
            fontSize = 10.sp, color = C.Z200, fontFamily = Fonts.body, lineHeight = 16.sp
        )
    }
    FullBtn("Acknowledge", C.Cyan950, C.Cyan600, C.Cyan300, { vm.taskInfoIdx = null }, Modifier.fillMaxWidth())
}

@Composable
private fun PurgeModal(vm: ShadowVM) = ModalBox(C.Red600) {
    ModalHeader("System Purge", C.Red500, Icons.Filled.Warning, { vm.purgeOpen = false })
    Text("Enter authorization key to initiate a complete system wipe.", fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
    Field(vm.purgeCode, { vm.purgeCode = it }, "PURGE CODE...", Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black).border(1.dp, C.Red900).padding(8.dp), password = true)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FullBtn("EXECUTE PURGE", C.Red900, C.Red600, Color.White, { vm.confirmPurge() }, Modifier.weight(1f))
        Box(Modifier.background(C.Z900).border(1.dp, C.Z800).tap { vm.purgeOpen = false }.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            T("CANCEL", 9f, C.Z400)
        }
    }
}

@Composable
private fun SettingsModal(vm: ShadowVM, a: Actions) = ModalBox(C.Red900) {
    ModalHeader("System_Settings", C.Red500, null, { vm.toggleSettings() }, bottom = 16f)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column {
            T("GEMINI API KEY 1 (TASK AI & CHAT)", 9f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fKey1, { vm.fKey1 = it }, "Enter Primary Task API Key...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp), password = true)
        }
        Column {
            T("GEMINI API KEY 2 (LOG SUMMARIZER - 10 LOG CYCLE)", 9f, C.Cyan400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fKey2, { vm.fKey2 = it }, "Enter Second Summarizer API Key...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp), password = true)
        }
        Column {
            T("SYSTEM CONTEXT & LORE PROMPT", 9f, C.Red500, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fPrompt, { vm.fPrompt = it }, "Describe who you are, your goals, current scenario, habits, or drama series system rules...", Modifier.fillMaxWidth().height(96.dp).background(Color.Black).border(1.dp, C.Z800).padding(8.dp), singleLine = false)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.background(C.Z900).border(1.dp, C.Z700).tap { a.pickContext() }.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ico(Icons.Filled.FileUpload, 9f, C.Z300); Spacer(Modifier.width(4.dp))
                    T("LOAD FILE (.TXT, .MD)", 8f, C.Z300, bold = true)
                }
                T(vm.fPromptStatus, 7f, C.Cyan400)
            }
        }
        Column(Modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Z900, RoundedCornerShape(4.dp)).padding(8.dp)) {
            Row(Modifier.fillMaxWidth().tap { vm.summaryExpanded = !vm.summaryExpanded }, horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ico(Icons.Filled.Description, 9f, Color.White); Spacer(Modifier.width(4.dp))
                    T("TEMPORARY HIDDEN LOG SUMMARY", 9f, Color.White, bold = true)
                }
                Ico(if (vm.summaryExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, 10f, C.Z500)
            }
            if (vm.summaryExpanded) {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(C.Z900))
                    T("Auto-updated every 10 system logs via 2nd API. Resets at midnight.", 7f, Color(0xFF52525B), italic = true)
                    Box(Modifier.fillMaxWidth().heightIn(max = 128.dp).background(C.Z950, RoundedCornerShape(4.dp)).border(1.dp, C.Z900, RoundedCornerShape(4.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
                        T(vm.s.logSummary.ifBlank { "No daily log summary recorded yet." }, 8f, C.Z400)
                    }
                }
            }
        }
    }
    Row(Modifier.padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FullBtn("Save System Settings", C.Red900, C.Red600, Color.White, { vm.saveSettings() }, Modifier.weight(1f))
        Box(Modifier.background(C.Z900).border(1.dp, C.Z800).tap { vm.toggleSettings() }.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            T("CANCEL", 9f, C.Z400)
        }
    }
}

@Composable
private fun GuideModal(vm: ShadowVM) = ModalBox(C.Cyan800) {
    ModalHeader("System_User_Guide", C.Cyan400, Icons.Filled.MenuBook, { vm.guideOpen = false })
    @Composable fun sec(h: String, col: Color, body: androidx.compose.ui.text.AnnotatedString) {
        Column(Modifier.padding(bottom = 12.dp)) {
            T(h, 11f, col, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Text(body, fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp)
        }
    }
    fun plain(t: String) = buildAnnotatedString { append(t) }
    fun withBold(pre: String, b: String, post: String) = buildAnnotatedString { append(pre); withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(b) }; append(post) }

    sec("1. System Level & Stats (XP & SP)", C.Red500, plain("Gain XP by logging hydration, food, daily objectives, and prayer rituals. SP (Stat Points) is generated as you gain total XP and can be spent on Black Market items or Staking Contracts."))
    sec("2. AI Neural Link & Custom Lore", C.Cyan400, withBold("Configure your personal scenario and Gemini API Keys in ", "Settings (Gear Icon)", ". The AI will speak like an authoritative drama system and issue realistic, tailored tasks based on your background prompt."))
    sec("3. Dynamic AI Quest Valuation", C.Z300, plain("The AI automatically assigns relative XP values based on task difficulty (+10 to +20 for quick items, +25 to +40 for medium focus, +50 to +75 for intense drills). Completing a task awards its specific XP value."))
    sec("4. 10-Log Automated AI Summarizer", C.Emerald400, withBold("Every 10 system logs, the ", "2nd API Key", " creates a hidden daily summary. This summary is injected into your prompt file so the AI knows what you did during the day. Both raw logs and this summary reset automatically at midnight!"))
    sec("5. Flexible Screen Time Verification", C.Purple400, plain("Upload screenshots of any Digital Wellbeing, device activity, or app usage stats (at least 5 days). If rejected, the system will explicitly tell you why!"))
    Spacer(Modifier.height(4.dp))
    FullBtn("Acknowledge & Exit", C.Cyan950, C.Cyan700, C.Cyan300, { vm.guideOpen = false }, Modifier.fillMaxWidth())
}
