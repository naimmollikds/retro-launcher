package com.shadow.alpha

import android.app.Application
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val HYD_LIMIT = 4000
const val AUTH_KEY = "1420"
fun xpLimit(lvl: Int) = lvl * 500
fun spLimit(lvl: Int) = lvl * 50

class ShadowVM(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val store = Store(ctx)

    var s by mutableStateOf(store.load())
        private set

    // ---- live UI state (not persisted) ----
    var clock by mutableStateOf("--:--:--")
    var battery by mutableStateOf(-1)
    var charging by mutableStateOf(false)
    var nowMs by mutableStateOf(System.currentTimeMillis())
    var tab by mutableStateOf(0)

    var timerSeconds by mutableStateOf(0)
    var timerActive by mutableStateOf(false)
    private var timerEnd = 0L
    var tInput by mutableStateOf("")

    var aiQuery by mutableStateOf("")
    var mealInput by mutableStateOf("")
    var taskInput by mutableStateOf("")
    var taskXpInput by mutableStateOf("20")
    var noteInput by mutableStateOf("")
    var pendingFile by mutableStateOf<AttachedFile?>(null)

    var micActive by mutableStateOf(false)
    var ghostMicActive by mutableStateOf(false)

    var settingsOpen by mutableStateOf(false)
    var guideOpen by mutableStateOf(false)
    var stInitOpen by mutableStateOf(false)
    var stProofOpen by mutableStateOf(false)
    var taskProofIdx by mutableStateOf<Int?>(null)
    var taskInfoIdx by mutableStateOf<Int?>(null)
    var purgeOpen by mutableStateOf(false)

    var stInitUri by mutableStateOf<Uri?>(null)
    var stInitName by mutableStateOf("")
    var stProofUri by mutableStateOf<Uri?>(null)
    var stProofName by mutableStateOf("")
    var taskProofUri by mutableStateOf<Uri?>(null)
    var taskProofName by mutableStateOf("")

    // settings form fields
    var fKey1 by mutableStateOf("")
    var fKey2 by mutableStateOf("")
    var fPrompt by mutableStateOf("")
    var fPromptStatus by mutableStateOf("")
    var summaryExpanded by mutableStateOf(false)
    var stInitKey by mutableStateOf("")
    var purgeCode by mutableStateOf("")

    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setPitch(0.6f); tts?.setSpeechRate(1.1f)
            }
        }
        if (s.lastReset.isBlank()) s = s.copy(lastReset = today())
        if (s.targetMaxScreenTimeHours != 0.0 && s.targetMaxScreenTimeMinutes == 0)
            s = s.copy(targetMaxScreenTimeMinutes = Math.round(s.targetMaxScreenTimeHours * 60).toInt())
        else if (s.targetMaxScreenTimeMinutes != 0 && s.targetMaxScreenTimeHours == 0.0)
            s = s.copy(targetMaxScreenTimeHours = Math.round(s.targetMaxScreenTimeMinutes / 6.0) / 10.0)
        checkDailyReset()
        if (!s.screenTimeInitialized) stInitOpen = true
        save()
        pushLog("SYSTEM ONLINE. NEURAL LINK ESTABLISHED.", true)
        startTicker()
    }

    override fun onCleared() { tts?.shutdown(); super.onCleared() }

    // ---------- helpers ----------
    private fun today() = LocalDate.now().toString()
    private fun save() = store.save(s)
    private fun upd(f: (AppState) -> AppState) { s = f(s); save() }

    fun calculateSP() = s.totalXP / 10 - s.spentSP

    fun online(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun speak(text: String) {
        try {
            val t = text.replace(Regex("ML", RegexOption.IGNORE_CASE), "milliliters").replace("_", " ")
            tts?.setPitch(0.6f); tts?.setSpeechRate(1.1f)
            tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "shadow")
        } catch (_: Exception) { }
    }

    fun haptic(ms: Long = 30) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java) ?: return
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
    }

    private fun hapticPattern(p: LongArray) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java) ?: return
            v.vibrate(VibrationEffect.createWaveform(p, -1))
        } catch (_: Exception) { }
    }

    private fun beep() {
        Thread {
            try {
                val sr = 22050
                val n = sr * 50 / 1000
                val buf = ShortArray(n) { (sin(2 * PI * 880 * it / sr) * Short.MAX_VALUE * 0.02).toInt().toShort() }
                val t = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                t.write(buf, 0, n); t.play(); Thread.sleep(90); t.release()
            } catch (_: Exception) { }
        }.start()
    }

    // ---------- logs ----------
    fun pushLog(msg: String, silent: Boolean = false) {
        val ts = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
        var counter = s.logCounter + 1
        val trigger = counter >= 10
        if (trigger) counter = 0
        upd { it.copy(logs = (listOf(LogEntry(ts, msg)) + it.logs).take(25), logCounter = counter) }
        if (!silent) speak(msg)
        if (trigger) summarizeLogs()
    }

    // ---------- XP / SP ----------
    fun gainXP(amt: Double) {
        val gain = amt * s.xpMult
        var xp = s.xp + gain
        val total = s.totalXP + gain
        var lvl = s.lvl
        var ascended = 0
        while (xp >= xpLimit(lvl)) {
            if (total / 10 >= spLimit(lvl)) { lvl++; ascended = lvl } else break
        }
        upd { it.copy(xp = xp, totalXP = total, lvl = lvl) }
        if (ascended > 0) { hapticPattern(longArrayOf(0, 50, 30, 50)); pushLog("ASCENDED TO LEVEL $ascended") }
    }

    fun deductXP(amt: Double) {
        val d = amt * s.xpMult
        upd { it.copy(xp = max(0.0, it.xp - d), totalXP = max(0.0, it.totalXP - d)) }
    }

    // ---------- skins / contracts ----------
    fun buySkin(type: String, cost: Int, mult: Int) {
        if (calculateSP() >= cost) {
            upd { it.copy(spentSP = it.spentSP + cost, activeSkin = type, xpMult = mult,
                skinExpiry = System.currentTimeMillis() + 30 * 60 * 1000) }
            pushLog("${type.uppercase()} SKIN APPLIED: ${mult}X XP GAIN")
        } else pushLog("INSUFFICIENT SP")
    }

    fun initStake(type: String, cost: Int, reward: Int) {
        if (timerSeconds <= 0) { pushLog("TIMER NOT SET"); return }
        if (calculateSP() >= cost) {
            upd { it.copy(spentSP = it.spentSP + cost, activeContract = Contract(type, cost, reward)) }
            pushLog("BOND COMMITTED: $type AT $cost SP")
        } else pushLog("INSUFFICIENT SP FOR BOND")
    }

    private fun secureContract() {
        val c = s.activeContract ?: return
        upd { it.copy(spentSP = it.spentSP - c.cost) }
        gainXP(c.reward.toDouble())
        pushLog("BOND SECURED: +${c.reward} XP RECEIVED")
        upd { it.copy(activeContract = null) }
    }

    // ---------- timer ----------
    fun igniteTimer() {
        if (timerActive) { timerActive = false; pushLog("CHRONO CYCLE PAUSED"); return }
        if (timerSeconds <= 0) {
            val mins = tInput.toIntOrNull() ?: 0
            if (mins <= 0) return
            timerSeconds = mins * 60; tInput = ""
            pushLog("CHRONO CYCLE IGNITED: $mins MINUTES")
        } else pushLog("CHRONO CYCLE RESUMED")
        timerEnd = System.currentTimeMillis() + timerSeconds * 1000L
        timerActive = true
    }

    fun resetTimer() {
        timerActive = false; timerSeconds = 0
        pushLog("CHRONO TIMER ABORTED")
    }

    // ---------- ticker (clock, timer, skin expiry, midnight, battery, retries) ----------
    private fun startTicker() {
        viewModelScope.launch {
            var n = 0
            while (true) {
                val now = System.currentTimeMillis()
                nowMs = now
                clock = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(now))
                if (timerActive) {
                    val rem = ceil((timerEnd - now) / 1000.0).toInt()
                    if (rem <= 0) {
                        timerSeconds = 0; timerActive = false
                        hapticPattern(longArrayOf(0, 100, 50, 100))
                        if (s.activeContract != null) secureContract()
                        pushLog("CHRONO CYCLE COMPLETE")
                    } else timerSeconds = rem
                }
                if (n % 2 == 0) {
                    checkDailyReset()
                    if (s.activeSkin != "default" && now > s.skinExpiry) {
                        upd { it.copy(activeSkin = "default", xpMult = 1) }
                        pushLog("SKIN EXPIRED: REVERTING MATERIAL")
                    }
                    readBattery()
                }
                if (n % 120 == 0 && s.pendingSummary && online()) summarizeLogs()
                n++
                delay(500)
            }
        }
    }

    private fun readBattery() {
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (lvl >= 0) battery = Math.round(lvl * 100f / scale)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        } catch (_: Exception) { }
    }

    // ---------- midnight reset (works fully offline) ----------
    fun checkDailyReset() { if (s.lastReset != today()) executeMidnightPurge() }

    private fun executeMidnightPurge() {
        if (s.screenTimeInitialized && !s.screenTimeProofSubmitted) {
            deductXP(150.0)
            pushLog("PENALTY APPLIED: SCREEN TIME PROOF NOT SUBMITTED BEFORE MIDNIGHT (-150 XP)")
        }
        upd { it.copy(salah = List(5) { false }, lastReset = today(), water = 0, tasks = emptyList(),
            logs = emptyList(), logCounter = 0, logSummary = "", screenTimeProofSubmitted = false,
            pendingSummary = false) }
        pushLog("12 AM MIDNIGHT CYCLE REACHED: WATER, TASKS, LOGS & SUMMARY RESET", true)
    }

    // ---------- vitals ----------
    fun logW(ml: Int) {
        upd { it.copy(water = min(4000, it.water + ml), lastW = ml) }
        pushLog("INTAKE RECORDED: $ml ML"); gainXP(ml / 10.0); haptic(20)
    }

    fun undoW() {
        if (s.lastW > 0) {
            val l = s.lastW
            upd { it.copy(water = max(0, it.water - l), lastW = 0) }
            deductXP(l / 10.0)
            pushLog("INTAKE VOIDED: -$l ML")
        }
    }

    fun logMeal() {
        val m = mealInput.trim(); if (m.isEmpty()) return
        pushLog("NUTRIENT COMMITTED: ${m.uppercase()}"); gainXP(50.0); mealInput = ""
    }

    // ---------- tasbih / salah ----------
    fun incTasbih() { upd { it.copy(tasbih = it.tasbih + 1) }; gainXP(0.1); haptic(25); beep() }
    fun resetTasbih() { upd { it.copy(tasbih = 0) }; pushLog("TASBIH COUNTER RESET") }

    fun markSalah(idx: Int, checked: Boolean) {
        val names = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
        upd { st -> st.copy(salah = st.salah.mapIndexed { i, v -> if (i == idx) checked else v }) }
        if (checked) { gainXP(20.0); pushLog("${names[idx]} SALAH OBSERVED"); haptic(30) }
        else { deductXP(20.0); pushLog("${names[idx]} SALAH REMOVED") }
    }

    // ---------- tasks ----------
    fun addTask() {
        val t = taskInput.trim(); if (t.isEmpty()) return
        val xp = taskXpInput.toIntOrNull() ?: 20
        val low = t.lowercase()
        val isST = low.contains("screen time") || low.contains("screentime")
        upd { it.copy(tasks = listOf(Task(t.uppercase(), xp, false, isST, false, "")) + it.tasks) }
        pushLog("OBJECTIVE DEPLOYED [+$xp XP]: ${t.uppercase()}")
        taskInput = ""
    }

    private fun setTask(i: Int, f: (Task) -> Task) =
        upd { st -> st.copy(tasks = st.tasks.mapIndexed { idx, t -> if (idx == i) f(t) else t }) }

    fun completeTask(i: Int) {
        val t = s.tasks.getOrNull(i) ?: return
        if (!t.done) {
            if (t.requiresProof) { openTaskProof(i); return }
            if (t.isScreenTime && !s.screenTimeProofSubmitted) {
                pushLog("SCREEN TIME TASK REQUIRES TODAY'S SCREENSHOT PROOF!")
                openScreenTimeProof(); return
            }
            setTask(i) { it.copy(done = true) }
            gainXP(t.xp.toDouble()); pushLog("OBJECTIVE SECURED: +${t.xp} XP"); haptic(40)
        } else {
            setTask(i) { it.copy(done = false) }
            deductXP(t.xp.toDouble()); pushLog("OBJECTIVE REACTIVATED: -${t.xp} XP"); haptic(20)
        }
    }

    fun openTaskProof(i: Int) { taskProofIdx = i; taskProofUri = null; taskProofName = "" }
    fun closeTaskProof() { taskProofIdx = null }
    fun openScreenTimeProof() { stProofUri = null; stProofName = ""; stProofOpen = true }

    // ---------- notes ----------
    fun displayName(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) return c.getString(i)
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "file"
    }

    fun attachFile(uri: Uri) {
        viewModelScope.launch {
            val f = withContext(Dispatchers.IO) {
                try {
                    val name = displayName(uri)
                    val mime = ctx.contentResolver.getType(uri) ?: ""
                    val dest = File(store.mediaDir, "${System.currentTimeMillis()}_${name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                    ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                    AttachedFile(name, mime, dest.absolutePath)
                } catch (_: Exception) { null }
            }
            if (f != null) pendingFile = f else pushLog("COULD NOT READ ATTACHED FILE")
        }
    }

    fun clearAttachedFile() {
        pendingFile?.let { File(it.path).delete() }
        pendingFile = null
    }

    fun archiveNote() {
        val t = noteInput.trim()
        if (t.isEmpty() && pendingFile == null) return
        val date = SimpleDateFormat("M/d/yyyy, h:mm:ss a", Locale.getDefault()).format(Date())
        upd { it.copy(noteArchive = listOf(Note(System.currentTimeMillis(), t, pendingFile, date)) + it.noteArchive) }
        noteInput = ""; pendingFile = null
        pushLog("DATA ARCHIVED TO NEURAL CORE")
    }

    fun deleteNote(id: Long) {
        s.noteArchive.firstOrNull { it.id == id }?.file?.let { File(it.path).delete() }
        upd { it.copy(noteArchive = it.noteArchive.filter { n -> n.id != id }) }
    }

    // ---------- purge ----------
    fun confirmPurge() {
        if (purgeCode == AUTH_KEY) {
            store.wipe()
            s = AppState(lastReset = today())
            pendingFile = null
            pushLog("SYSTEM PURGE INITIATED")
            purgeOpen = false
            stInitOpen = true
        } else {
            pushLog("PURGE FAILED: INVALID CODE")
            purgeOpen = false
        }
    }

    // ---------- settings ----------
    fun toggleSettings() {
        if (settingsOpen) settingsOpen = false
        else { fKey1 = s.geminiKey1; fKey2 = s.geminiKey2; fPrompt = s.systemPrompt; fPromptStatus = ""; settingsOpen = true }
    }

    fun loadContextFile(uri: Uri) {
        viewModelScope.launch {
            val txt = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() } catch (_: Exception) { null }
            }
            if (txt != null) { fPrompt = txt; fPromptStatus = "LOADED: ${displayName(uri).uppercase()}" }
        }
    }

    fun saveSettings() {
        val k1 = fKey1.trim(); val k2 = fKey2.trim()
        upd { it.copy(systemPrompt = fPrompt.trim()) }
        viewModelScope.launch {
            if (k1.isNotEmpty()) {
                if (!online()) { upd { it.copy(geminiKey1 = k1) }; pushLog("OFFLINE: KEY 1 SAVED, WILL VALIDATE WHEN ONLINE") }
                else {
                    pushLog("VALIDATING PRIMARY AI KEY...")
                    val m = Gemini.bestModel(k1)
                    if (m != null) { upd { it.copy(geminiKey1 = k1) }; pushLog("PRIMARY KEY ACTIVE: ${m.uppercase()}") }
                    else pushLog("KEY 1 INVALID OR NO MODELS AVAILABLE")
                }
            } else upd { it.copy(geminiKey1 = "") }

            if (k2.isNotEmpty()) {
                if (!online()) upd { it.copy(geminiKey2 = k2) }
                else {
                    val m = Gemini.bestModel(k2)
                    if (m != null) { upd { it.copy(geminiKey2 = k2) }; pushLog("KEY 2 ACTIVE (SUMMARIZER): ${m.uppercase()}") }
                }
            } else upd { it.copy(geminiKey2 = "") }

            settingsOpen = false
            pushLog("SYSTEM LORE & SETTINGS UPDATED")
        }
    }

    fun triggerPing() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val c = java.net.URL("https://trigger.macrodroid.com/77323e70-8c5b-4a14-a355-e2ac57672a2d/ping")
                    .openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000; c.responseCode; c.disconnect()
            } catch (_: Exception) { }
        }
        pushLog("SECONDARY NODE PINGED")
    }

    // ================= AI (needs internet) =================
    private fun key2() = s.geminiKey2.ifBlank { s.geminiKey1 }

    private fun stLimitText(): String =
        if (s.targetMaxScreenTimeHours != 0.0) s.targetMaxScreenTimeHours.toString()
        else if (s.targetMaxScreenTimeMinutes != 0) String.format(Locale.US, "%.1f", s.targetMaxScreenTimeMinutes / 60.0)
        else "Unset"

    fun askGhost() {
        val q = aiQuery.trim(); if (q.isEmpty()) return
        pushLog("SIGNAL: ${q.uppercase()}", true)
        aiQuery = ""
        viewModelScope.launch {
            if (!online()) { pushLog("OFFLINE: NEURAL LINK NEEDS INTERNET. ALL OTHER SYSTEMS ACTIVE."); return@launch }
            val keys = listOf(s.geminiKey1, s.geminiKey2).filter { it.isNotBlank() }.distinct()
            if (keys.isEmpty()) { pushLog("NO API KEY SET: OPEN SETTINGS (GEAR ICON)"); return@launch }
            val ctxText = if (s.systemPrompt.isNotBlank()) "User Context/Lore:\n${s.systemPrompt}\n" else ""
            val sumCtx = if (s.logSummary.isNotBlank()) "User Activity Today (Summarized Logs):\n${s.logSummary}\n" else ""
            val rawLogs = if (s.logs.isNotEmpty()) "Recent System Logs:\n" + s.logs.joinToString("\n") { "[${it.ts}] ${it.text}" } + "\n" else ""
            val tasksCtx = if (s.tasks.isNotEmpty()) "Current System Quests/Tasks:\n" + s.tasks.mapIndexed { idx, t ->
                "#${idx + 1}: ${t.text} (XP: ${t.xp}, Status: ${if (t.done) "Completed" else "Pending"}, Requires Photo Proof: ${t.requiresProof}" +
                    (if (t.requiresProof) ", Proof Rule: \"${t.proofInstruction.ifBlank { "Clear photo proof" }}\"" else "") + ")"
            }.joinToString("\n") + "\n" else "Current System Quests/Tasks: None\n"
            val stCtx = if (s.screenTimeHistory.isNotBlank())
                "Screen Time Historical Context:\n${s.screenTimeHistory}\nTarget Max Screen Time: ${stLimitText()} hours.\n" else ""
            val prompt = "$ctxText$sumCtx$rawLogs$tasksCtx${stCtx}Persona: Dark Shadow/System Node. Act strictly as the authoritative RPG System or Shadow guide from webtoon/drama series. Speak with radical candor, cold precision, and witty clarity. You have full knowledge of all current system tasks (with their serial numbers #1, #2, etc.), their proof requirements, and system logs. Brief response (max 20 words). User Query: $q"
            for (k in keys) {
                val m = Gemini.bestModel(k) ?: "gemini-1.5-flash"
                val r = Gemini.generate(k, m, prompt)
                if (r != null) { pushLog(r); return@launch }
            }
            pushLog("CRITICAL: ALL NEURAL NODES DEPLETED")
        }
    }

    fun generateAITasks() {
        pushLog("INITIATING AI TASK DEPLOYMENT...")
        viewModelScope.launch {
            if (!online()) { pushLog("OFFLINE: AI TASKS NEED INTERNET. ADD TASKS MANUALLY."); return@launch }
            val keys = listOf(s.geminiKey1, s.geminiKey2).filter { it.isNotBlank() }.distinct()
            if (keys.isEmpty()) { pushLog("NO API KEY SET: OPEN SETTINGS (GEAR ICON)"); return@launch }
            val lore = if (s.systemPrompt.isNotBlank()) "\nUSER LORE & CONTEXT:\n${s.systemPrompt}\n" else ""
            val summ = if (s.logSummary.isNotBlank()) "\nUSER ACCOMPLISHMENTS TODAY (SUMMARIZED): \n${s.logSummary}\n" else ""
            val st = if (s.targetMaxScreenTimeHours != 0.0 || s.targetMaxScreenTimeMinutes != 0)
                "\nSCREEN TIME MANDATE: Include 1 task strictly mandating keeping screen time under ${stLimitText()} hours today.\n" else ""
            val prompt = """You are an absolute, mysterious, high-tech RPG System from a fantasy/drama webtoon (like Solo Leveling). You know exactly who the user is and what they are currently trying to achieve based on their profile and daily summarized activities.$lore$summ$st
INSTRUCTIONS:
1. Generate 3 to 4 hyper-realistic, highly relatable daily quests/objectives tailored specifically to the user's real-life scenario, routine, and lore above.
2. DO NOT make absurd fantasy tasks like 'defeat a dragon' or 'catch the moon'. Make them practical, grounded, actionable, and formatted like cyber system quests.
3. XP VALUATION: Assign a realistic XP reward for each task based on effort/time:
   - Light/Quick tasks: 10 to 20 XP
   - Medium/Standard focus tasks: 25 to 40 XP
   - Heavy/Intense tasks: 50 to 75 XP
4. PHOTO PROOF REQUIREMENT & EXPLICIT AI INSTRUCTIONS (requiresProof & proofInstruction):
   Determine logically if the user can authentically prove the task with static photo evidence.
   If requiresProof is true, set proofInstruction to highly specific, detailed, step-by-step instructions generated by you explicitly telling the user what EXACTLY must be captured in the image to verify completion.
   EXAMPLES OF SPECIFIC PROOF INSTRUCTIONS TO GENERATE:
   - For a reading task (e.g. reading a book for 30 mins): "Take a photo showing your open book with a visible clock/watch showing the start time, and another photo upon finishing with the clock showing 30 minutes elapsed."
   - For a workout task: "Capture a photo of your exercise equipment or sweat towel next to a paper note displaying today's date."
   - For a study/coding task: "Capture a photo of your open IDE or written note sheet with your completed exercise clearly visible."
   If the task cannot be proven by static photo evidence -> requiresProof: false and proofInstruction: "".
5. Return ONLY a valid JSON array of objects. Each object MUST have keys: "text" (string), "xp" (number between 10 and 75), "requiresProof" (boolean), and "proofInstruction" (string). No markdown formatting, code blocks, or extra text."""
            for (k in keys) {
                val m = Gemini.bestModel(k) ?: continue
                val txt = Gemini.generate(k, m, prompt) ?: continue
                val arr = Gemini.parseArray(txt) ?: continue
                if (arr.length() == 0) continue
                val list = ArrayList<Task>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i)
                    val text = o?.optString("text") ?: arr.optString(i)
                    if (text.isBlank()) continue
                    var xp = o?.optInt("xp", 20) ?: 20
                    if (xp < 5) xp = 20
                    if (xp > 100) xp = 100
                    val req = o?.optBoolean("requiresProof", false) ?: false
                    val ins = o?.optString("proofInstruction", "") ?: ""
                    val low = text.lowercase()
                    list.add(Task(text.uppercase(), xp, false, low.contains("screen time") || low.contains("screentime"), req, ins))
                }
                upd { it.copy(tasks = list + it.tasks) }
                pushLog("AI TASKS DEPLOYED WITH DYNAMIC XP VALUES")
                return@launch
            }
            pushLog("AI GENERATION ERROR: CHECK KEY OR NETWORK")
        }
    }

    /** 10-log summary. Offline: writes a local summary now and upgrades it with AI when internet returns. */
    private fun summarizeLogs() {
        viewModelScope.launch {
            val recent = s.logs.joinToString("\n") { "[${it.ts}] ${it.text}" }
            if (recent.isEmpty()) return@launch
            val key = key2()
            if (key.isBlank() || !online()) {
                val secured = s.logs.count { it.text.startsWith("OBJECTIVE SECURED") }
                val local = "[OFFLINE SUMMARY] ${s.logs.size} recent events, $secured objectives secured, " +
                    "${s.water} ML water, level ${s.lvl}, ${s.xp.toInt()} XP."
                upd { it.copy(logSummary = local, pendingSummary = key.isNotBlank()) }
                return@launch
            }
            val m = Gemini.bestModel(key) ?: "gemini-1.5-flash"
            val prompt = "System Logs:\n$recent\n\nTask: Synthesize these log entries into a concise, high-level summary paragraph describing what the user accomplished or did today. Existing summary context: ${s.logSummary.ifBlank { "None" }}"
            val r = Gemini.generate(key, m, prompt)
            if (r != null) upd { it.copy(logSummary = r, pendingSummary = false) }
            else upd { it.copy(pendingSummary = true) }
        }
    }

    private suspend fun analyzeImage(uri: Uri, prompt: String): org.json.JSONObject? {
        if (!online()) { pushLog("OFFLINE: IMAGE VERIFICATION NEEDS INTERNET"); return null }
        val k = key2()
        if (k.isBlank()) { pushLog("NO API KEY SET: OPEN SETTINGS (GEAR ICON)"); return null }
        val img = withContext(Dispatchers.IO) { Gemini.imageToBase64(ctx, uri) }
        if (img == null) { pushLog("COULD NOT READ IMAGE"); return null }
        val m = Gemini.bestModel(k) ?: "gemini-1.5-flash"
        val txt = Gemini.generate(k, m, prompt, img.first, img.second)
        if (txt == null) { pushLog("VERIFICATION ERROR"); return null }
        return Gemini.parseObject(txt)
    }

    fun submitTaskProof() {
        val idx = taskProofIdx ?: return
        val task = s.tasks.getOrNull(idx) ?: return
        val uri = taskProofUri
        if (uri == null) { pushLog("SELECT AN IMAGE FILE FOR QUEST PROOF"); return }
        pushLog("VERIFYING QUEST PROOF WITH SECONDARY NEURAL NODE...")
        viewModelScope.launch {
            val rule = if (task.proofInstruction.isNotBlank()) "\nMandatory Photo Proof Requirement: \"${task.proofInstruction}\"." else ""
            val prompt = """Target Quest: "${task.text}".$rule
Analyze this submitted image and determine whether it authentically proves that the user completed this specific task following the required photo proof guidelines above.
Respond STRICTLY in valid JSON with format:
If authentic proof:
{"valid": true}

If not valid proof:
{"valid": false, "reason": "Short explanation why the image does not prove the quest completion based on required proof rules."}"""
            val j = analyzeImage(uri, prompt) ?: run { pushLog("ERROR PROCESSING QUEST PROOF IMAGE"); return@launch }
            if (j.optBoolean("valid", false)) {
                setTask(idx) { it.copy(done = true) }
                gainXP(task.xp.toDouble())
                pushLog("QUEST VERIFIED BY AI: +${task.xp} XP RECEIVED")
                haptic(40); closeTaskProof()
            } else {
                pushLog("PROOF REJECTED: ${j.optString("reason", "Image does not prove completion of quest.").uppercase()}")
            }
        }
    }

    fun verifyInitialScreenTime() {
        val uri = stInitUri
        if (uri == null) { pushLog("PLEASE SELECT A SCREENSHOT FILE"); return }
        val pk = stInitKey.trim()
        if (pk.isNotEmpty()) { upd { it.copy(geminiKey1 = pk) }; pushLog("UPDATED GEMINI API KEY VIA INITIALIZATION POPUP") }
        pushLog("ANALYZING DEVICE USAGE HISTORY...")
        viewModelScope.launch {
            val date = LocalDate.now().toString()
            val prompt = """Analyze this image carefully. Current Date: $date.
CRITERIA FOR RECOGNITION:
1. The image does NOT need to explicitly display the text "Screen Time". Any smartphone interface showing phone activity, Digital Wellbeing, App Usage duration, Daily/Weekly usage bar graphs, or device activity metrics counts as a valid usage screen.
2. Determine if at least 5 days or more of usage data/history are visible in total.
3. Check the dates or timestamps visible on the screenshot to ensure it is fresh and recent, not an old or irrelevant photo.
4. Extracted relevant data: Extract total daily active hours/minutes, primary top-used apps, and overall usage patterns visible in the image.

OUTPUT FORMAT: Respond STRICTLY in valid JSON with no extra codeblocks or text:
If valid (showing device usage stats AND has recent data for 5+ days):
{"valid": true, "historyText": "Summarize extracted days (e.g. Day 1: 4h, Day 2: 3h...) along with key usage breakdown", "targetMaxHours": 4.0}

If invalid:
{"valid": false, "reason": "Clear explanation of why it was rejected (e.g. 'Image shows camera photo instead of phone usage stats', 'Only 3 days of usage are visible; minimum 5 days required', 'Image appears outdated/old', or 'Image is unreadable')."}"""
            val j = analyzeImage(uri, prompt) ?: run { pushLog("ERROR PROCESSING SCREEN TIME IMAGE"); return@launch }
            if (j.optBoolean("valid", false)) {
                val hrs = j.optDouble("targetMaxHours", 4.0).let { if (it.isNaN() || it <= 0) 4.0 else it }
                upd { it.copy(screenTimeInitialized = true, screenTimeHistory = j.optString("historyText", ""),
                    targetMaxScreenTimeHours = hrs, targetMaxScreenTimeMinutes = Math.round(hrs * 60).toInt()) }
                pushLog("SCREEN TIME VERIFIED: TARGET MAX SET TO $hrs HOURS")
                stInitOpen = false
            } else {
                pushLog("REJECTED: ${j.optString("reason", "Unrecognized screenshot format or insufficient days.").uppercase()}")
            }
        }
    }

    fun submitScreenTimeProof() {
        val uri = stProofUri
        if (uri == null) { pushLog("SELECT SCREENSHOT PROOF FILE"); return }
        pushLog("VERIFYING DAILY SCREEN TIME PROOF...")
        viewModelScope.launch {
            val lim = if (s.targetMaxScreenTimeMinutes != 0) s.targetMaxScreenTimeMinutes else 240
            val limH = if (s.targetMaxScreenTimeHours != 0.0) s.targetMaxScreenTimeHours else 4.0
            val prompt = """Analyze this daily usage screenshot carefully using Key 2 (Log Summarizer/Image Analyzer).
Target Max Limit: $limH hours ($lim minutes).
Current Date: ${LocalDate.now()}.

CRITERIA FOR RECOGNITION:
1. The screenshot does NOT need to explicitly state "Screen Time". Recognize any screen showing today's phone active time, Digital Wellbeing, or total app usage metrics.
2. Verify that visible dates or timestamps indicate this screenshot is recent and relevant for today.
3. ANALYZE APP BREAKDOWN: Extract total active minutes AND breakdown of time spent on specific individual applications visible in the screenshot (e.g. YouTube: 45m, WhatsApp: 30m, Games: 60m).

OUTPUT FORMAT: Respond STRICTLY in valid JSON with no extra codeblocks or text:
If valid:
{"valid": true, "actualMinutes": 210, "appBreakdown": "YouTube: 45m, WhatsApp: 30m, Games: 60m"}

If invalid:
{"valid": false, "reason": "Explanation why rejected (e.g. 'Not a valid phone usage screen', 'Screenshot is outdated/old', or 'Cannot read numbers clearly')."}"""
            val j = analyzeImage(uri, prompt) ?: run { pushLog("ERROR EVALUATING PROOF"); return@launch }
            if (j.optBoolean("valid", false)) {
                upd { it.copy(screenTimeProofSubmitted = true) }
                val actual = j.optInt("actualMinutes", 0)
                val bd = j.optString("appBreakdown", "").let { if (it.isBlank()) "" else " [$it]" }
                if (actual <= lim) {
                    val reward = Math.round((lim - actual) / 2.0).toInt() + 50
                    gainXP(reward.toDouble())
                    pushLog("PROOF ACCEPTED: $actual MINS (LIMIT ${lim}M)$bd. PRIZE: +$reward XP")
                    val ti = s.tasks.indexOfFirst { it.isScreenTime }
                    if (ti != -1 && !s.tasks[ti].done) {
                        setTask(ti) { it.copy(done = true) }
                        gainXP(s.tasks[ti].xp.toDouble())
                        pushLog("DAILY SCREEN TIME TASK COMPLETED: +${s.tasks[ti].xp} XP")
                    }
                } else {
                    val pen = Math.round((actual - lim) * 1.5).toInt()
                    deductXP(pen.toDouble())
                    pushLog("LIMIT EXCEEDED: $actual MINS (LIMIT ${lim}M)$bd. PENALTY: -$pen XP")
                }
                stProofOpen = false
            } else {
                pushLog("PROOF REJECTED: ${j.optString("reason", "Not a valid phone usage screenshot.").uppercase()}")
                deductXP(50.0)
                pushLog("PENALTY APPLIED: INVALID SCREEN TIME PROOF (-50 XP)")
            }
        }
    }
}
