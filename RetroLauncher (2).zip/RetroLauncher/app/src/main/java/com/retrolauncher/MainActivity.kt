package com.retrolauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private val origin = "https://appassets.androidplatform.net"
    private lateinit var web: WebView
    private var promptedForAccess = false
    private var askedPerms = false
    private var pendingCall: String? = null

    private val storeListener: (String, MessageStore.Msg) -> Unit = { contact, msg ->
        runOnUiThread {
            push(JSONObject().put("type", "message").put("contact", contact).put("msg", msg.toJson()))
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            pushContacts()
            val pc = pendingCall
            pendingCall = null
            if (pc != null) {
                if (result[Manifest.permission.CALL_PHONE] == true) placeCall(pc) else dialOnly(pc)
            }
            promptIfNeeded()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MessageStore.init(this)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Never let the top-level page navigate away from our bundled UI.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.isForMainFrame && !request.url.toString().startsWith(origin)
        }

        // Secure bridge: only exposed to our own https origin, never to iframes.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "nativeBridge", setOf(origin)) { _, message, sourceOrigin, isMainFrame, _ ->
                if (isMainFrame && sourceOrigin.toString() == origin) {
                    message.data?.let { handleMessage(it) }
                }
            }
        } else {
            AlertDialog.Builder(this)
                .setMessage("Please update Android System WebView / Chrome. This launcher needs a newer WebView.")
                .setPositiveButton("OK", null).show()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
            }
        })

        web.loadUrl("$origin/assets/www/index.html")
    }

    override fun onStart() {
        super.onStart()
        MessageStore.addListener(storeListener)
    }

    override fun onStop() {
        MessageStore.removeListener(storeListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        val missing = missingPerms()
        if (missing.isNotEmpty() && !askedPerms) {
            askedPerms = true
            permLauncher.launch(missing)
        } else {
            if (hasPerm(Manifest.permission.READ_CONTACTS)) pushContacts()
            promptIfNeeded()
        }
    }

    // Home pressed while launcher is already showing -> back to home screen
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
    }

    // ---------- permissions & prompts ----------

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun missingPerms(): Array<String> {
        val all = mutableListOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        return all.filter { !hasPerm(it) }.toTypedArray()
    }

    private fun hasAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openAccessSettings() =
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun promptIfNeeded() {
        val prefs = getSharedPreferences("launcher_prefs", MODE_PRIVATE)
        if (!hasAccess()) {
            if (promptedForAccess) return
            promptedForAccess = true
            AlertDialog.Builder(this)
                .setTitle("Allow notification access")
                .setMessage("To show your WhatsApp messages and send replies, enable Notification access for Retro Launcher.\n\nOn Android 13+, if the switch is greyed out: App info → ⋮ menu → \"Allow restricted settings\", then try again.")
                .setPositiveButton("Open settings") { _, _ -> openAccessSettings() }
                .setNegativeButton("Later", null)
                .show()
        } else if (!prefs.getBoolean("battery_prompted", false)) {
            prefs.edit().putBoolean("battery_prompted", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Keep running in background")
                .setMessage("Some phones (Xiaomi etc.) kill background apps, which makes you miss WhatsApp messages and alarms.\n\nOn the next screen set Retro Launcher to \"Don't optimize\" / \"No restrictions\". Also enable Autostart for it in Security → Permissions.")
                .setPositiveButton("Open settings") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) {}
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    // ---------- calls ----------

    private fun cleanNumber(raw: String) = raw.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

    private fun dialOnly(number: String) {
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) } catch (e: Exception) {}
    }

    private fun placeCall(raw: String) {
        val number = cleanNumber(raw)
        if (number.isEmpty()) return
        if (hasPerm(Manifest.permission.CALL_PHONE)) {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)))
            } catch (e: Exception) {
                dialOnly(number)
            }
        } else {
            pendingCall = number
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE))
        }
    }

    // ---------- contacts ----------

    private fun roleOf(type: Int) = when (type) {
        1 -> "Home"
        2 -> "Mobile"
        3 -> "Work"
        else -> "Phone"
    }

    private fun loadContacts(): JSONArray {
        val out = JSONArray()
        val seen = HashSet<String>()
        val cols = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.TYPE)
        contentResolver.query(Phone.CONTENT_URI, cols, null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val key = name + "|" + num.filter { it.isDigit() }
                if (!seen.add(key)) continue
                out.put(JSONObject().put("name", name).put("phone", num).put("role", roleOf(c.getInt(2))))
            }
        }
        return out
    }

    private fun pushContacts() {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            push(JSONObject().put("type", "contacts").put("contacts", JSONArray()).put("denied", true))
            return
        }
        Thread {
            val arr = try { loadContacts() } catch (e: Exception) { JSONArray() }
            runOnUiThread {
                push(JSONObject().put("type", "contacts").put("contacts", arr).put("denied", false))
            }
        }.start()
    }

    private fun requestPermsOrSettings() {
        val missing = missingPerms()
        if (missing.isEmpty()) return
        val canAsk = !askedPerms || missing.any { shouldShowRequestPermissionRationale(it) }
        if (canAsk) {
            askedPerms = true
            permLauncher.launch(missing)
        } else {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        }
    }

    // ---------- bridge ----------

    private fun handleMessage(data: String) {
        try {
            val o = JSONObject(data)
            when (o.getString("op")) {
                "sync" -> push(
                    JSONObject().put("type", "threads")
                        .put("threads", MessageStore.snapshotJson()).put("access", hasAccess())
                )

                "sendReply" -> {
                    val id = o.getInt("id")
                    val contact = o.getString("contact")
                    val text = o.getString("text")
                    val err = ReplyRegistry.send(this, contact, text)
                    if (err == null) {
                        MessageStore.add(contact, MessageStore.Msg("Me", text, System.currentTimeMillis(), "sent", false))
                    }
                    push(
                        JSONObject().put("type", "sendResult").put("id", id)
                            .put("ok", err == null).put("error", err ?: "")
                    )
                }

                "openAccessSettings" -> openAccessSettings()
                "getContacts" -> pushContacts()
                "requestPerms" -> requestPermsOrSettings()
                "call" -> placeCall(o.getString("number"))

                "openBrowser" -> {
                    val url = o.getString("url")
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        val i = Intent(this, BrowserActivity::class.java)
                        i.putExtra("url", url)
                        startActivity(i)
                    }
                }

                "syncTimers" -> {
                    val arr = o.getJSONArray("items")
                    val list = (0 until arr.length()).map { TimerScheduler.Item.fromJson(arr.getJSONObject(it)) }
                    TimerScheduler.sync(this, list)
                }
            }
        } catch (e: Exception) { /* ignore malformed messages */ }
    }

    private fun push(payload: JSONObject) {
        val js = "window.__nativeIn && window.__nativeIn(${JSONObject.quote(payload.toString())});"
        web.evaluateJavascript(js, null)
    }
}
