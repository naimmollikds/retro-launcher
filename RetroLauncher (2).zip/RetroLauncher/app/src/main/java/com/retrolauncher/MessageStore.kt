package com.retrolauncher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Holds WhatsApp conversations captured from notifications.
 * Persisted as JSON in app-private storage (not encrypted, not backed up).
 */
object MessageStore {
    private const val PREFS = "wa_store"
    private const val KEY = "threads"
    private const val MAX_PER_THREAD = 200

    data class Msg(
        val sender: String,
        val text: String,
        val timeMs: Long,
        val type: String,      // "received" | "sent"
        val urgent: Boolean
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("sender", sender).put("text", text).put("timeMs", timeMs)
            .put("type", type).put("urgent", urgent)
    }

    private val threads = LinkedHashMap<String, MutableList<Msg>>()
    private var prefs: SharedPreferences? = null
    private val listeners = CopyOnWriteArraySet<(String, Msg) -> Unit>()

    fun addListener(l: (String, Msg) -> Unit) { listeners.add(l) }
    fun removeListener(l: (String, Msg) -> Unit) { listeners.remove(l) }

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs?.getString(KEY, null) ?: return
        try {
            val root = JSONObject(raw)
            for (contact in root.keys()) {
                val arr = root.getJSONArray(contact)
                val list = mutableListOf<Msg>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(Msg(o.getString("sender"), o.getString("text"), o.getLong("timeMs"),
                        o.getString("type"), o.optBoolean("urgent")))
                }
                threads[contact] = list
            }
        } catch (_: Exception) { threads.clear() }
    }

    /** Returns true if the message was new. */
    fun add(contact: String, msg: Msg): Boolean {
        val added: Boolean
        synchronized(this) {
            val list = threads.getOrPut(contact) { mutableListOf() }
            val dup = list.any { it.timeMs == msg.timeMs && it.text == msg.text && it.sender == msg.sender }
            if (dup) return false
            list.add(msg)
            list.sortBy { it.timeMs }
            while (list.size > MAX_PER_THREAD) list.removeAt(0)
            persist()
            added = true
        }
        if (added) listeners.forEach { it(contact, msg) }
        return added
    }

    @Synchronized
    fun snapshotJson(): JSONObject {
        val root = JSONObject()
        for ((c, list) in threads) {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            root.put(c, arr)
        }
        return root
    }

    @Synchronized
    fun clear() { threads.clear(); persist() }

    private fun persist() {
        prefs?.edit()?.putString(KEY, snapshotJson().toString())?.apply()
    }
}
