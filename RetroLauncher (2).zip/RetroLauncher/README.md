# Retro Launcher v2

## Build (GitHub Actions, same as before)
Replace RetroLauncher.zip in your repo with this one, run the workflow, download the APK.
This version uses a FIXED signing key (app/retro-debug.keystore): future builds install
OVER this one and keep your data. Uninstall the old v1 once (it used a random key).
Keep the GitHub repo PRIVATE: anyone with the keystore could sign look-alike updates.

## First run on the phone
1. Allow Contacts, Phone (calls) and Notifications when asked.
2. Notification access (WhatsApp). Android 13+: App info -> ⋮ -> Allow restricted settings first.
3. Battery: set to "No restrictions", enable Autostart (Xiaomi: Security -> Permissions -> Autostart),
   and lock the app in the recents screen. Otherwise MIUI kills the listener and you MISS messages.
4. Make it the default Home app.

## What is real now
- WhatsApp: every notification message is captured (up to 200 per chat); reply via notification.
- Urgent screen: real flagged messages (keywords incl. Bengali), opens the chat.
- Contacts: your phone contacts, searchable in PEOPLE and in the dial pad.
- Calls: every call button places a real call (system call screen).
- Alarms: ring daily at the set time (sound+vibration, lock-screen screen, snooze 10 min, survive reboot).
- Reminders: optional "REMIND AT" date/time -> notification. No time = plain to-do.
- Schedule: time (e.g. 10:00 AM) + optional date -> alert 10 minutes before. No date = today.
- Browser: opens a full-screen browser (any site). COLOR button toggles grayscale.

## Limits
- WhatsApp does not allow reading chat history. Only messages that produced a notification
  while the listener was running are captured (muted chats, chat open on screen, or a killed
  background service = missed).
- Reply works only while WhatsApp still has a notification for that chat.
- Calendar/class schedule is local to this app (not synced with Google Calendar).
