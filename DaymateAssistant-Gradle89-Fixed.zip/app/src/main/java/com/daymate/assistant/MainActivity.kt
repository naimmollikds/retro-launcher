package com.daymate.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DaymateApp() }
    }
}

private data class Expense(
    val id: Long,
    val date: String,
    val title: String,
    val category: String,
    val amount: Double
)

private fun money(value: Double): String =
    "৳" + String.format(Locale.US, "%.2f", value)

private fun loadExpenses(raw: String?): List<Expense> {
    if (raw.isNullOrBlank()) return emptyList()
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Expense(
                id = o.optLong("id"),
                date = o.optString("date"),
                title = o.optString("title"),
                category = o.optString("category"),
                amount = o.optDouble("amount")
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveExpenses(expenses: List<Expense>): String {
    val array = JSONArray()
    expenses.forEach { e ->
        array.put(JSONObject().apply {
            put("id", e.id); put("date", e.date); put("title", e.title)
            put("category", e.category); put("amount", e.amount)
        })
    }
    return array.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DaymateApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("daymate_data", 0) }

    var budget by remember { mutableDoubleStateOf(prefs.getString("budget", "3500")?.toDoubleOrNull() ?: 3500.0) }
    var plannedMeals by remember { mutableIntStateOf(prefs.getInt("planned_meals", 60)) }
    val consumed = remember { mutableStateMapOf<String, Boolean>() }
    val expenses = remember { mutableStateListOf<Expense>().apply {
        addAll(loadExpenses(prefs.getString("expenses", null)))
    } }

    // Load saved meal selections for the selected month as the user navigates.
    var month by remember { mutableStateOf(YearMonth.now()) }
    var showSettings by remember { mutableStateOf(false) }
    var showAddExpense by remember { mutableStateOf(false) }
    var expenseTitle by remember { mutableStateOf("") }
    var expenseCategory by remember { mutableStateOf("Other") }
    var expenseAmount by remember { mutableStateOf("") }

    fun persistSettings() {
        prefs.edit().putString("budget", budget.toString())
            .putInt("planned_meals", plannedMeals).apply()
    }
    fun isTaken(date: LocalDate, slot: String): Boolean =
        consumed["${date}|${slot}"] ?: prefs.getBoolean("meal_${date}_$slot", false)

    fun setTaken(date: LocalDate, slot: String, checked: Boolean) {
        val key = "${date}|${slot}"
        consumed[key] = checked
        prefs.edit().putBoolean("meal_${date}_$slot", checked).apply()
    }

    val monthDates = remember(month) { (1..month.lengthOfMonth()).map { month.atDay(it) } }
    val mealPrice = if (plannedMeals > 0) budget / plannedMeals else 0.0
    val takenCount = monthDates.sumOf { d ->
        (if (isTaken(d, "Lunch")) 1 else 0) + (if (isTaken(d, "Dinner")) 1 else 0)
    }
    val mealCost = takenCount * mealPrice
    val remainingMeals = (plannedMeals - takenCount).coerceAtLeast(0)
    val monthExpenses = expenses.filter { it.date.startsWith(month.toString()) }
    val otherExpenseTotal = monthExpenses.sumOf { it.amount }
    val remainingBudget = budget - mealCost

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Daymate Assistant", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAddExpense = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add expense")
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Monthly overview", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Meal budget")
                                    Text(money(budget), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Per meal")
                                    Text(money(mealPrice), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                            HorizontalDivider()
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                SummaryValue("Meals taken", "$takenCount / $plannedMeals")
                                SummaryValue("Meals left", "$remainingMeals")
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                SummaryValue("Meal spend", money(mealCost))
                                SummaryValue("Meal budget left", money(remainingBudget))
                            }
                            LinearProgressIndicator(
                                progress = { if (budget > 0) (totalSpent / budget).toFloat().coerceIn(0f, 1f) else 0f },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("Meal cost is calculated automatically from checked meals. Unchecking a meal removes it from the count and cost.")
                        }
                    }
                }

                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, "Previous month") }
                                Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, "Next month") }
                            }
                            Text("Select meals for each day", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                items(monthDates, key = { it.toString() }) { date ->
                    val lunchChecked = isTaken(date, "Lunch")
                    val dinnerChecked = isTaken(date, "Dinner")
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()), fontWeight = FontWeight.SemiBold)
                                    Text(date.format(DateTimeFormatter.ofPattern("dd MMM yyyy")), style = MaterialTheme.typography.bodySmall)
                                }
                                Text("${(if (lunchChecked) 1 else 0) + (if (dinnerChecked) 1 else 0)} meal(s)", style = MaterialTheme.typography.labelMedium)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = lunchChecked, onCheckedChange = { setTaken(date, "Lunch", it) })
                                    Text("Lunch")
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = dinnerChecked, onCheckedChange = { setTaken(date, "Dinner", it) })
                                    Text("Dinner")
                                }
                            }
                        }
                    }
                }

                item {
                    Text("Other expenses", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Monthly total: ${money(otherExpenseTotal)}", style = MaterialTheme.typography.bodyMedium)
                }
                if (monthExpenses.isEmpty()) {
                    item { Text("No extra expenses added for this month yet.") }
                } else {
                    items(monthExpenses.sortedByDescending { it.date }, key = { it.id }) { expense ->
                        Card {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(expense.title, fontWeight = FontWeight.SemiBold)
                                    Text("${expense.category} • ${expense.date}", style = MaterialTheme.typography.bodySmall)
                                }
                                Text(money(expense.amount), fontWeight = FontWeight.Bold)
                                IconButton(onClick = {
                                    expenses.removeAll { it.id == expense.id }
                                    prefs.edit().putString("expenses", saveExpenses(expenses)).apply()
                                }) { Icon(Icons.Default.Delete, contentDescription = "Delete expense") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        var budgetInput by remember { mutableStateOf(budget.toString()) }
        var mealsInput by remember { mutableStateOf(plannedMeals.toString()) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Monthly settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(budgetInput, { budgetInput = it }, label = { Text("Monthly meal budget (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    OutlinedTextField(mealsInput, { mealsInput = it }, label = { Text("Planned meals per month") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    budget = budgetInput.toDoubleOrNull()?.coerceAtLeast(0.0) ?: budget
                    plannedMeals = mealsInput.toIntOrNull()?.coerceAtLeast(0) ?: plannedMeals
                    persistSettings()
                    showSettings = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }

    if (showAddExpense) {
        AlertDialog(
            onDismissRequest = { showAddExpense = false },
            title = { Text("Add an expense") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(expenseTitle, { expenseTitle = it }, label = { Text("Expense name") }, singleLine = true)
                    OutlinedTextField(expenseCategory, { expenseCategory = it }, label = { Text("Category") }, singleLine = true)
                    OutlinedTextField(expenseAmount, { expenseAmount = it }, label = { Text("Amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val amount = expenseAmount.toDoubleOrNull()
                    if (expenseTitle.isNotBlank() && amount != null && amount >= 0) {
                        expenses.add(Expense(System.currentTimeMillis(), LocalDate.now().toString(), expenseTitle.trim(), expenseCategory.ifBlank { "Other" }.trim(), amount))
                        prefs.edit().putString("expenses", saveExpenses(expenses)).apply()
                        expenseTitle = ""; expenseAmount = ""; expenseCategory = "Other"
                        showAddExpense = false
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAddExpense = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SummaryValue(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}
