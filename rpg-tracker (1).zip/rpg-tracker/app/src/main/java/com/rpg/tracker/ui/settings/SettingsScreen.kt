package com.rpg.tracker.ui.settings

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rpg.tracker.data.prefs.SettingsStore
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.ui.theme.*
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = GameRepository.get(app)
    private val s = repo.settings

    var keys by mutableStateOf(s.apiKeys); private set
    var activeIndex by mutableStateOf(s.activeKeyIndex); private set
    var model by mutableStateOf(s.model); private set
    var models by mutableStateOf(s.cachedModels.ifEmpty { SettingsStore.DEFAULT_MODELS }); private set
    var interval by mutableStateOf(s.snapshotIntervalMin); private set
    var blocked by mutableStateOf(s.blockedPackages.joinToString(", "))
    var status by mutableStateOf(""); private set
    var loading by mutableStateOf(false); private set

    fun addKey(raw: String) {
        val k = raw.trim()
        if (k.isEmpty() || k in keys) return
        keys = keys + k
        s.apiKeys = keys
    }

    fun removeKey(i: Int) {
        keys = keys.filterIndexed { idx, _ -> idx != i }
        s.apiKeys = keys
        s.activeKeyIndex = 0
        activeIndex = 0
    }

    fun selectModel(m: String) { model = m; s.model = m }

    fun updateInterval(v: Int) { interval = v; s.snapshotIntervalMin = v }

    fun saveBlocked() {
        s.blockedPackages = blocked.split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        status = "Blocklist saved"
    }

    fun fetchModels() {
        viewModelScope.launch {
            loading = true
            repo.rotator.fetchModels()
                .onSuccess { models = it; status = "Loaded ${it.size} models"; activeIndex = s.activeKeyIndex }
                .onFailure { status = "Fetch failed: ${it.message}" }
            loading = false
        }
    }
}

private fun mask(k: String) = if (k.length <= 8) "••••" else k.take(4) + "••••" + k.takeLast(4)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, vm: SettingsViewModel = viewModel()) {
    var newKey by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = NeonCyan, unfocusedBorderColor = NeonCyan.copy(alpha = 0.4f), cursorColor = NeonCyan
    )

    LazyColumn(
        Modifier.fillMaxSize().background(CharcoalBlack).statusBarsPadding().navigationBarsPadding().imePadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("CONFIG//CORE", Modifier.weight(1f), color = NeonCyan, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 2.sp)
                NeonButton("BACK", NeonPurple, onBack)
            }
        }
        item {
            GlassCard {
                Text("GEMINI KEY POOL", color = NeonPurple, fontWeight = FontWeight.Bold)
                Text("Keys rotate automatically on HTTP 429 / 403.", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                vm.keys.forEachIndexed { i, k ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "#${i + 1}  ${mask(k)}" + if (i == vm.activeIndex) "  ● ACTIVE" else "",
                            Modifier.weight(1f), color = if (i == vm.activeIndex) EmeraldGreen else Color.White.copy(alpha = 0.8f)
                        )
                        IconButton(onClick = { vm.removeKey(i) }) { Icon(Icons.Default.Delete, "Remove", tint = CrimsonRed) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        newKey, { newKey = it }, Modifier.weight(1f), singleLine = true,
                        label = { Text("Add API key") }, visualTransformation = PasswordVisualTransformation(), colors = fieldColors
                    )
                    IconButton(onClick = { vm.addKey(newKey); newKey = "" }) { Icon(Icons.Default.Add, "Add", tint = NeonCyan) }
                }
            }
        }
        item {
            GlassCard {
                Text("MODEL", color = NeonPurple, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                ExposedDropdownMenuBox(expanded, { expanded = it }) {
                    OutlinedTextField(
                        vm.model, {}, readOnly = true, label = { Text("Active model") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(), colors = fieldColors
                    )
                    ExposedDropdownMenu(expanded, { expanded = false }) {
                        vm.models.forEach { m ->
                            DropdownMenuItem(text = { Text(m) }, onClick = { vm.selectModel(m); expanded = false })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                NeonButton(if (vm.loading) "FETCHING…" else "REFRESH MODEL LIST", NeonCyan, vm::fetchModels, Modifier.fillMaxWidth(), enabled = !vm.loading)
            }
        }
        item {
            GlassCard {
                Text("SCAN INTERVAL: ${vm.interval} MIN", color = NeonPurple, fontWeight = FontWeight.Bold)
                Slider(
                    value = vm.interval.toFloat(), onValueChange = { vm.updateInterval(it.toInt()) },
                    valueRange = 2f..5f, steps = 2,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                )
            }
        }
        item {
            GlassCard {
                Text("BLOCKED APPS (package names)", color = NeonPurple, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(vm.blocked, { vm.blocked = it }, Modifier.fillMaxWidth(), minLines = 3, colors = fieldColors)
                Spacer(Modifier.height(8.dp))
                NeonButton("SAVE BLOCKLIST", EmeraldGreen, vm::saveBlocked, Modifier.fillMaxWidth())
            }
        }
        if (vm.status.isNotEmpty()) item { Text(vm.status, color = NeonCyan) }
    }
}
