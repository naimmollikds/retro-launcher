# Shadow Alpha (native Android, Kotlin + Jetpack Compose)

Offline-first port of the SHADOW_V200 web app. Everything except the optional AI features works with no internet.

## Build on GitHub
1. Create a repo and push this folder.
2. GitHub > Actions > "Build APK" runs automatically (or run it manually).
3. Download the `ShadowAlpha-apk` artifact. Install `app-debug.apk` (or `app-release.apk`, signed with the debug key).

Local build: open in Android Studio (Koala+) or run `gradle :app:assembleDebug` (JDK 17, Gradle 8.7).

## What is offline
3D character (procedural wireframe head drawn in code, no model download), XP/SP/levels, hydration, quests,
tasbih + salah, chrono timer + bonds + skins, notes with attachments, streak and 7-day chart, backup/restore,
hydration reminders, timer-finished notification, screen time (Android Usage Access), spoken voice (device TTS),
voice dictation (device recognizer; offline if the language pack is installed).

## What needs internet (optional, needs your own Gemini key in Settings)
AI chat, AI quest generation, AI photo-proof check, log summarizer. Without a key the app falls back to a built-in
quest pool, status replies, and a 50% honor-system claim for proof quests.

## Notes
- No API keys are bundled. Paste yours in Settings (stored only on the device, never exported in backups).
- First launch: grant notification permission; open the phone icon to grant Usage Access for screen time.
- Fonts: uses the system monospace font. Drop Archivo Black / Space Mono .ttf files into `res/font/` and swap `Mono` in `Ui.kt` if you want the exact web look.
- Release APK is signed with the debug key for convenience. Use your own keystore before publishing.
