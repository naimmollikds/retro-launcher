package com.shadow.alpha

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ShadowDialog(title: String, accent: Color, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.fillMaxWidth().heightIn(max = 640.dp).background(Color(0xFF09090B)).border(1.dp, accent).padding(16.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title.uppercase(), color = accent, fontSize = 12.sp, fontFamily = Mono, fontWeight = FontWeight.Black)
                Text("✕", color = Color.White, modifier = Modifier.clickable(onClick = onClose).padding(horizontal = 6.dp))
            }
            Column(Modifier.verticalScroll(rememberScrollState()), content = content)
        }
    }
}

@Composable
private fun Body(text: String, color: Color = Color(0xFFD4D4D8)) {
    Text(text, color = color, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun Label(text: String, color: Color = Color(0xFFA1A1AA)) {
    Text(text.uppercase(), color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 3.dp, top = 6.dp))
}

// ───────────────────────── settings ─────────────────────────

@Composable
fun SettingsDialog(vm: GameViewModel, s: GameState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var k1 by remember { mutableStateOf(s.key1) }
    var k2 by remember { mutableStateOf(s.key2) }
    var prompt by remember { mutableStateOf(s.systemPrompt) }
    var hook by remember { mutableStateOf(s.webhookUrl) }
    var goal by remember { mutableStateOf(s.hydrationGoal.toString()) }
    var pin by remember { mutableStateOf(s.pin) }
    var rem by remember { mutableStateOf(s.hydrationReminders) }
    var voice by remember { mutableStateOf(s.voice) }
    var showSummary by remember { mutableStateOf(false) }

    val loadFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()?.let { prompt = it }
            } catch (e: Exception) {
            }
        }
    }

    ShadowDialog("System_Settings", Blood, onClose) {
        Body("Everything works offline. The keys below are only for the optional AI features.", Dim)
        Label("Gemini API key 1 (chat, tasks, photo proof)")
        Field(k1, { k1 = it }, "Optional...", password = true)
        Btn("Test key 1", Modifier.padding(top = 4.dp), color = Dim) { vm.testKey(k1) }
        Label("Gemini API key 2 (log summarizer)", Aqua)
        Field(k2, { k2 = it }, "Optional...", password = true)
        Label("System context & lore prompt", Blood)
        Field(prompt, { prompt = it }, "Who you are, goals, scenario, habits, system rules...", singleLine = false, minLines = 4)
        Btn("Load .txt / .md file", Modifier.padding(top = 4.dp), color = Dim) { loadFile.launch("text/*") }
        Label("Ping webhook URL (optional)")
        Field(hook, { hook = it }, "https://...", keyboard = KeyboardType.Uri)
        Label("Hydration goal (ML)")
        Field(goal, { goal = it.filter(Char::isDigit).take(5) }, "4000", keyboard = KeyboardType.Number)
        Label("Purge PIN")
        Field(pin, { pin = it }, "1420", password = true)
        Spacer(Modifier.height(6.dp))
        Check("Hydration reminders (every ~2h, 08:00-22:00)", rem) { rem = it }
        Check("Spoken system voice (needs a TTS voice installed)", voice) { voice = it }

        Spacer(Modifier.height(8.dp))
        Text(
            if (showSummary) "▾ HIDDEN LOG SUMMARY" else "▸ HIDDEN LOG SUMMARY", color = Gold, fontSize = 9.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.clickable { showSummary = !showSummary }.padding(vertical = 4.dp)
        )
        if (showSummary) Body(s.logSummary.ifBlank { "No daily log summary recorded yet. (Built every 10 logs when an AI key is set; resets at midnight.)" }, Dim)

        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Save", Modifier.weight(1f), filled = true) {
                vm.saveSettings(k1, k2, prompt, hook, goal.toIntOrNull() ?: 4000, rem, voice, pin)
                onClose()
            }
            Btn("Cancel", color = Dim, onClick = onClose)
        }
    }
}

// ───────────────────────── guide ─────────────────────────

@Composable
fun GuideDialog(onClose: () -> Unit) {
    ShadowDialog("System_User_Guide", Aqua, onClose) {
        Label("1. XP & SP", Blood)
        Body("Log water, food, quests and prayers to gain XP. SP is earned as total XP grows (10 XP = 1 SP) and is spent in the Black Market on skins and bond contracts.")
        Label("2. Works offline", Aqua)
        Body("Everything is stored on your phone. The 3D character, timer, quests, tasks, notes, tasbih, reminders and screen time all work with no internet. Only AI chat, AI tasks, AI photo proof and the log summarizer need a connection and a key.")
        Label("3. Offline quests", Gold)
        Body("If the AI is unavailable, the quest button deploys quests from a built-in pool instead. Quests that need photo proof can be claimed on the honor system for 50% XP when offline.")
        Label("4. Screen time", Color(0xFFF59E0B))
        Body("Grant Usage Access once (phone icon). The app reads real usage from Android, sets a daily limit from your last 5 days, and settles at midnight: under the limit earns XP, over the limit costs XP. No screenshots needed.")
        Label("5. Chrono & bonds", Color(0xFF34D399))
        Body("Set minutes and ignite. If you stake a bond first, finishing the timer returns your SP plus the reward; aborting forfeits the bond. You get a notification even if the app is closed.")
        Label("6. Midnight reset", Color(0xFFC084FC))
        Body("At midnight water, quests, logs and prayers reset. The day is saved to history; 100+ XP keeps your streak alive.")
        Btn("Acknowledge & exit", Modifier.fillMaxWidth(), color = Aqua, onClick = onClose)
    }
}

// ───────────────────────── screen time ─────────────────────────

@Composable
fun ScreenTimeDialog(vm: GameViewModel, s: GameState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val perm by vm.usagePermission.collectAsStateWithLifecycle()
    val today by vm.todayMinutes.collectAsStateWithLifecycle()
    val apps by vm.topApps.collectAsStateWithLifecycle()
    var limit by remember { mutableStateOf((s.stTargetMin / 60f).let { "%.1f".format(it) }) }

    ShadowDialog("Screen Time", Color(0xFFF59E0B), onClose) {
        if (!perm) {
            Body("Usage access is off. Grant it to \"Shadow Alpha\" in the next screen, then come back.")
            Btn("Open usage access settings", Modifier.fillMaxWidth(), color = Color(0xFFF59E0B), filled = true) {
                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
            Spacer(Modifier.height(8.dp))
            Btn("I granted it - refresh", Modifier.fillMaxWidth(), color = Dim) { vm.refreshUsage() }
        } else {
            Label("Today")
            Text(
                if (today >= 0) "$today MIN  /  ${s.stTargetMin} MIN LIMIT" else "READING...",
                color = if (today > s.stTargetMin) Blood else Color(0xFF34D399), fontSize = 16.sp, fontWeight = FontWeight.Black
            )
            apps.forEach { (n, m) -> Text("$n: ${m}m", color = Color(0xFFA1A1AA), fontSize = 9.sp) }
            Spacer(Modifier.height(10.dp))
            if (s.stInitialized) Body("Baseline: ${s.stHistory}", Dim)
            Btn(
                if (s.stInitialized) "Recalculate limit from last 5 days" else "Initialize from last 5 days",
                Modifier.fillMaxWidth(), color = Color(0xFFF59E0B), filled = !s.stInitialized
            ) { vm.initScreenTime() }
            Label("Or set the daily limit manually (hours)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(limit, { limit = it.filter { c -> c.isDigit() || c == '.' }.take(4) }, "4.0", Modifier.weight(1f), KeyboardType.Decimal)
                Btn("Set", color = Color(0xFFF59E0B)) { limit.toFloatOrNull()?.let { vm.setScreenTarget((it * 60).toInt()) } }
            }
            Spacer(Modifier.height(10.dp))
            Body("Settles at midnight: under the limit earns 50 XP plus half the minutes saved; over the limit costs 1.5 XP per extra minute (max 300).", Dim)
        }
    }
}

// ───────────────────────── purge ─────────────────────────

@Composable
fun PurgeDialog(vm: GameViewModel, onClose: () -> Unit) {
    var code by remember { mutableStateOf("") }
    ShadowDialog("System Purge", Blood, onClose) {
        Body("This permanently deletes all progress, notes and attached files on this phone. Enter your purge PIN to continue.")
        Field(code, { code = it }, "PURGE CODE...", password = true)
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Execute purge", Modifier.weight(1f), filled = true) { vm.purge(code); onClose() }
            Btn("Cancel", color = Dim, onClick = onClose)
        }
    }
}

// ───────────────────────── quest proof / info ─────────────────────────

@Composable
fun ProofDialog(vm: GameViewModel, task: Task, onClose: () -> Unit) {
    var uri by remember { mutableStateOf<Uri?>(null) }
    val busy by vm.aiBusy.collectAsStateWithLifecycle()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri = it }

    ShadowDialog("Quest Proof Required", Aqua, onClose) {
        Label("Target quest")
        Body(task.text, Aqua)
        if (task.proofInstruction.isNotBlank()) {
            Label("Required proof", Gold)
            Body(task.proofInstruction)
        }
        Body("Upload a photo. AI verification needs internet and an API key. Offline? Claim on the honor system for 50% XP.", Dim)
        Btn(if (uri == null) "Choose photo" else "Photo selected - change", Modifier.fillMaxWidth(), color = Dim) { pick.launch("image/*") }
        Spacer(Modifier.height(8.dp))
        Btn(if (busy) "Verifying..." else "Verify photo & complete", Modifier.fillMaxWidth(), color = Aqua, filled = true, enabled = uri != null && !busy) {
            vm.submitProof(task.id, uri!!) { ok -> if (ok) onClose() }
        }
        Spacer(Modifier.height(8.dp))
        Btn("No connection: claim 50% XP", Modifier.fillMaxWidth(), color = Gold) { vm.claimWithoutProof(task.id); onClose() }
    }
}

@Composable
fun InfoDialog(task: Task, onClose: () -> Unit) {
    ShadowDialog("Quest Requirements", Aqua, onClose) {
        Label("Target quest")
        Body(task.text, Aqua)
        Label("Capture instructions", Gold)
        Body(task.proofInstruction.ifBlank { "Capture clear image evidence proving completion of this task." })
        Btn("Acknowledge", Modifier.fillMaxWidth(), color = Aqua, onClick = onClose)
    }
}
