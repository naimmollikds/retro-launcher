package com.shadow.alpha

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar

object Notify {
    private const val CHANNEL = "shadow_main"

    fun post(ctx: Context, id: Int, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Shadow System", NotificationManager.IMPORTANCE_DEFAULT)
        )
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_ghost)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

/** Fires when the chrono timer ends, even if the app is closed. */
class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notify.post(context, 2, "CHRONO CYCLE COMPLETE", "Return to the system and claim your result.")
    }

    companion object {
        private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 77, Intent(ctx, TimerReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun schedule(ctx: Context, atMs: Long) {
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            // Inexact alarm: needs no special permission; may fire a little late in Doze.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pending(ctx))
        }

        fun cancel(ctx: Context) {
            ctx.getSystemService(AlarmManager::class.java)?.cancel(pending(ctx))
        }
    }
}

/** Gentle hydration nudge every ~2h between 08:00 and 22:00 if you are behind pace. */
class HydrationWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val s = Store(applicationContext).load()
        if (!s.hydrationReminders) return Result.success()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour < 8 || hour >= 22) return Result.success()
        val water = if (s.lastReset == today()) s.water else 0
        val expected = s.hydrationGoal * (hour - 7) / 15f
        if (water < expected - 250) {
            Notify.post(
                applicationContext, 1, "HYDRATION LOW",
                "$water / ${s.hydrationGoal} ML. Drink up."
            )
        }
        return Result.success()
    }
}
