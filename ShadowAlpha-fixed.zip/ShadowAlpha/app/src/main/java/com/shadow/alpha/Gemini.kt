package com.shadow.alpha

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * The ONLY networked part of the app. Every call is optional; if there is no key or no
 * connection the callers fall back to offline behaviour.
 */
object Gemini {
    private val MODELS = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash")

    fun textPart(s: String): JSONObject = JSONObject().put("text", s)

    fun imagePart(bytes: ByteArray, mime: String): JSONObject = JSONObject().put(
        "inline_data",
        JSONObject().put("mime_type", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
    )

    fun parts(vararg p: JSONObject): JSONArray = JSONArray().also { arr -> p.forEach { arr.put(it) } }

    suspend fun generate(key: String, parts: JSONArray): String = withContext(Dispatchers.IO) {
        var lastErr = "no model available"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .toString()
            .toByteArray()
        for (model in MODELS) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(body) }
                val code = conn.responseCode
                if (code == 200) {
                    val txt = conn.inputStream.bufferedReader().readText()
                    return@withContext JSONObject(txt)
                        .getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                        .getJSONObject(0).getString("text")
                }
                lastErr = "HTTP $code"
                // Bad key / bad request will fail on every model; model missing or busy: try the next.
                if (code != 404 && code != 429 && code < 500) break
            } finally {
                conn.disconnect()
            }
        }
        throw IOException(lastErr)
    }

    fun stripFences(s: String): String =
        s.trim().replace(Regex("```(json)?", RegexOption.IGNORE_CASE), "").trim()
}
