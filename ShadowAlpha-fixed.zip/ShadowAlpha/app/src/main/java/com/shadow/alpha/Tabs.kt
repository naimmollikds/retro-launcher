package com.shadow.alpha

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File
import kotlin.math.max

private val tabPad = Modifier.padding(start = 20.dp, end = 20.dp, top = 15.dp, bottom = 15.dp)

@Composable
private fun TabScroll(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).then(tabPad), content = content)
}

// ───────────────────────── 1. Neural ─────────────────────────

@Composable
fun NeuralTab(vm: GameViewModel, s: GameState) {
    var q by remember { mutableStateOf("") }
    val busy by vm.aiBusy.collectAsStateWithLifecycle()
    val speech = rememberSpeech { vm.ask(it) }
    TabScroll {
        Module {
            Tag("Neural_Link")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(q, { q = it }, "Signal thought...", Modifier.weight(1f))
                Text("MIC", color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable { speech() }.padding(4.dp))
                Icon(
                    Icons.AutoMirrored.Filled.Send, "Send", tint = Blood,
                    modifier = Modifier.clickable { vm.ask(q); q = "" }.padding(4.dp)
                )
            }
            if (busy) Text("PROCESSING...", color = Aqua, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Tag("System_Logs")
            Box(Modifier.fillMaxWidth().height(170.dp).verticalScroll(rememberScrollState())) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    s.logs.forEach {
                        Text(
                            "[${it.ts}] ${it.text}", color = Color(0xFF777777), fontSize = 9.sp,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp)
                        )
                    }
                }
            }
        }
        Btn("Ping Secondary Node", Modifier.fillMaxWidth(), filled = true) { vm.ping() }
    }
}

// ───────────────────────── 2. Vitals ─────────────────────────

@Composable
fun VitalsTab(vm: GameViewModel, s: GameState) {
    var custom by remember { mutableStateOf("") }
    var meal by remember { mutableStateOf("") }
    TabScroll {
        Module {
            Tag("Hydration Intake")
            Text("${s.water} ML", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text("GOAL ${s.hydrationGoal} ML", color = Dim, fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("+250 ML", Modifier.weight(1f), color = Aqua) { vm.logWater(250) }
                Btn("+500 ML", Modifier.weight(1f), color = Aqua) { vm.logWater(500) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Field(custom, { custom = it.filter(Char::isDigit).take(4) }, "Custom ML", Modifier.weight(1f), KeyboardType.Number)
                Btn("Add", color = Aqua) { custom.toIntOrNull()?.let { vm.logWater(it); custom = "" } }
            }
            Spacer(Modifier.height(8.dp))
            Btn("Undo last drink", Modifier.fillMaxWidth(), color = Dim) { vm.undoWater() }
        }
        Module {
            Tag("Nutrient Intake")
            Field(meal, { meal = it }, "Describe intake...")
            Spacer(Modifier.height(8.dp))
            Btn("Commit (+50 XP)", Modifier.fillMaxWidth()) { vm.logMeal(meal); meal = "" }
        }
    }
}

// ───────────────────────── 3. Quests ─────────────────────────

@Composable
fun QuestsTab(vm: GameViewModel, s: GameState, onProof: (Long) -> Unit, onInfo: (Long) -> Unit) {
    var text by remember { mutableStateOf("") }
    var xp by remember { mutableStateOf("20") }
    val busy by vm.aiBusy.collectAsStateWithLifecycle()
    val minutes by vm.todayMinutes.collectAsStateWithLifecycle()
    TabScroll {
        Module {
            Tag("Daily Objectives")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(text, { text = it }, "Target objective...", Modifier.weight(1f))
                Field(xp, { xp = it.filter(Char::isDigit).take(3) }, "XP", Modifier.width(64.dp), KeyboardType.Number)
            }
            Spacer(Modifier.height(8.dp))
            Btn("Deploy Custom Task", Modifier.fillMaxWidth()) { vm.addTask(text, xp.toIntOrNull() ?: 20); text = "" }
            Spacer(Modifier.height(8.dp))
            Btn(
                if (busy) "Deploying..." else "Deploy Dynamic Tasks (AI, offline fallback)",
                Modifier.fillMaxWidth(), color = Aqua, enabled = !busy
            ) { vm.generateTasks() }
        }
        s.tasks.forEachIndexed { i, t ->
            Module {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("#${i + 1} ", color = Blood, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                t.text, color = if (t.done) Color(0x4DFFFFFF) else Color.White, fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                textDecoration = if (t.done) TextDecoration.LineThrough else null,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (t.requiresProof) {
                                Text(" CAM", color = Aqua, fontSize = 8.sp, fontWeight = FontWeight.Black)
                                Icon(Icons.Default.Info, "Proof details", tint = Aqua, modifier = Modifier.padding(start = 4.dp).width(14.dp).height(14.dp).clickable { onInfo(t.id) })
                            }
                        }
                        Text("+${t.xp} XP", color = Gold, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                        if (t.isScreenTime) {
                            Text(
                                if (minutes >= 0) "TODAY ${minutes}/${s.stTargetMin} MIN - SETTLES AT MIDNIGHT" else "NEEDS USAGE ACCESS (PHONE ICON)",
                                color = Color(0xFFF59E0B), fontSize = 8.sp
                            )
                        }
                    }
                    Text(
                        if (t.done) "↺" else "✓", color = Blood, fontSize = 18.sp,
                        modifier = Modifier.clickable {
                            if (!t.done && t.requiresProof) onProof(t.id) else vm.toggleTask(t.id)
                        }.padding(8.dp)
                    )
                    Text("✕", color = Color(0xFF444444), fontSize = 14.sp, modifier = Modifier.clickable { vm.deleteTask(t.id) }.padding(6.dp))
                }
            }
        }
    }
}

// ───────────────────────── 4. Market ─────────────────────────

@Composable
fun MarketTab(vm: GameViewModel, s: GameState) {
    TabScroll {
        Module {
            Tag("Active_Contracts", Gold)
            Text(
                s.contract?.let { "${it.type.uppercase()} BOND ACTIVE: ${it.cost} SP STAKED, REWARD ${it.reward} XP. FINISH THE TIMER. ABORTING FORFEITS THE BOND." }
                    ?: "No active bonds. Set the timer, then risk SP to gain XP.",
                color = Color(0x80FFFFFF), fontSize = 9.sp
            )
        }
        Module {
            Tag("Black_Market")
            Text("SP AVAILABLE: ${"%.1f".format(s.sp)}", color = ShadowBlue, fontSize = 9.sp, modifier = Modifier.padding(bottom = 8.dp))
            ShopRow("Gold Skin", "XP x2 | 30 MINS", Gold, "50 SP", "Apply", s.skin == "gold") { vm.buySkin("gold", 50, 2) }
            ShopRow("Diamond Skin", "XP x3 | 30 MINS", Color(0xFF22D3EE), "100 SP", "Apply", s.skin == "diamond") { vm.buySkin("diamond", 100, 3) }
            ShopRow("Platinum Skin", "XP x4 | 30 MINS", Color(0xFFD4D4D8), "200 SP", "Apply", s.skin == "platinum") { vm.buySkin("platinum", 200, 4) }
            ShopRow("Focus Contract", "BOND 50 SP | REWARD 100 XP", Color(0xFFF59E0B), "", "Stake", false) { vm.initStake("Focus", 50, 100) }
            ShopRow("Physical Contract", "BOND 50 SP | REWARD 100 XP", Color(0xFF3B82F6), "", "Stake", false) { vm.initStake("Physical", 50, 100) }
        }
    }
}

@Composable
private fun ShopRow(name: String, sub: String, color: Color, cost: String, btn: String, active: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(if (active) "ACTIVE" else sub, color = if (active) Blood else Color(0x4DFFFFFF), fontSize = 8.sp)
        }
        if (cost.isNotEmpty()) Text(cost, color = ShadowBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 10.dp))
        Btn(btn, color = color, onClick = onClick)
    }
}

// ───────────────────────── 5. Character ─────────────────────────

@Composable
fun CharTab(vm: GameViewModel, s: GameState, onPurge: () -> Unit) {
    val ctx = LocalContext.current
    var note by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Uri?>(null) }
    var pickedName by remember { mutableStateOf("") }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        picked = uri
        pickedName = uri?.lastPathSegment ?: ""
    }
    val speech = rememberSpeech { note = (note + " " + it).trim() }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportJson().toByteArray()) }
                Toast.makeText(ctx, "BACKUP SAVED", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "BACKUP FAILED", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = try { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() } catch (e: Exception) { null }
            val ok = txt != null && vm.importJson(txt)
            Toast.makeText(ctx, if (ok) "DATA RESTORED" else "INVALID BACKUP FILE", Toast.LENGTH_SHORT).show()
        }
    }

    TabScroll {
        // Tasbih + salah
        Column(
            Modifier.fillMaxWidth().padding(bottom = 15.dp).background(Color(0xFF050505)).border(1.dp, Color(0xFF1A1A1A)).padding(15.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Tag("Tasbih_Protocol")
            Text("${s.tasbih}", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.width(80.dp).height(80.dp).border(2.dp, Gold, androidx.compose.foundation.shape.CircleShape)
                    .clickable { vm.incTasbih() },
                contentAlignment = Alignment.Center
            ) { Text("TAP", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Black) }
            Text("↺", color = Color(0x4DFFFFFF), fontSize = 18.sp, modifier = Modifier.clickable { vm.resetTasbih() }.padding(8.dp))
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha").forEachIndexed { i, n ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { vm.setSalah(i, !s.salah[i]) }) {
                        Text(n.uppercase(), color = Dim, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier.width(22.dp).height(22.dp).border(1.dp, if (s.salah[i]) Blood else Color(0xFF333333)).background(if (s.salah[i]) Blood else Color.Black),
                            contentAlignment = Alignment.Center
                        ) { if (s.salah[i]) Text("✓", color = Color.Black, fontWeight = FontWeight.Black) }
                    }
                }
            }
        }

        // Progress history
        Module {
            Tag("Last_7_Days_XP", Gold)
            val days = (s.history.takeLast(6).map { it.xp.toFloat() } + s.dayXp.toFloat())
            val peak = max(100f, days.max())
            Canvas(Modifier.fillMaxWidth().height(60.dp)) {
                val slot = size.width / 7f
                days.forEachIndexed { i, v ->
                    val h = size.height * (v / peak)
                    drawRect(
                        if (i == days.lastIndex) Blood else Color(0xFF7A0000),
                        topLeft = Offset(slot * (7 - days.size + i) + slot * 0.2f, size.height - h),
                        size = Size(slot * 0.6f, max(2f, h))
                    )
                }
            }
            Text("STREAK ${s.streak}D  |  BEST ${s.bestStreak}D  |  A DAY COUNTS AT 100+ XP", color = Dim, fontSize = 8.sp, modifier = Modifier.padding(top = 6.dp))
        }

        // Archive
        Module {
            Tag("Neural_Archive")
            Field(note, { note = it }, "Record entry...", Modifier.fillMaxWidth(), singleLine = false, minLines = 3)
            if (picked != null) {
                Row(Modifier.fillMaxWidth().padding(top = 6.dp).background(Color(0xFF0A0A0A)).border(1.dp, Edge).padding(6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ATTACHED: ${pickedName.uppercase()}", color = Aqua, fontSize = 8.sp, modifier = Modifier.weight(1f))
                    Text("✕", color = Blood, modifier = Modifier.clickable { picked = null; pickedName = "" })
                }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("MIC", color = Dim) { speech() }
                Btn("ATTACH", color = Dim) { pick.launch("*/*") }
                Btn("Archive Data", Modifier.weight(1f), color = Color(0xFF0044FF)) {
                    vm.addNote(note, picked); note = ""; picked = null; pickedName = ""
                }
            }
            Spacer(Modifier.height(12.dp))
            s.notes.forEach { n -> NoteRow(n, onDelete = { vm.deleteNote(n.id) }) }
        }

        Module {
            Tag("Backup", Aqua)
            Text("Export or restore progress as a JSON file (API keys are never included, attached files are not).", color = Dim, fontSize = 8.sp, modifier = Modifier.padding(bottom = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Export", Modifier.weight(1f), color = Aqua) { export.launch("shadow_backup_${today()}.json") }
                Btn("Import", Modifier.weight(1f), color = Aqua) { restore.launch(arrayOf("application/json", "text/plain", "*/*")) }
            }
        }

        Btn("WIPE SYSTEM DATA", Modifier.fillMaxWidth(), color = Blood, onClick = onPurge)
    }
}

@Composable
private fun NoteRow(n: Note, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).background(Color(0xFF050505)).border(1.dp, Color(0xFF111111)).padding(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f)) {
            Text(n.date, color = Color(0x4DFFFFFF), fontSize = 7.sp)
            if (n.text.isNotEmpty()) Text(n.text, color = Color.White, fontSize = 10.sp)
            val f = n.filePath?.let { File(it) }
            if (f != null && f.exists()) {
                if (n.mime?.startsWith("image/") == true) {
                    val bmp = remember(n.filePath) { ImageUtil.thumb(f.absolutePath) }
                    if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.padding(top = 6.dp).fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
                }
                Text(
                    "OPEN ${n.fileName?.uppercase() ?: "FILE"}", color = Aqua, fontSize = 9.sp,
                    modifier = Modifier.padding(top = 6.dp).clickable {
                        try {
                            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(uri, n.mime ?: "*/*")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        } catch (e: ActivityNotFoundException) {
                            Toast.makeText(ctx, "NO APP TO OPEN THIS FILE", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            } else if (n.fileName != null) {
                Text("FILE UNAVAILABLE: ${n.fileName.uppercase()}", color = Dim, fontSize = 8.sp)
            }
        }
        Text("✕", color = Color(0xFF444444), modifier = Modifier.clickable(onClick = onDelete).padding(4.dp))
    }
}
