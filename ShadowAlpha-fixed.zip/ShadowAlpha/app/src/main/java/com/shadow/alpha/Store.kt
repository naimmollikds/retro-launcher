package com.shadow.alpha

import android.content.Context
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDate

val JsonCfg = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    isLenient = true
}

fun today(): String = LocalDate.now().toString()

/** Everything lives in one JSON file in app-private storage. No network involved. */
class Store(private val ctx: Context) {
    private val file = File(ctx.filesDir, "state.json")

    fun load(): GameState {
        if (!file.exists()) return GameState(lastReset = today())
        return try {
            JsonCfg.decodeFromString(GameState.serializer(), file.readText())
        } catch (e: Exception) {
            // Keep the unreadable file instead of silently destroying it.
            file.renameTo(File(ctx.filesDir, "state.corrupt.${System.currentTimeMillis()}.json"))
            GameState(lastReset = today())
        }
    }

    @Synchronized
    fun save(state: GameState) {
        val tmp = File(ctx.filesDir, "state.json.tmp")
        tmp.writeText(JsonCfg.encodeToString(GameState.serializer(), state))
        tmp.renameTo(file)
    }

    fun mediaDir(): File = File(ctx.filesDir, "media").also { it.mkdirs() }

    fun wipe() {
        file.delete()
        mediaDir().deleteRecursively()
    }
}
