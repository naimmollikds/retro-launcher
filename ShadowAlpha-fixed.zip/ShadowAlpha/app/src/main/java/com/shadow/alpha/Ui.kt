package com.shadow.alpha

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.min
import kotlin.math.roundToInt

// ───────────────────────── palette & small components ─────────────────────────

val Mono = FontFamily.Monospace
val Blood = Color(0xFFFF0000)
val ShadowBlue = Color(0xFF0088FF)
val Gold = Color(0xFFFFD700)
val Aqua = Color(0xFF00F2FF)
val Panel = Color(0xFF0A0A0A)
val Edge = Color(0xFF222222)
val Dim = Color(0xFF555555)

@Composable
fun Module(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(Panel)
            .border(1.dp, Edge)
            .padding(12.dp),
        content = content
    )
}

@Composable
fun Tag(text: String, color: Color = Blood) {
    Text(
        text.uppercase(), color = color, fontSize = 9.sp, fontFamily = Mono,
        fontWeight = FontWeight.Black, modifier = Modifier.padding(bottom = 5.dp)
    )
}

@Composable
fun Btn(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Blood,
    filled: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier
            .background(if (filled) color else Color.Black)
            .border(1.dp, if (enabled) color else Dim)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text.uppercase(), color = if (filled) Color.Black else if (enabled) color else Dim,
            fontSize = 10.sp, fontFamily = Mono, fontWeight = FontWeight.Black
        )
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
    password: Boolean = false
) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        textStyle = TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = Mono),
        cursorBrush = SolidColor(Blood),
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation()
        else androidx.compose.ui.text.input.VisualTransformation.None,
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .border(1.dp, Color(0xFF333333))
                    .padding(8.dp)
            ) {
                if (value.isEmpty()) Text(hint, color = Dim, fontSize = 11.sp, fontFamily = Mono)
                inner()
            }
        }
    )
}

@Composable
fun Check(label: String, on: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.clickable { onToggle(!on) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(18.dp).height(18.dp).border(1.dp, if (on) Blood else Color(0xFF333333))
                .background(if (on) Blood else Color.Black),
            contentAlignment = Alignment.Center
        ) { if (on) Text("✓", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color(0xFFCCCCCC), fontSize = 10.sp, fontFamily = Mono)
    }
}

@Composable
fun rememberSpeech(onResult: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) onResult(t)
    }
    return {
        try {
            launcher.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "NO SPEECH RECOGNIZER INSTALLED", Toast.LENGTH_SHORT).show()
        }
    }
}

// ───────────────────────── root ─────────────────────────

@Composable
fun ShadowApp(vm: GameViewModel) {
    val ctx = LocalContext.current
    val s by vm.state.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val battery by vm.battery.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var dlg by rememberSaveable { mutableStateOf("") }
    var proofId by remember { mutableStateOf<Long?>(null) }
    var infoId by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(Unit) { vm.messages.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blood, background = Color.Black, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
            Header(
                vm, s, now, battery,
                onScreen = { dlg = "screen" }, onGuide = { dlg = "guide" }, onSettings = { dlg = "settings" }
            )
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xF2000000))) {
                when (tab) {
                    0 -> NeuralTab(vm, s)
                    1 -> VitalsTab(vm, s)
                    2 -> QuestsTab(vm, s, onProof = { proofId = it }, onInfo = { infoId = it })
                    3 -> MarketTab(vm, s)
                    else -> CharTab(vm, s, onPurge = { dlg = "purge" })
                }
            }
            NavBar(tab) { tab = it }
        }

        when (dlg) {
            "settings" -> SettingsDialog(vm, s) { dlg = "" }
            "guide" -> GuideDialog { dlg = "" }
            "screen" -> ScreenTimeDialog(vm, s) { dlg = "" }
            "purge" -> PurgeDialog(vm) { dlg = "" }
        }
        proofId?.let { id -> s.tasks.firstOrNull { it.id == id }?.let { ProofDialog(vm, it) { proofId = null } } }
        infoId?.let { id -> s.tasks.firstOrNull { it.id == id }?.let { InfoDialog(it) { infoId = null } } }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val icons: List<ImageVector> = listOf(
        Icons.Default.Face, Icons.Default.Favorite, Icons.Default.CheckCircle,
        Icons.Default.ShoppingCart, Icons.Default.Person
    )
    Row(Modifier.fillMaxWidth().height(60.dp).background(Color.Black).border(BorderStroke(1.dp, Edge))) {
        icons.forEachIndexed { i, ic ->
            Box(Modifier.weight(1f).height(60.dp).clickable { onTab(i) }, contentAlignment = Alignment.Center) {
                Icon(ic, null, tint = if (i == tab) Blood else Color(0xFF333333))
            }
        }
    }
}

// ───────────────────────── header ─────────────────────────

fun vitality(s: GameState): Int {
    val w = min(1f, s.water / s.hydrationGoal.toFloat()) * 40f
    val t = if (s.tasks.isEmpty()) 0f else s.tasks.count { it.done } / s.tasks.size.toFloat() * 40f
    val p = s.salah.count { it } / 5f * 20f
    return (w + t + p).roundToInt()
}

@Composable
fun Header(
    vm: GameViewModel, s: GameState, now: Long, battery: Pair<Int, Boolean>,
    onScreen: () -> Unit, onGuide: () -> Unit, onSettings: () -> Unit
) {
    var mins by remember { mutableStateOf("") }
    val remaining = vm.timerRemaining(s, now)
    val running = s.timerEndAt > 0
    val clock = remember(now / 1000) { LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a")) }

    Box(Modifier.fillMaxWidth().height(262.dp).background(Color.Black).border(BorderStroke(1.dp, Edge))) {
        Shadow3D(s.skin, Modifier.align(Alignment.TopCenter).padding(top = 44.dp).fillMaxWidth().height(140.dp))

        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("SHADOW_ALPHA", color = Color.White, fontSize = 14.sp, fontFamily = Mono, fontWeight = FontWeight.Black)
                Box(
                    Modifier.padding(top = 4.dp).width(100.dp).height(1.dp)
                        .background(Brush.horizontalGradient(listOf(Color.Transparent, Blood, Color.Transparent)))
                )
                Text("LEVEL_${s.lvl}", color = Color(0x66FFFFFF), fontSize = 8.sp, fontFamily = Mono, modifier = Modifier.padding(top = 6.dp))
                Text("STREAK ${s.streak}D", color = Gold, fontSize = 8.sp, fontFamily = Mono)
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Phone, "Screen time", tint = Color(0xFFF59E0B), modifier = Modifier.width(16.dp).height(16.dp).clickable(onClick = onScreen))
                    Icon(Icons.Default.Info, "Guide", tint = Aqua, modifier = Modifier.width(16.dp).height(16.dp).clickable(onClick = onGuide))
                    Icon(Icons.Default.Settings, "Settings", tint = Blood, modifier = Modifier.width(16.dp).height(16.dp).clickable(onClick = onSettings))
                }
                Text(clock, color = Color(0x80FFFFFF), fontSize = 9.sp, fontFamily = Mono, modifier = Modifier.padding(top = 4.dp))
                Text(
                    if (battery.first >= 0) "PWR: ${battery.first}%" else "PWR: --%",
                    color = Color(0xFFDC2626), fontSize = 9.sp, fontFamily = Mono, fontWeight = FontWeight.Bold
                )
                Text(if (battery.second) "CHARGING" else "DISCHARGING", color = Color(0xFFDC2626), fontSize = 7.sp, fontFamily = Mono)
            }
        }

        // XP / SP / HYD bars
        Column(Modifier.align(Alignment.TopEnd).padding(top = 82.dp, end = 15.dp).width(110.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            StatBar("XP ${s.xp.toInt()}/${s.xpLimit}", (s.xp / s.xpLimit).toFloat(), Gold)
            StatBar("SP ${"%.1f".format(s.sp)}/${s.spLimit}", (s.sp / s.spLimit).toFloat(), ShadowBlue)
            StatBar("HYD ${s.water}/${s.hydrationGoal}", s.water / s.hydrationGoal.toFloat(), Aqua)
        }

        // Chrono block
        Row(
            Modifier.align(Alignment.BottomCenter).padding(start = 20.dp, end = 20.dp, bottom = 22.dp)
                .fillMaxWidth().height(44.dp).background(Color(0xFF050505)).border(1.dp, Edge).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "%02d:%02d".format(remaining / 60, remaining % 60),
                color = Blood, fontSize = 18.sp, fontFamily = Mono, fontWeight = FontWeight.Black,
                modifier = Modifier.width(80.dp)
            )
            Field(mins, { mins = it.filter(Char::isDigit).take(3) }, "MINS", Modifier.width(62.dp), KeyboardType.Number)
            Btn(
                if (running) "PAUSE" else if (s.timerPaused > 0) "RESUME" else "IGNITE",
                Modifier.weight(1f)
            ) { vm.igniteTimer(mins.toIntOrNull() ?: 0); mins = "" }
            Text("↺", color = Color(0x66FFFFFF), fontSize = 18.sp, modifier = Modifier.clickable { vm.resetTimer() }.padding(4.dp))
        }

        // vitality segments
        val vit = vitality(s)
        Row(Modifier.align(Alignment.BottomCenter).padding(start = 20.dp, end = 20.dp, bottom = 9.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0 until 10) {
                Box(Modifier.weight(1f).height(5.dp).background(if (i < vit / 10) Blood else Color(0xFF111111)))
            }
        }
    }
}

@Composable
fun StatBar(label: String, frac: Float, color: Color) {
    Column {
        Text(label, color = Color(0xCCFFFFFF), fontSize = 7.sp, fontFamily = Mono, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFF111111), RoundedCornerShape(2.dp))) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).height(4.dp).background(color, RoundedCornerShape(2.dp)))
        }
    }
}
