package com.shadow.alpha

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Procedural wireframe head: generated in code, so there is no model file or download at all. */
object HeadMesh {
    private const val A = 0.78f
    private const val B = 1.0f
    private const val C = 0.88f

    private fun taper(y: Float): Float = if (y < 0) 1f - 0.38f * (-y / B).pow(1.6f) else 1f

    private fun surf(theta: Float, phi: Float): Triple<Float, Float, Float> {
        val y = B * cos(theta)
        val k = taper(y)
        return Triple(A * sin(theta) * cos(phi) * k, y, C * sin(theta) * sin(phi) * k)
    }

    /** z on the front of the face for a given x,y (including jaw taper). */
    private fun zFace(x: Float, y: Float): Float {
        val k = taper(y)
        val x0 = x / k
        return C * sqrt(max(0f, 1f - (x0 / A).pow(2) - (y / B).pow(2))) * k
    }

    private fun poly(pts: List<Triple<Float, Float, Float>>): FloatArray {
        val a = FloatArray(pts.size * 3)
        pts.forEachIndexed { i, p -> a[i * 3] = p.first; a[i * 3 + 1] = p.second; a[i * 3 + 2] = p.third }
        return a
    }

    fun build(): List<FloatArray> {
        val lines = mutableListOf<FloatArray>()
        val tau = (2 * PI).toFloat()
        val pi = PI.toFloat()
        // latitude rings
        for (i in 1..11) {
            val th = pi * i / 12f
            lines += poly((0..48).map { j -> surf(th, tau * j / 48f) })
        }
        // longitude arcs
        for (j in 0 until 16) {
            val ph = tau * j / 16f
            lines += poly((0..24).map { i -> surf(pi * i / 24f, ph) })
        }
        // eyes
        for (sx in listOf(-1f, 1f)) {
            val cx = 0.3f * sx
            lines += poly((0..20).map { n ->
                val t = tau * n / 20f
                val x = cx + 0.11f * cos(t)
                val y = 0.18f + 0.06f * sin(t)
                Triple(x, y, zFace(x, y) + 0.012f)
            })
        }
        // nose
        val nz = zFace(0f, -0.05f)
        lines += poly(
            listOf(
                Triple(0f, 0.15f, zFace(0f, 0.15f) + 0.01f),
                Triple(0f, -0.1f, nz + 0.2f),
                Triple(-0.09f, -0.16f, zFace(-0.09f, -0.16f) + 0.06f),
                Triple(0f, -0.1f, nz + 0.2f),
                Triple(0.09f, -0.16f, zFace(0.09f, -0.16f) + 0.06f)
            )
        )
        // mouth
        lines += poly((0..14).map { n ->
            val x = -0.25f + 0.5f * n / 14f
            val y = -0.4f - 0.04f * cos((x / 0.25f) * pi / 2f)
            Triple(x, y, zFace(x, y) + 0.012f)
        })
        return lines
    }
}

@Composable
fun Shadow3D(skin: String, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { t ->
                if (last != 0L) angle += (t - last) / 1e9f * 0.5f
                last = t
            }
        }
    }
    val mesh = remember { HeadMesh.build() }
    val line = when (skin) {
        "gold" -> Color(0xFFFFD700)
        "diamond" -> Color(0xFF00FFFF)
        "platinum" -> Color(0xFFE5E4E2)
        else -> Color(0xFFFF0000)
    }
    Canvas(modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val sc = size.height * 0.42f
        val ca = cos(angle)
        val sa = sin(angle)
        drawCircle(
            brush = Brush.radialGradient(listOf(line.copy(alpha = 0.18f), Color.Transparent), center = Offset(cx, cy), radius = sc * 1.3f),
            radius = sc * 1.3f, center = Offset(cx, cy)
        )
        for (p in mesh) {
            var prev: Offset? = null
            var prevZ = 0f
            for (k in 0 until p.size / 3) {
                val x = p[k * 3]
                val y = p[k * 3 + 1]
                val z = p[k * 3 + 2]
                val xr = x * ca + z * sa
                val zr = -x * sa + z * ca
                val persp = 3.6f / (3.6f - zr)
                val o = Offset(cx + xr * sc * persp, cy - y * sc * persp)
                val pv = prev
                if (pv != null) {
                    val depth = (((zr + prevZ) / 2f) + 1f) / 2f
                    val a = (0.12f + 0.88f * depth).coerceIn(0f, 1f)
                    drawLine(line.copy(alpha = a * 0.9f), pv, o, strokeWidth = 1.3f)
                }
                prev = o
                prevZ = zr
            }
        }
    }
}
