package com.shadow.alpha

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@OptIn(FlowPreview::class)
class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val store = Store(ctx)
    private val _s = MutableStateFlow(store.load())
    val state = _s.asStateFlow()

    val now = MutableStateFlow(System.currentTimeMillis())
    val battery = MutableStateFlow(-1 to false)
    val aiBusy = MutableStateFlow(false)
    val todayMinutes = MutableStateFlow(-1)
    val topApps = MutableStateFlow<List<Pair<String, Int>>>(emptyList())
    val usagePermission = MutableStateFlow(false)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private val speaker = Speaker(ctx)
    private val vibrator: Vibrator? = ctx.getSystemService(Vibrator::class.java)
    private var rolling = false
    private var idSeq = System.currentTimeMillis()
    private fun newId(): Long = ++idSeq

    init {
        speaker.enabled = _s.value.voice
        viewModelScope.launch {
            _s.drop(1).debounce(400).collect { st -> withContext(Dispatchers.IO) { store.save(st) } }
        }
        viewModelScope.launch {
            while (true) {
                tick()
                delay(1000)
            }
        }
        scheduleHydration(_s.value.hydrationReminders)
        log("SYSTEM ONLINE. NEURAL LINK ESTABLISHED.", speak = false)
    }

    override fun onCleared() {
        speaker.shutdown()
        store.save(_s.value)
    }

    fun flush() = store.save(_s.value)

    fun onResume() {
        checkRollover()
        refreshUsage()
        readBattery()
    }

    // ───────────────────────── core state helpers ─────────────────────────

    private fun GameState.addLog(msg: String): GameState {
        val ts = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"))
        return copy(logs = (listOf(LogEntry(ts, msg)) + logs).take(25), logCounter = logCounter + 1)
    }

    private fun GameState.gain(amt: Double): GameState {
        val a = amt * xpMult
        var s = copy(xp = xp + a, totalXP = totalXP + a, dayXp = dayXp + a)
        while (s.xp >= s.xpLimit) {
            val nextLvl = s.lvl + 1
            s = s.copy(xp = s.xp - s.xpLimit, lvl = nextLvl).addLog("ASCENDED TO LEVEL $nextLvl")
        }
        return s
    }

    private fun GameState.deduct(amt: Double): GameState {
        val a = amt * xpMult
        return copy(
            xp = max(0.0, xp - a),
            totalXP = max(0.0, totalXP - a),
            dayXp = max(0.0, dayXp - a)
        )
    }

    private fun act(say: String? = null, f: (GameState) -> GameState) {
        _s.update(f)
        if (say != null) speaker.say(say)
        if (_s.value.logCounter >= 10) summarize()
    }

    private fun log(msg: String, speak: Boolean = true, f: (GameState) -> GameState = { it }) =
        act(if (speak) msg else null) { f(it).addLog(msg) }

    private fun toast(msg: String) {
        messages.tryEmit(msg)
    }

    private fun vib(ms: Long = 30) {
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun aiKeys(): List<String> = _s.value.let { listOf(it.key1, it.key2) }.filter { it.isNotBlank() }

    // ───────────────────────── tick / midnight / skins ─────────────────────────

    private fun tick() {
        val t = System.currentTimeMillis()
        now.value = t
        val st = _s.value
        if (st.skin != "default" && t > st.skinExpiry) {
            log("SKIN EXPIRED: REVERTING MATERIAL") { it.copy(skin = "default", xpMult = 1) }
        }
        if (st.timerEndAt in 1L..t) finishTimer()
        checkRollover()
        val sec = t / 1000
        if (sec % 5 == 0L) readBattery()
        if (sec % 60 == 0L) refreshUsage()
    }

    private fun readBattery() {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        if (level >= 0) battery.value = (level * 100 / scale) to charging
    }

    private fun checkRollover() {
        if (rolling) return
        val todayDate = LocalDate.now()
        val last = runCatching { LocalDate.parse(_s.value.lastReset) }.getOrNull()
        if (last == null) {
            _s.update { it.copy(lastReset = todayDate.toString()) }
            return
        }
        if (!todayDate.isAfter(last)) return
        rolling = true
        viewModelScope.launch {
            try {
                val st = _s.value
                var mins = -1
                if (st.stInitialized && ScreenTime.hasPermission(ctx)) {
                    mins = withContext(Dispatchers.IO) { ScreenTime.minutesForDate(ctx, last).first }
                }
                _s.update { finishDay(it, last, todayDate, mins) }
            } finally {
                rolling = false
            }
        }
    }

    private fun finishDay(s0: GameState, last: LocalDate, todayDate: LocalDate, mins: Int): GameState {
        var s = s0
        val notes = mutableListOf<String>()
        if (mins >= 0) {
            val limit = s.stTargetMin
            if (mins <= limit) {
                val bonus = (limit - mins) / 2 + 50 + (s.tasks.firstOrNull { it.isScreenTime && !it.done }?.xp ?: 0)
                s = s.gain(bonus.toDouble())
                notes += "SCREEN TIME OK: $mins/$limit MIN. +$bonus XP"
            } else {
                val pen = min(300, ((mins - limit) * 1.5).roundToInt())
                s = s.deduct(pen.toDouble())
                notes += "SCREEN TIME EXCEEDED: $mins/$limit MIN. -$pen XP"
            }
        }
        val rec = DayRecord(
            last.toString(), s.dayXp.roundToInt(), s.water,
            s.tasks.count { it.done }, s.tasks.size, s.salah.count { it }
        )
        val gap = ChronoUnit.DAYS.between(last, todayDate)
        val ok = s.dayXp >= 100 && gap == 1L
        val newStreak = if (ok) s.streak + 1 else 0
        s = s.copy(
            history = (s.history + rec).takeLast(60),
            streak = newStreak,
            bestStreak = max(s.bestStreak, newStreak),
            water = 0, lastW = 0, tasks = emptyList(), logs = emptyList(),
            logCounter = 0, logSummary = "", salah = List(5) { false },
            dayXp = 0.0, lastReset = todayDate.toString()
        )
        s = s.addLog("MIDNIGHT CYCLE: WATER, TASKS, LOGS & SUMMARY RESET")
        notes.forEach { s = s.addLog(it) }
        return s
    }

    // ───────────────────────── vitals ─────────────────────────

    fun logWater(ml: Int) {
        vib(20)
        log("INTAKE RECORDED: $ml ML") {
            it.copy(water = min(it.hydrationGoal, it.water + ml), lastW = ml).gain(ml / 10.0)
        }
    }

    fun undoWater() {
        val last = _s.value.lastW
        if (last <= 0) return
        log("INTAKE VOIDED: -$last ML") {
            it.copy(water = max(0, it.water - last), lastW = 0).deduct(last / 10.0)
        }
    }

    fun logMeal(text: String) {
        if (text.isBlank()) return
        log("NUTRIENT COMMITTED: ${text.trim().uppercase()}") { it.gain(50.0) }
    }

    // ───────────────────────── quests ─────────────────────────

    fun addTask(text: String, xp: Int) {
        if (text.isBlank()) return
        val low = text.lowercase()
        val isST = "screen time" in low || "screentime" in low
        val x = xp.coerceIn(5, 200)
        val t = Task(newId(), text.trim().uppercase(), x, isScreenTime = isST)
        log("OBJECTIVE DEPLOYED [+$x XP]: ${t.text}") { it.copy(tasks = listOf(t) + it.tasks) }
    }

    fun deleteTask(id: Long) = _s.update { st -> st.copy(tasks = st.tasks.filter { it.id != id }) }

    fun toggleTask(id: Long) {
        val t = _s.value.tasks.firstOrNull { it.id == id } ?: return
        if (!t.done && t.isScreenTime) {
            val m = todayMinutes.value
            val limit = _s.value.stTargetMin
            toast(
                if (m >= 0) "SETTLES AT MIDNIGHT. TODAY: $m / $limit MIN"
                else "SETTLES AT MIDNIGHT. GRANT USAGE ACCESS IN SCREEN TIME PANEL."
            )
            return
        }
        vib(40)
        if (!t.done) {
            log("OBJECTIVE SECURED: +${t.xp} XP") {
                it.copy(tasks = it.tasks.map { x -> if (x.id == id) x.copy(done = true) else x }).gain(t.xp.toDouble())
            }
        } else {
            log("OBJECTIVE REACTIVATED: -${t.xp} XP") {
                it.copy(tasks = it.tasks.map { x -> if (x.id == id) x.copy(done = false) else x }).deduct(t.xp.toDouble())
            }
        }
    }

    /** Verifies a photo with Gemini (needs internet + key). onDone(true) when the quest was completed. */
    fun submitProof(id: Long, uri: Uri, onDone: (Boolean) -> Unit) {
        val task = _s.value.tasks.firstOrNull { it.id == id }
        val keys = aiKeys()
        if (task == null) { onDone(false); return }
        if (keys.isEmpty()) { toast("NO AI KEY SET. USE THE 50% HONOR CLAIM OR ADD A KEY IN SETTINGS."); onDone(false); return }
        viewModelScope.launch {
            aiBusy.value = true
            var ok = false
            try {
                val bytes = withContext(Dispatchers.IO) { ImageUtil.jpegBytes(ctx, uri) }
                val rule = if (task.proofInstruction.isNotBlank()) "\nMandatory Photo Proof Requirement: \"${task.proofInstruction}\"." else ""
                val prompt = "Target Quest: \"${task.text}\".$rule\n" +
                    "Analyze this submitted image and determine whether it authentically proves the user completed this task per the proof guidelines above.\n" +
                    "Respond STRICTLY in valid JSON. If authentic proof: {\"valid\": true}  If not: {\"valid\": false, \"reason\": \"short explanation\"}"
                var answer: String? = null
                for (k in keys) {
                    try {
                        answer = Gemini.generate(k, Gemini.parts(Gemini.textPart(prompt), Gemini.imagePart(bytes, "image/jpeg")))
                        break
                    } catch (e: Exception) {
                    }
                }
                if (answer == null) {
                    log("PROOF CHECK FAILED: NO CONNECTION OR AI ERROR")
                } else {
                    val j = JSONObject(Gemini.stripFences(answer))
                    if (j.optBoolean("valid", false)) {
                        ok = true
                        vib(40)
                        log("QUEST VERIFIED BY AI: +${task.xp} XP RECEIVED") {
                            it.copy(tasks = it.tasks.map { x -> if (x.id == id) x.copy(done = true) else x }).gain(task.xp.toDouble())
                        }
                    } else {
                        log("PROOF REJECTED: ${j.optString("reason", "IMAGE DOES NOT PROVE COMPLETION").uppercase()}")
                    }
                }
            } catch (e: Exception) {
                log("ERROR PROCESSING QUEST PROOF")
            } finally {
                aiBusy.value = false
                onDone(ok)
            }
        }
    }

    /** Offline fallback: complete a proof-required quest on the honor system for half XP. */
    fun claimWithoutProof(id: Long) {
        val t = _s.value.tasks.firstOrNull { it.id == id && !it.done } ?: return
        val half = t.xp / 2.0
        log("UNVERIFIED CLAIM: +${half.roundToInt()} XP (50%)") {
            it.copy(tasks = it.tasks.map { x -> if (x.id == id) x.copy(done = true) else x }).gain(half)
        }
    }

    fun generateTasks() {
        viewModelScope.launch {
            aiBusy.value = true
            log("INITIATING TASK DEPLOYMENT...", speak = false)
            val st = _s.value
            var list: List<Task> = emptyList()
            for (k in aiKeys()) {
                try {
                    list = parseTasks(Gemini.generate(k, Gemini.parts(Gemini.textPart(taskPrompt(st)))))
                    if (list.isNotEmpty()) break
                } catch (e: Exception) {
                }
            }
            if (list.isEmpty()) {
                list = OfflineQuests.pick(st) { newId() }
                log("AI UNAVAILABLE: OFFLINE QUESTS DEPLOYED") { it.copy(tasks = list + it.tasks) }
            } else {
                log("AI TASKS DEPLOYED WITH DYNAMIC XP VALUES") { it.copy(tasks = list + it.tasks) }
            }
            aiBusy.value = false
        }
    }

    private fun taskPrompt(st: GameState): String {
        val lore = if (st.systemPrompt.isNotBlank()) "\nUSER LORE & CONTEXT:\n${st.systemPrompt}\n" else ""
        val summ = if (st.logSummary.isNotBlank()) "\nUSER ACCOMPLISHMENTS TODAY (SUMMARIZED):\n${st.logSummary}\n" else ""
        val stm = if (st.stInitialized) "\nSCREEN TIME MANDATE: Include 1 task strictly mandating keeping screen time under ${"%.1f".format(st.stTargetMin / 60f)} hours today.\n" else ""
        return "You are an absolute, mysterious, high-tech RPG System from a fantasy/drama webtoon (like Solo Leveling). You know exactly who the user is and what they are trying to achieve.$lore$summ$stm\n" +
            "INSTRUCTIONS:\n1. Generate 3 to 4 hyper-realistic, relatable daily quests tailored to the user's real-life scenario.\n" +
            "2. No absurd fantasy tasks. Practical, grounded, actionable, formatted like cyber system quests.\n" +
            "3. XP: light 10-20, medium 25-40, heavy 50-75.\n" +
            "4. requiresProof: true only if static photo evidence can prove it. If true, proofInstruction must say exactly what to capture. Otherwise requiresProof false and proofInstruction \"\".\n" +
            "5. Return ONLY a valid JSON array of objects with keys: \"text\" (string), \"xp\" (number 10-75), \"requiresProof\" (boolean), \"proofInstruction\" (string). No markdown."
    }

    private fun parseTasks(raw: String): List<Task> {
        val txt = Gemini.stripFences(raw)
        val arr = JSONArray(txt.substring(txt.indexOf('['), txt.lastIndexOf(']') + 1))
        val out = mutableListOf<Task>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val text = o.optString("text").trim()
            if (text.isEmpty()) continue
            val low = text.lowercase()
            out += Task(
                id = newId(), text = text.uppercase(), xp = o.optInt("xp", 20).coerceIn(5, 100),
                isScreenTime = "screen time" in low || "screentime" in low,
                requiresProof = o.optBoolean("requiresProof", false),
                proofInstruction = o.optString("proofInstruction", "")
            )
        }
        return out
    }

    // ───────────────────────── rituals ─────────────────────────

    private val beeper by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 25) }

    fun incTasbih() {
        _s.update { it.copy(tasbih = it.tasbih + 1).gain(0.1) }
        vib(25)
        try { beeper.startTone(ToneGenerator.TONE_PROP_BEEP, 40) } catch (e: Exception) { }
    }

    fun resetTasbih() = log("TASBIH COUNTER RESET", speak = false) { it.copy(tasbih = 0) }

    fun setSalah(i: Int, on: Boolean) {
        if (_s.value.salah[i] == on) return
        val name = listOf("FAJR", "DHUHR", "ASR", "MAGHRIB", "ISHA")[i]
        vib(30)
        log(if (on) "$name SALAH OBSERVED" else "$name SALAH REMOVED") {
            val n = it.copy(salah = it.salah.toMutableList().also { l -> l[i] = on })
            if (on) n.gain(20.0) else n.deduct(20.0)
        }
    }

    // ───────────────────────── market / contracts / timer ─────────────────────────

    fun buySkin(type: String, cost: Int, mult: Int) {
        if (_s.value.sp >= cost) {
            log("${type.uppercase()} SKIN APPLIED: ${mult}X XP GAIN") {
                it.copy(spentSP = it.spentSP + cost, skin = type, xpMult = mult, skinExpiry = System.currentTimeMillis() + 30 * 60 * 1000L)
            }
        } else log("INSUFFICIENT SP")
    }

    fun timerRemaining(s: GameState, t: Long): Int =
        if (s.timerEndAt > 0) max(0, ((s.timerEndAt - t + 999) / 1000).toInt()) else s.timerPaused

    fun initStake(type: String, cost: Int, reward: Int) {
        val st = _s.value
        when {
            st.contract != null -> log("A BOND IS ALREADY ACTIVE")
            timerRemaining(st, System.currentTimeMillis()) <= 0 -> log("TIMER NOT SET")
            st.sp < cost -> log("INSUFFICIENT SP FOR BOND")
            else -> log("BOND COMMITTED: ${type.uppercase()} AT $cost SP") {
                it.copy(spentSP = it.spentSP + cost, contract = Contract(type, cost, reward))
            }
        }
    }

    fun igniteTimer(minutes: Int) {
        val st = _s.value
        val t = System.currentTimeMillis()
        when {
            st.timerEndAt > 0 -> {
                val rem = timerRemaining(st, t)
                TimerReceiver.cancel(ctx)
                log("CHRONO CYCLE PAUSED") { it.copy(timerEndAt = 0, timerPaused = rem) }
            }
            st.timerPaused > 0 -> {
                val end = t + st.timerPaused * 1000L
                TimerReceiver.schedule(ctx, end)
                log("CHRONO CYCLE RESUMED") { it.copy(timerEndAt = end, timerPaused = 0) }
            }
            minutes > 0 -> {
                val end = t + minutes * 60_000L
                TimerReceiver.schedule(ctx, end)
                log("CHRONO CYCLE IGNITED: $minutes MINUTES") { it.copy(timerEndAt = end, timerPaused = 0) }
            }
        }
    }

    fun resetTimer() {
        val st = _s.value
        val active = st.timerEndAt > 0 || st.timerPaused > 0
        TimerReceiver.cancel(ctx)
        if (active && st.contract != null) {
            log("CHRONO ABORTED: BOND FORFEITED (${st.contract.cost} SP LOST)") {
                it.copy(timerEndAt = 0, timerPaused = 0, contract = null)
            }
        } else {
            log("CHRONO TIMER ABORTED") { it.copy(timerEndAt = 0, timerPaused = 0) }
        }
    }

    private fun finishTimer() {
        vib(200)
        val c = _s.value.contract
        if (c != null) {
            log("BOND SECURED: +${c.reward} XP RECEIVED") {
                it.copy(timerEndAt = 0, timerPaused = 0, contract = null, spentSP = it.spentSP - c.cost)
                    .gain(c.reward.toDouble())
            }
        }
        log("CHRONO CYCLE COMPLETE") { it.copy(timerEndAt = 0, timerPaused = 0) }
    }

    // ───────────────────────── notes / archive ─────────────────────────

    fun addNote(text: String, uri: Uri?) {
        if (text.isBlank() && uri == null) return
        viewModelScope.launch {
            var name: String? = null
            var path: String? = null
            var mime: String? = null
            if (uri != null) {
                withContext(Dispatchers.IO) {
                    try {
                        mime = ctx.contentResolver.getType(uri)
                        name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                            if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).let { i -> if (i >= 0) c.getString(i) else null } else null
                        } ?: "file"
                        val dest = File(store.mediaDir(), "${System.currentTimeMillis()}_${name!!.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                        ctx.contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use { input.copyTo(it) } }
                        path = dest.absolutePath
                    } catch (e: Exception) {
                        path = null
                    }
                }
            }
            val note = Note(
                System.currentTimeMillis(), text.trim(),
                java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date()),
                name, path, mime
            )
            log("DATA ARCHIVED TO NEURAL CORE", speak = false) { it.copy(notes = listOf(note) + it.notes) }
        }
    }

    fun deleteNote(id: Long) {
        val n = _s.value.notes.firstOrNull { it.id == id } ?: return
        n.filePath?.let { File(it).delete() }
        _s.update { st -> st.copy(notes = st.notes.filter { it.id != id }) }
    }

    // ───────────────────────── AI chat / summary ─────────────────────────

    fun ask(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        log("SIGNAL: ${q.uppercase()}", speak = false)
        viewModelScope.launch {
            aiBusy.value = true
            val st = _s.value
            val keys = aiKeys()
            var reply: String? = null
            if (keys.isNotEmpty()) {
                val prompt = buildString {
                    if (st.systemPrompt.isNotBlank()) append("User Context/Lore:\n${st.systemPrompt}\n")
                    if (st.logSummary.isNotBlank()) append("User Activity Today (Summarized Logs):\n${st.logSummary}\n")
                    if (st.logs.isNotEmpty()) append("Recent System Logs:\n" + st.logs.joinToString("\n") { "[${it.ts}] ${it.text}" } + "\n")
                    append(
                        if (st.tasks.isEmpty()) "Current System Quests/Tasks: None\n"
                        else "Current System Quests/Tasks:\n" + st.tasks.mapIndexed { i, t ->
                            "#${i + 1}: ${t.text} (XP: ${t.xp}, Status: ${if (t.done) "Completed" else "Pending"}, Requires Photo Proof: ${t.requiresProof}${if (t.requiresProof) ", Proof Rule: \"${t.proofInstruction}\"" else ""})"
                        }.joinToString("\n") + "\n"
                    )
                    if (st.stInitialized) append("Screen Time Baseline:\n${st.stHistory}\nDaily limit: ${"%.1f".format(st.stTargetMin / 60f)} hours.\n")
                    append("Persona: Dark Shadow/System Node. Act strictly as the authoritative RPG System or Shadow guide from webtoon/drama series. Radical candor, cold precision, witty clarity. You know all current tasks (#1, #2...), proof requirements and logs. Brief response (max 20 words). User Query: $q")
                }
                for (k in keys) {
                    try { reply = Gemini.generate(k, Gemini.parts(Gemini.textPart(prompt))).trim(); break } catch (e: Exception) { }
                }
            }
            log(reply ?: "[OFFLINE] ${offlineReply(st)}")
            aiBusy.value = false
        }
    }

    private fun offlineReply(s: GameState): String {
        val pending = s.tasks.count { !it.done }
        return when {
            pending > 0 -> "$pending OBJECTIVES UNRESOLVED. EXECUTE."
            s.water < s.hydrationGoal / 2 -> "HYDRATION BELOW HALF. DRINK."
            s.tasks.isEmpty() -> "NO OBJECTIVES ACTIVE. DEPLOY NEW QUESTS."
            else -> "ALL OBJECTIVES CLEARED. HOLD THE LINE."
        }
    }

    private fun summarize() {
        val st = _s.value
        _s.update { it.copy(logCounter = 0) }
        val key = st.key2.ifBlank { st.key1 }
        if (key.isBlank() || st.logs.isEmpty()) return
        val prompt = "System Logs:\n" + st.logs.joinToString("\n") { "[${it.ts}] ${it.text}" } +
            "\n\nTask: Synthesize these log entries into a concise, high-level summary paragraph describing what the user accomplished or did today. Existing summary context: ${st.logSummary.ifBlank { "None" }}"
        viewModelScope.launch {
            try {
                val r = Gemini.generate(key, Gemini.parts(Gemini.textPart(prompt))).trim()
                _s.update { it.copy(logSummary = r) }
            } catch (e: Exception) {
            }
        }
    }

    // ───────────────────────── screen time ─────────────────────────

    fun refreshUsage() {
        val perm = ScreenTime.hasPermission(ctx)
        usagePermission.value = perm
        if (!perm) { todayMinutes.value = -1; return }
        viewModelScope.launch {
            val (m, apps) = withContext(Dispatchers.IO) { ScreenTime.minutesForDate(ctx, LocalDate.now()) }
            todayMinutes.value = m
            topApps.value = apps
        }
    }

    fun initScreenTime() {
        if (!ScreenTime.hasPermission(ctx)) { toast("GRANT USAGE ACCESS FIRST"); return }
        viewModelScope.launch {
            val days = withContext(Dispatchers.IO) {
                (1..5).map { d -> ScreenTime.minutesForDate(ctx, LocalDate.now().minusDays(d.toLong())).first }
            }
            val withData = days.filter { it > 0 }
            if (withData.isEmpty()) { toast("NO USAGE DATA YET. TRY AGAIN LATER."); return@launch }
            val avg = withData.average()
            val target = max(60, ((avg * 0.85) / 10).roundToInt() * 10)
            val hist = days.mapIndexed { i, m -> "D-${i + 1}: ${m / 60}h${m % 60}m" }.joinToString(", ")
            log("SCREEN TIME BASELINE SET. TARGET ${"%.1f".format(target / 60f)} HOURS") {
                it.copy(stInitialized = true, stHistory = hist, stTargetMin = target)
            }
        }
    }

    fun setScreenTarget(minutes: Int) {
        if (minutes < 15) return
        log("SCREEN TIME LIMIT SET: $minutes MIN", speak = false) { it.copy(stTargetMin = minutes, stInitialized = true) }
    }

    // ───────────────────────── settings / data ─────────────────────────

    fun saveSettings(
        k1: String, k2: String, prompt: String, webhook: String,
        goal: Int, reminders: Boolean, voice: Boolean, pin: String
    ) {
        speaker.enabled = voice
        scheduleHydration(reminders)
        log("SYSTEM LORE & SETTINGS UPDATED", speak = false) {
            it.copy(
                key1 = k1.trim(), key2 = k2.trim(), systemPrompt = prompt.trim(), webhookUrl = webhook.trim(),
                hydrationGoal = goal.coerceIn(500, 10000), hydrationReminders = reminders, voice = voice,
                pin = pin.ifBlank { "1420" }
            )
        }
    }

    fun testKey(key: String) {
        if (key.isBlank()) return
        viewModelScope.launch {
            toast(
                try { Gemini.generate(key.trim(), Gemini.parts(Gemini.textPart("Reply with: OK"))); "KEY ACTIVE" }
                catch (e: Exception) { "KEY TEST FAILED (${e.message})" }
            )
        }
    }

    private fun scheduleHydration(on: Boolean) {
        val wm = WorkManager.getInstance(ctx)
        if (on) {
            wm.enqueueUniquePeriodicWork(
                "hydration", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<HydrationWorker>(2, TimeUnit.HOURS).build()
            )
        } else wm.cancelUniqueWork("hydration")
    }

    fun ping() {
        val url = _s.value.webhookUrl
        log("SECONDARY NODE PINGED", speak = false)
        if (url.startsWith("http")) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 5000; c.readTimeout = 5000
                    c.responseCode
                    c.disconnect()
                } catch (e: Exception) {
                }
            }
        }
    }

    /** API keys are never exported. Attached files are not included in the JSON. */
    fun exportJson(): String = JsonCfg.encodeToString(GameState.serializer(), _s.value.copy(key1 = "", key2 = ""))

    fun importJson(text: String): Boolean = try {
        val n = JsonCfg.decodeFromString(GameState.serializer(), text)
        _s.update { cur -> n.copy(key1 = cur.key1, key2 = cur.key2) }
        true
    } catch (e: Exception) {
        false
    }

    fun purge(pin: String): Boolean {
        if (pin != _s.value.pin) {
            log("PURGE FAILED: INVALID CODE")
            return false
        }
        TimerReceiver.cancel(ctx)
        store.wipe()
        _s.value = GameState(lastReset = today())
        log("SYSTEM PURGED", speak = false)
        return true
    }
}
