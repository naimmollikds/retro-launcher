package com.shadow.alpha

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val id: Long,
    val text: String,
    val xp: Int = 20,
    val done: Boolean = false,
    val isScreenTime: Boolean = false,
    val requiresProof: Boolean = false,
    val proofInstruction: String = ""
)

@Serializable
data class LogEntry(val ts: String, val text: String)

@Serializable
data class Note(
    val id: Long,
    val text: String,
    val date: String,
    val fileName: String? = null,
    val filePath: String? = null,
    val mime: String? = null
)

@Serializable
data class Contract(val type: String, val cost: Int, val reward: Int)

@Serializable
data class DayRecord(
    val date: String,
    val xp: Int,
    val water: Int,
    val tasksDone: Int,
    val tasksTotal: Int,
    val salah: Int
)

@Serializable
data class GameState(
    val lvl: Int = 1,
    val xp: Double = 0.0,
    val totalXP: Double = 0.0,
    val spentSP: Double = 0.0,
    val dayXp: Double = 0.0,
    val water: Int = 0,
    val lastW: Int = 0,
    val tasks: List<Task> = emptyList(),
    val logs: List<LogEntry> = emptyList(),
    val notes: List<Note> = emptyList(),
    val contract: Contract? = null,
    val tasbih: Int = 0,
    val salah: List<Boolean> = List(5) { false },
    val lastReset: String = "",
    val skin: String = "default",
    val xpMult: Int = 1,
    val skinExpiry: Long = 0,
    // Chrono timer (survives app restarts): either running (timerEndAt > 0) or paused (timerPaused > 0)
    val timerEndAt: Long = 0,
    val timerPaused: Int = 0,
    // AI (optional, needs internet)
    val key1: String = "",
    val key2: String = "",
    val systemPrompt: String = "",
    val logCounter: Int = 0,
    val logSummary: String = "",
    // Screen time (offline, via Usage Access)
    val stInitialized: Boolean = false,
    val stHistory: String = "",
    val stTargetMin: Int = 240,
    // Stats
    val history: List<DayRecord> = emptyList(),
    val streak: Int = 0,
    val bestStreak: Int = 0,
    // Settings
    val hydrationGoal: Int = 4000,
    val hydrationReminders: Boolean = true,
    val voice: Boolean = true,
    val webhookUrl: String = "",
    val pin: String = "1420"
)

val GameState.sp: Double get() = totalXP / 10.0 - spentSP
val GameState.xpLimit: Int get() = lvl * 500
val GameState.spLimit: Int get() = lvl * 50
