package com.shadow.alpha

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.time.LocalDate
import java.time.ZoneId

/**
 * Offline screen time using Android's own Usage Access data. No screenshots, no AI, no internet.
 * The user must grant "Usage access" once in system settings.
 */
object ScreenTime {
    fun hasPermission(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Total foreground minutes for a calendar day plus the top apps (label, minutes). */
    fun minutesForDate(ctx: Context, date: LocalDate): Pair<Int, List<Pair<String, Int>>> {
        val usm = ctx.getSystemService(UsageStatsManager::class.java) ?: return 0 to emptyList()
        val zone = ZoneId.systemDefault()
        val start = date.atStartOfDay(zone).toInstant().toEpochMilli()
        val end = minOf(date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(), System.currentTimeMillis())
        if (end <= start) return 0 to emptyList()

        val home = launcherPackages(ctx)
        val perApp = usm.queryAndAggregateUsageStats(start, end)
            .filter { it.value.totalTimeInForeground > 0 && it.key !in home && it.key != ctx.packageName }
            .map { it.key to (it.value.totalTimeInForeground / 60_000L).toInt() }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
        val total = perApp.sumOf { it.second }
        return total to perApp.take(5).map { label(ctx, it.first) to it.second }
    }

    private fun launcherPackages(ctx: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return ctx.packageManager.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
            .map { it.activityInfo.packageName }.toSet()
    }

    private fun label(ctx: Context, pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.')
    }
}
