package com.shadow.alpha

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.tts.TextToSpeech
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.max

/** Offline text-to-speech (uses the voice data installed on the phone). */
class Speaker(ctx: Context) : TextToSpeech.OnInitListener {
    private var ready = false
    var enabled = true
    private val tts = TextToSpeech(ctx.applicationContext, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            tts.setPitch(0.6f)
            tts.setSpeechRate(1.1f)
            tts.language = Locale.getDefault()
        }
    }

    fun say(text: String) {
        if (!enabled || !ready) return
        val spoken = text.replace("ML", "milliliters", ignoreCase = false).replace('_', ' ')
        tts.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "shadow")
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}

object ImageUtil {
    /** Downscaled JPEG bytes (keeps AI requests small). */
    fun jpegBytes(ctx: Context, uri: Uri, maxDim: Int = 1280): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalArgumentException("unreadable image")
        return ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
    }

    fun thumb(path: String, maxDim: Int = 600): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
        return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}

/** Offline quest pool used when the AI is unavailable. */
object OfflineQuests {
    private data class Q(val text: String, val xp: Int, val proof: String = "")

    private val pool = listOf(
        Q("READ 20 PAGES OF A BOOK", 30, "Photo of the open book page with today's date on a note beside it."),
        Q("DO 20 PUSH-UPS", 20),
        Q("WALK 15 MINUTES OUTDOORS", 25),
        Q("25 MINUTES OF DISTRACTION-FREE DEEP WORK", 40),
        Q("WRITE TOMORROW'S TOP 3 PRIORITIES", 15, "Photo of the written list with today's date."),
        Q("TIDY YOUR DESK OR ROOM", 20, "Photo of the tidy space."),
        Q("STRETCH FOR 10 MINUTES", 20),
        Q("NO SOCIAL MEDIA FOR THE FIRST HOUR AFTER WAKING", 30),
        Q("REVIEW AND SORT TODAY'S MESSAGES AND TASKS", 15),
        Q("LEARN ONE NEW THING AND NOTE IT IN THE ARCHIVE", 35),
        Q("COMPLETE 100 TASBIH COUNTS", 20),
        Q("DRINK A FULL GLASS OF WATER NOW", 10)
    )

    fun pick(s: GameState, newId: () -> Long): List<Task> {
        val existing = s.tasks.map { it.text }.toSet()
        val out = pool.filter { it.text !in existing }.shuffled().take(3).map {
            Task(newId(), it.text, it.xp, requiresProof = it.proof.isNotEmpty(), proofInstruction = it.proof)
        }.toMutableList()
        if (s.stInitialized && s.tasks.none { it.isScreenTime }) {
            val h = "%.1f".format(s.stTargetMin / 60f)
            out += Task(newId(), "KEEP SCREEN TIME UNDER $h HOURS TODAY", 30, isScreenTime = true)
        }
        return out
    }
}
