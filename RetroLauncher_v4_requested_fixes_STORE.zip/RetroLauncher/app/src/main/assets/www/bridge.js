/*
 * Native bridge for the Retro Launcher.
 * Loaded AFTER the original UI script. Keeps the look & feel, but swaps the
 * demo data/behaviour for real Android features:
 *   WhatsApp messages + replies (AI-rated importance), phone contacts, real calls,
 *   WhatsApp calls, alarms/reminders/schedule notifications, a real full-screen browser,
 *   plug-in web apps and the phone's installed apps.
 * Outside the Android app (plain browser) it does nothing, so the demo still works.
 */
(function () {
  'use strict';
  if (!window.nativeBridge) { console.info('[bridge] not inside launcher, mock mode'); return; }

  const $ = (id) => document.getElementById(id);
  const post = (o) => nativeBridge.postMessage(JSON.stringify(o));
  const pending = {};
  let seq = 0;
  let contactsDenied = false;
  let activeMessagePlatform = "WhatsApp";

  // ---------- helpers ----------
  // Real text is untrusted: the UI injects it via innerHTML, so escape it.
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // Names go inside inline onclick="fn('NAME')": strip anything that could break out.
  const safeName = (s) => String(s).replace(/['"`\\<>&${}\u0000-\u001f]/g, '').trim().slice(0, 40);
  const safePhone = (s) => String(s).replace(/[^0-9+*#() -]/g, '').trim();
  const decode = (str) => { const t = document.createElement('textarea'); t.innerHTML = str; return t.value; };

  function fmt(ms) {
    const d = new Date(ms);
    let h = d.getHours();
    const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return h + ':' + m + ' ' + ap;
  }
  function fmtDateTime(ms) {
    const d = new Date(ms);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + fmt(ms);
  }

  const toUi = (m) => ({
    sender: esc(m.sender), text: esc(m.text), time: fmt(m.timeMs), ts: m.timeMs,
    type: m.type, platform: m.platform || 'WhatsApp', urgent: !!m.urgent, id: m.id, reason: esc(m.reason || ''), checked: !!m.checked
  });

  function modalTitle() {
    const modal = $('app-modal');
    const open = modal && !modal.classList.contains('translate-y-full');
    return open ? (($('modal-title') || {}).innerText || '') : '';
  }

  // Don't keep a second copy of message content in WebView localStorage.
  const origSet = Storage.prototype.setItem;
  Storage.prototype.setItem = function (k, v) {
    if (k === 'whatsapp_chat_threads') return;
    return origSet.call(this, k, v);
  };

  // =====================================================================
  // 1. WhatsApp threads
  // =====================================================================
  const origRender = window.renderRecentNotifications;
  window.renderRecentNotifications = function () {
    origRender();
    // The banner uses innerText; decode our escaped entities back to plain text.
    const el = $('ai-summary-text');
    if (el) el.innerText = decode(el.innerText);
  };

  chatThreads = {};
  renderRecentNotifications();

  function refreshUi() {
    renderRecentNotifications();
    const title = modalTitle();
    if (title.includes('WHATSAPP')) {
      const input = $('whatsapp-reply-input');
      if (input) {
        const v = input.value, focused = document.activeElement === input, pos = input.selectionStart;
        renderWhatsAppConversation(activeWhatsAppContact);
        const n = $('whatsapp-reply-input');
        if (n) {
          n.value = v;
          if (focused) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} }
        }
      } else if ($('whatsapp-chat-container')) {
        renderWhatsAppContactsOverview();
      }
    } else if (title.includes('IMPORTANT')) {
      renderImportantModal();
    }
  }

  function nativeSend(contact, text, platform = "WhatsApp") {
    return new Promise((resolve) => {
      const id = ++seq;
      pending[id] = (ok, err) => resolve({ ok: ok, err: err });
      post({ op: 'sendReply', id: id, contact: contact, text: text, platform: platform });
      setTimeout(() => {
        if (pending[id]) { delete pending[id]; resolve({ ok: false, err: 'Reply timed out' }); }
      }, 8000);
    });
  }

  window.sendWhatsAppMessage = function (contactName, messageText, platform = "WhatsApp") {
    if (!messageText || !messageText.trim()) return Promise.resolve(false);
    return nativeSend(contactName, messageText.trim(), platform).then((r) => {
      if (!r.ok) showToast('✗ ' + r.err);
      return r.ok;
    });
  };

  window.executeWhatsAppReply = async function () {
    const input = $('whatsapp-reply-input');
    if (!input || !input.value.trim()) return;
    const message = input.value.trim();
    // Clear immediately after the user sends, so the next message can be typed at once.
    input.value = '';
    input.focus();
    const ok = await window.sendWhatsAppMessage(activeWhatsAppContact, message, activeMessagePlatform);
    if (ok) showToast('✓ Replied via ' + activeMessagePlatform);
  };

  window.clearRecentChats = function () {
    if (!window.confirm('Clear all saved recent WhatsApp and Messenger chats from this launcher?')) return;
    post({ op: 'clearRecentChats' });
  };
  window.openMessageThread = function(contact, platform) {
    activeMessagePlatform = platform === 'Messenger' ? 'Messenger' : 'WhatsApp';
    window.activeMessagePlatform = activeMessagePlatform;
    activeWhatsAppContact = contact;
    renderWhatsAppConversation(contact);
  };

  function allowedReply(contact, platform) {
    const rules = String(window.aiInstructions || '').split(/\n/).map(x => x.trim());
    const line = rules.find(x => /^ALLOW_REPLY\s*:/i.test(x));
    if (!line) return false; // fail closed: never auto-reply without an explicit allow-list
    const entries = line.replace(/^ALLOW_REPLY\s*:/i, '').split(/[;,]/).map(x => x.trim());
    return entries.some(x => {
      const m = x.match(/^(WhatsApp|Messenger)\s*:\s*(.+)$/i);
      if (m) return m[1].toLowerCase() === platform.toLowerCase() && m[2].toLowerCase() === contact.toLowerCase();
      return x.toLowerCase() === contact.toLowerCase();
    });
  }

  window.isReplyAllowed = allowedReply;

  // =====================================================================
  // 3. Contacts + real phone calls
  // =====================================================================
  contactsList = [];

  const toContact = (c, i) => {
    const phone = safePhone(c.phone);
    return { id: i + 1, name: safeName(c.name) || phone, phone: phone,
             role: safeName(c.role) || 'Phone', digits: phone.replace(/\D/g, '') };
  };

  function searchContacts(q, limit) {
    const s = String(q || '').trim().toLowerCase();
    const d = s.replace(/\D/g, '');
    const numeric = d.length > 0 && /^[0-9+*#() -]+$/.test(s);
    const list = []; let total = 0;
    for (const c of contactsList) {
      const hit = !s || c.name.toLowerCase().includes(s) ||
        (numeric && c.digits.includes(d)) || c.role.toLowerCase().includes(s);
      if (hit) { total++; if (list.length < limit) list.push(c); }
    }
    return { list: list, total: total };
  }

  window.callNumber = function (n) {
    const num = safePhone(n);
    if (!num) { showToast('Enter a number first'); return; }
    post({ op: 'call', number: num });
  };

  // Every "call" button in the UI (dial pad CALL, contact rows, chat header) lands here.
  window.startWhatsAppCall = function (nameOrNumber, role) {
    const v = String(nameOrNumber || '').trim();
    if (!v || v === 'Unknown Number') { showToast('Type a number or pick a contact'); return; }
    if (/^[0-9+*#() -]+$/.test(v)) { window.callNumber(v); return; }
    const exact = contactsList.filter((c) => c.name.toLowerCase() === v.toLowerCase());
    const found = exact.length ? exact : searchContacts(v, 2).list;
    if (found.length === 1 || exact.length >= 1) window.callNumber(found[0].phone);
    else if (found.length > 1) showToast('Several matches: pick one from the list');
    else showToast('No phone number found for ' + v);
  };

  window.updateDialPadDisplay = function (updateSearchInput) {
    if (updateSearchInput === undefined) updateSearchInput = true;
    const display = $('dial-display'), searchInput = $('dial-contact-search'), box = $('dial-contact-matches');
    if (display) display.innerText = dialBuffer || '---';
    if (searchInput && updateSearchInput) searchInput.value = dialBuffer;
    if (!box) return;
    const r = searchContacts(dialBuffer, 30);
    if (!r.list.length) {
      box.innerHTML = `<div class="p-2 text-center text-xs text-gray-500 font-mono italic">
        ${contactsDenied ? 'Contacts permission is off. Open PEOPLE to allow it.' : 'No contacts match "' + esc(dialBuffer) + '". Press CALL to dial number directly.'}</div>`;
      return;
    }
    box.innerHTML = r.list.map((c) => `
      <div class="p-2 bg-white rounded border border-gray-300 flex justify-between items-center active:bg-gray-100">
        <div class="min-w-0 flex-1 pr-2">
          <p class="font-bold text-xs text-gray-900 truncate">${c.name}</p>
          <p class="text-[10px] text-gray-500 font-mono">${c.phone} • ${c.role}</p>
        </div>
        <div class="flex gap-1 shrink-0">
          <button onclick="callNumber('${c.phone}')" class="bg-emerald-700 text-white text-[10px] px-2 py-1 rounded font-mono font-bold"><i class="fa-solid fa-phone"></i></button>
          <button onclick="typeDialFromContact('${c.phone}')" class="bg-gray-800 text-white text-[10px] px-2 py-1 rounded font-mono font-bold">SELECT</button>
        </div>
      </div>`).join('');
  };

  window.renderContactRows = function (q) {
    const box = $('contacts-rows'), hint = $('contacts-hint');
    if (!box) return;
    const r = searchContacts(q, 40);
    if (hint) {
      hint.innerHTML = contactsDenied
        ? `Contacts permission is off. <button onclick="post_requestPerms()" class="underline font-bold text-emerald-800">ALLOW CONTACTS</button>`
        : `${r.total} contact${r.total === 1 ? '' : 's'}${r.total > r.list.length ? ' (showing ' + r.list.length + ', type to narrow)' : ''}`;
    }
    box.innerHTML = r.list.map((c) => `
      <div class="p-2 bg-white rounded-lg border border-gray-400 flex justify-between items-center">
        <div class="min-w-0 flex-1 pr-2">
          <p class="font-bold text-xs text-gray-900 truncate">${c.name}</p>
          <p class="text-[10px] text-gray-500 font-mono">${c.phone} • ${c.role}</p>
        </div>
        <div class="flex gap-1 shrink-0">
          <button onclick="openWhatsAppChatFromFeed('${c.name}')" title="WhatsApp chat" class="bg-emerald-800 text-white text-xs px-2 py-1 rounded font-mono font-bold"><i class="fa-brands fa-whatsapp"></i></button>
          <button onclick="waCall('${c.name}', false, '${c.phone}')" title="WhatsApp call" class="bg-emerald-700 text-white text-xs px-2 py-1 rounded font-mono font-bold"><i class="fa-brands fa-whatsapp"></i><i class="fa-solid fa-phone text-[8px] ml-0.5"></i></button>
          <button onclick="callNumber('${c.phone}')" title="Phone call" class="bg-gray-800 text-white text-xs px-2 py-1 rounded font-mono font-bold"><i class="fa-solid fa-phone"></i></button>
        </div>
      </div>`).join('');
  };
  window.post_requestPerms = function () { post({ op: 'requestPerms' }); };

  // Real WhatsApp voice/video call (uses WhatsApp's own entry in the phone's contacts).
  // If that is not possible for this chat, the phone opens the real WhatsApp app instead.
  window.waCall = function (name, video, number) {
    const n = String(name || '').trim();
    let num = number ? safePhone(number) : '';
    if (!num) {
      if (/^[0-9+*#() -]+$/.test(n)) num = safePhone(n);
      else {
        const hit = contactsList.find((c) => c.name.toLowerCase() === n.toLowerCase());
        if (hit) num = hit.phone;
      }
    }
    if (!n && !num) { showToast('Pick a contact first'); return; }
    showToast(video ? 'Starting WhatsApp video call...' : 'Starting WhatsApp call...');
    post({ op: 'waCall', name: n, number: num, video: !!video });
  };

  function renderContactsModal() {
    const body = $('modal-body');
    if (!body) return;
    body.innerHTML = `<div class="space-y-2 font-sans">
      <input id="contacts-search" type="text" placeholder="🔍 Search name or number..." oninput="renderContactRows(this.value)" class="w-full p-1.5 border border-gray-400 rounded-lg text-xs font-sans focus:outline-none bg-white">
      <p id="contacts-hint" class="text-[10px] text-gray-600 font-mono"></p>
      <div id="contacts-rows" class="space-y-2"></div></div>`;
    renderContactRows('');
  }

  // =====================================================================
  // 4. Alarms, reminders, schedule -> real Android alarms/notifications
  // =====================================================================
  function parseTime(s) {
    const m = String(s || '').trim().match(/^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?/i);
    if (!m) return null;
    let h = parseInt(m[1], 10);
    const mi = parseInt(m[2] || '0', 10);
    const ap = (m[3] || '').toUpperCase();
    if (ap === 'PM' && h < 12) h += 12;
    if (ap === 'AM' && h === 12) h = 0;
    if (h > 23 || mi > 59) return null;
    return { h: h, m: mi };
  }

  function buildTimers() {
    const items = [];
    const now = Date.now();
    alarmsList.forEach((a) => {
      if (!a.active) return;
      const t = parseTime(a.time);
      if (!t) return;
      items.push({ key: 'alarm:' + a.id, kind: 'alarm', title: a.label || 'Alarm', body: a.time,
                   hour: t.h, minute: t.m, atMs: 0, repeat: true });
    });
    remindersList.forEach((r) => {
      if (r.done || !r.at || r.at <= now) return;
      items.push({ key: 'rem:' + r.id, kind: 'reminder', title: '📝 Reminder', body: String(r.text),
                   hour: 0, minute: 0, atMs: r.at, repeat: false });
    });
    scheduleList.forEach((s) => {
      const t = parseTime(s.time);
      if (!t) return;
      let dt;
      if (s.date) {
        const p = String(s.date).split('-').map(Number);
        dt = new Date(p[0], p[1] - 1, p[2], t.h, t.m);
      } else {
        const b = new Date();
        dt = new Date(b.getFullYear(), b.getMonth(), b.getDate(), t.h, t.m);
      }
      const at = dt.getTime() - 10 * 60000;          // alert 10 minutes before
      if (at <= now) return;
      items.push({ key: 'sch:' + s.id, kind: 'schedule', title: '📅 ' + s.title,
                   body: s.time + ' • ' + s.detail + ' (starts in 10 min)',
                   hour: 0, minute: 0, atMs: at, repeat: false });
    });
    return items;
  }
  function syncTimers() { post({ op: 'syncTimers', items: buildTimers() }); }
  window.syncTimersNow = function() {
    return new Promise(resolve => {
      const id = ++seq;
      pending[id] = (ok, err, count) => resolve({ok, err, count});
      post({op:'syncTimers', id, items:buildTimers()});
      setTimeout(() => { if (pending[id]) { delete pending[id]; resolve({ok:false, err:'Android did not confirm alarm scheduling'}); } }, 8000);
    });
  };
  syncTimers();

  // Every add/remove/toggle already calls persistLauncherState(): hook it.
  const origPersist = window.persistLauncherState;
  window.persistLauncherState = function () { origPersist(); syncTimers(); };

  // Reminders: optional date+time
  window.addReminderItem = function () {
    const input = $('new-reminder-text');
    if (!input || !input.value.trim()) return;
    const atEl = $('new-reminder-at');
    const at = atEl && atEl.value ? new Date(atEl.value).getTime() : 0;
    remindersList.push({ id: Date.now(), text: input.value.trim(), done: false, at: at || 0 });
    input.value = '';
    if (atEl) atEl.value = '';
    persistLauncherState();
    renderRemindersList();
    showToast(at ? '✓ Reminder set for ' + fmtDateTime(at) : '✓ Reminder saved!');
  };

  window.renderRemindersList = function () {
    const container = $('reminders-render-container');
    if (!container) return;
    if (remindersList.length === 0) {
      container.innerHTML = `<div class="text-xs text-gray-500 font-mono italic p-2 text-center">No active reminders. Add one below!</div>`;
      return;
    }
    container.innerHTML = remindersList.map((r) => `
      <div class="p-2 bg-white border border-gray-300 rounded-lg flex justify-between items-center text-xs">
        <div class="flex items-center gap-2 flex-1 min-w-0 mr-2">
          <input type="checkbox" ${r.done ? 'checked' : ''} onchange="toggleReminderDone(${r.id})" class="w-4 h-4 accent-gray-800 cursor-pointer shrink-0">
          <div class="min-w-0">
            <span class="${r.done ? 'line-through text-gray-400' : 'text-gray-900 font-bold'} font-sans truncate block">${r.text}</span>
            ${r.at ? `<span class="text-[9px] font-mono text-emerald-800">⏰ ${fmtDateTime(r.at)}</span>` : ''}
          </div>
        </div>
        <button onclick="removeReminder(${r.id})" class="text-red-700 hover:text-red-900 px-2 py-0.5 border border-red-200 bg-red-50 rounded text-xs shrink-0">
          <i class="fa-solid fa-trash text-[10px]"></i>
        </button>
      </div>`).join('');
  };

  // Schedule: optional date
  window.addScheduleItem = function () {
    const title = ($('new-schedule-title') || {}).value;
    const time = ($('new-schedule-time') || {}).value || 'Today';
    const detail = ($('new-schedule-detail') || {}).value || 'General Event';
    const date = ($('new-schedule-date') || {}).value || '';
    if (!title) return;
    scheduleList.push({ id: Date.now(), time: time, title: title, detail: detail, date: date });
    persistLauncherState();
    renderScheduleList();
    showToast(parseTime(time) ? '✓ Schedule added! Alert 10 min before.' : '✓ Added (no alert: use a time like 10:00 AM)');
  };

  window.renderScheduleList = function () {
    const container = $('schedule-render-container');
    if (!container) return;
    container.innerHTML = scheduleList.map((s) => `
      <div class="p-2 bg-white border border-gray-400 rounded-lg flex justify-between items-start">
        <div class="min-w-0 flex-1 pr-2">
          <span class="font-bold text-emerald-800 text-xs block font-mono">${s.date ? s.date + ' • ' : ''}${s.time}</span>
          <p class="font-sans font-bold text-gray-900 text-xs truncate">${s.title}</p>
          <p class="text-[10px] text-gray-500">${s.detail}</p>
        </div>
        <button onclick="removeSchedule(${s.id})" class="text-red-700 hover:text-red-900 px-1.5 py-0.5 border border-red-300 rounded bg-red-50 text-xs shrink-0">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>`).join('');
  };

  // Add the optional date/time inputs into the existing forms (same styling).
  function injectReminderTime() {
    const txt = $('new-reminder-text');
    if (!txt || $('new-reminder-at')) return;
    const row = txt.parentElement;
    const wrap = document.createElement('div');
    wrap.className = 'flex items-center gap-1 shrink-0 pt-1';
    wrap.innerHTML = `<span class="text-[10px] font-mono font-bold text-gray-700">REMIND AT:</span>
      <input id="new-reminder-at" type="datetime-local" class="flex-1 p-1 border border-gray-300 rounded text-[11px] font-mono bg-white">`;
    row.parentElement.insertBefore(wrap, row);
  }
  function injectScheduleDate() {
    const t = $('new-schedule-time');
    if (!t || $('new-schedule-date')) return;
    const row = t.parentElement;
    const d = document.createElement('input');
    d.id = 'new-schedule-date';
    d.type = 'date';
    d.className = 'w-full p-1.5 border border-gray-300 rounded text-xs font-mono bg-white';
    row.parentElement.insertBefore(d, row.nextSibling);
  }

  // =====================================================================
  // 5. Browser -> real full-screen WebView
  // =====================================================================
  const origBrowse = window.executeBrowserSearch;
  window.executeBrowserSearch = function (overrideQuery) {
    if (browserMode !== 'interactive') return origBrowse(overrideQuery);   // lite text mode unchanged
    const input = $('browser-url-input'), view = $('browser-view-content');
    if (!view) return;
    const auto = overrideQuery === 'https://www.google.com' && !(input && input.value.trim());
    let q = overrideQuery || (input ? input.value.trim() : '');
    if (!q) q = 'https://www.google.com';
    let url;
    if (/^https?:\/\//i.test(q)) url = q;
    else if (q.includes('.') && !q.includes(' ')) url = 'https://' + q;
    else url = 'https://www.google.com/search?q=' + encodeURIComponent(q);
    if (input && !auto) input.value = q;

    window.__lastBrowserUrl = url;
    view.innerHTML = `<div class="text-center py-6 font-mono text-xs text-gray-600">
      <i class="fa-brands fa-chrome text-2xl mb-2 block text-gray-800"></i>
      Opens in a full-screen browser.<br>
      <span class="text-[10px] text-gray-500 break-all">${esc(url)}</span><br>
      <button onclick="openLastBrowserUrl()" class="tactile-btn mt-3 px-3 py-1 bg-emerald-800 text-white font-bold text-xs rounded border border-emerald-950">
        <i class="fa-solid fa-arrow-up-right-from-square mr-1"></i> OPEN</button>
    </div>`;
    if (!auto) post({ op: 'openBrowser', url: url });
  };
  window.openLastBrowserUrl = function () {
    if (window.__lastBrowserUrl) post({ op: 'openBrowser', url: window.__lastBrowserUrl });
  };
  window.toggleBrowserMode = function (mode) {
    browserMode = mode;
    localStorage.setItem('browser_mode', mode);
    openModal('browser');
  };

  // =====================================================================
  // 6. Wrap openModal for the screens we changed
  // =====================================================================
  const origOpen = window.openModal;
  window.openModal = function (key) {
    origOpen(key);
    if (key === 'ai_summary') post({ op: 'aiStatus' });
    else if (key === 'settings') { post({ op: 'getLauncherState' }); post({ op: 'aiStatus' }); }
    else if (key === 'apps') { renderAppsModal(); post({ op: 'getWebApps' }); }
    else if (key === 'contacts') { renderContactsModal(); post({ op: 'getContacts' }); }
    else if (key === 'tools') setTimeout(injectReminderTime, 60);
    else if (key === 'schedule') setTimeout(injectScheduleDate, 60);
  };

  // =====================================================================
  // 7. Native -> JS
  // =====================================================================
  window.__nativeIn = function (json) {
    const m = JSON.parse(json);
    switch (m.type) {
      case 'threads': {
        const t = {};
        Object.keys(m.threads).forEach((c) => { t[c] = m.threads[c].map(toUi); });
        chatThreads = t;
        aiError = m.aiError || '';
        refreshUi();
        break;
      }
      case 'flag': {
        // The AI finished rating a message.
        const list = chatThreads[m.contact];
        if (list) {
          const t = list.find((x) => x.id === m.msg.id);
          if (t) { t.urgent = !!m.msg.urgent; t.reason = esc(m.msg.reason || ''); t.checked = true; }
        }
        aiError = '';
        refreshUi();
        break;
      }
      case 'keyPeopleBiometric':
        if (typeof window.onKeyPeopleBiometric === 'function') window.onKeyPeopleBiometric(!!m.ok, m.message || '', m.people || '');
        break;
      case 'aiStatus':
        aiError = m.error || '';
        if (modalTitle().includes('IMPORTANT')) renderImportantModal();
        break;
      case 'aiTest': {
        const r = $('ai-test-result');
        if (r) r.innerText = (m.ok ? '✓ ' : '✗ ') + m.text;
        break;
      }
      case 'launcherState':
        launcherIsDefault = !!m.isDefault;
        updateLauncherStateUi();
        break;
      case 'toast':
        showToast(m.msg);
        break;
      case 'webapps':
        webApps = m.apps || [];
        if (modalTitle().trim() === 'APPS') renderAppsModal();
        else if (modalTitle().includes('ADD APPLICATION')) { pickedHtml = null; renderAppsModal(); }
        break;
      case 'apps':
        phoneApps = m.apps || [];
        if (modalTitle().includes('PHONE APPS')) renderPhoneApps((($('phoneapps-search') || {}).value) || '');
        break;
      case 'htmlPicked':
        if (m.ok) {
          pickedHtml = { name: m.name || 'app' };
          const lab = $('addapp-file-label');
          if (lab) lab.innerText = '✓ ' + pickedHtml.name;
          const nm = $('addapp-name');
          if (nm && !nm.value.trim()) nm.value = pickedHtml.name.slice(0, 30);
        } else if (m.error) {
          showToast('✗ ' + m.error);
        }
        break;
      case 'message':
        if (!chatThreads[m.contact]) chatThreads[m.contact] = [];
        chatThreads[m.contact].push(toUi(m.msg));
        refreshUi();
        break;
      case 'sendResult': {
        const cb = pending[m.id];
        delete pending[m.id];
        if (cb) cb(m.ok, m.error, m.scheduled);
        break;
      }
      case 'contacts': {
        contactsDenied = !!m.denied;
        contactsList = (m.contacts || []).map(toContact);
        const title = modalTitle();
        if (title.includes('PEOPLE')) renderContactRows(($('contacts-search') || {}).value || '');
        else if (title.includes('DIAL')) updateDialPadDisplay(false);
        break;
      }
    }
  };

  // =====================================================================
  // 8. AI settings -> phone (so messages are rated even when this screen is closed)
  // =====================================================================
  function pushAiConfig() {
    post({
      op: 'saveAiConfig',
      apiKey: apiKey, model: aiModel, enabled: !!aiAnalysisEnabled, instructions: aiInstructions,
      name: userProfile.name, role: userProfile.role, people: "", other: userProfile.other,
      subject: defaultUserSubject
    });
  }
  const origSaveSettings = window.saveSettingsKey;
  window.saveSettingsKey = function () {
    origSaveSettings();
    if (window.keyPeopleUnlocked && typeof window.getKeyPeopleValue === 'function') {
      post({ op: 'saveKeyPeople', people: window.getKeyPeopleValue() });
    }
    pushAiConfig();
  };

  window.testAiConnection = function () {
    window.saveSettingsKey();
    const r = $('ai-test-result');
    if (r) r.innerText = 'Testing...';
    post({ op: 'testAi' });
  };
  window.setDefaultLauncher = function () { post({ op: 'setDefaultLauncher' }); };

  // =====================================================================
  // 9. APPS: built-in tools, plug-in web apps, phone apps
  // =====================================================================
  let webApps = [];
  let phoneApps = [];
  let pickedHtml = null;
  const PKG_OK = /^[A-Za-z0-9._]+$/;
  const ID_OK = /^[0-9a-f]{10}$/;

  function setModalHeader(title, icon) {
    const t = $('modal-title'), i = $('modal-icon'), b = $('modal-action-btn');
    if (t) t.innerText = title;
    if (i) i.className = icon;
    if (b) { b.innerText = 'CLOSE'; b.setAttribute('onclick', 'closeModal()'); }
  }

  const appRow = (onclick, iconHtml, label, tag) => `
    <div onclick="${onclick}" class="p-2 bg-white border border-gray-300 rounded-lg flex justify-between items-center cursor-pointer active:bg-gray-200">
      <span class="font-bold text-gray-800 truncate pr-2">${iconHtml}${label}</span>
      <span class="text-[9px] bg-gray-200 text-gray-800 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">${tag}</span>
    </div>`;

  window.renderAppsModal = function () {
    setModalHeader('APPS', 'fa-solid fa-border-all');
    const body = $('modal-body');
    if (!body) return;
    const mine = webApps.filter((a) => ID_OK.test(a.id)).map((a) => `
      <div class="p-2 bg-white border border-gray-300 rounded-lg flex justify-between items-center">
        <div onclick="appsOpenWeb('${a.id}')" class="min-w-0 flex-1 cursor-pointer active:bg-gray-200">
          <span class="font-bold text-gray-800 truncate block"><i class="fa-solid fa-puzzle-piece text-purple-700 mr-2"></i>${esc(a.name)}</span>
          <span class="text-[9px] text-gray-500 font-mono truncate block">${a.kind === 'file' ? 'HTML FILE' : esc(a.url)}</span>
        </div>
        <button onclick="appsRemoveWeb('${a.id}')" class="text-red-700 px-2 py-0.5 border border-red-200 bg-red-50 rounded text-xs shrink-0 ml-2"><i class="fa-solid fa-trash text-[10px]"></i></button>
      </div>`).join('');

    body.innerHTML = `
      <div class="space-y-1.5 font-sans text-xs">
        <div class="grid grid-cols-2 gap-1.5">
          <button onclick="showAddApp()" class="tactile-btn py-2 rounded-lg border border-emerald-900 bg-emerald-800 text-white font-mono font-bold text-[11px]"><i class="fa-solid fa-plus mr-1"></i>ADD APPLICATION</button>
          <button onclick="showPhoneApps()" class="tactile-btn py-2 rounded-lg border border-gray-600 font-mono font-bold text-[11px] text-gray-900"><i class="fa-solid fa-mobile-screen mr-1"></i>PHONE APPS</button>
        </div>

        <p class="text-[10px] font-mono font-bold text-gray-600 pt-1">LAUNCHER TOOLS</p>
        ${appRow("openModal('messages')", '<i class="fa-brands fa-whatsapp text-emerald-700 mr-2"></i>', 'WhatsApp &amp; Replies', 'ACTIVE')}
        ${appRow("appsOpenWhatsApp()", '<i class="fa-brands fa-whatsapp text-emerald-700 mr-2"></i>', 'WhatsApp (real app)', 'OPEN')}
        ${appRow("openModal('tools')", '<i class="fa-solid fa-calculator text-gray-800 mr-2"></i>', 'Calculator &amp; Reminders', 'READY')}
        ${appRow("openModal('browser')", '<i class="fa-brands fa-chrome text-blue-700 mr-2"></i>', 'Interactive Chrome Browser', 'READY')}
        ${appRow("openModal('alarms')", '<i class="fa-solid fa-clock text-amber-700 mr-2"></i>', 'Alarms &amp; Clock Manager', 'SYSTEM')}
        ${appRow("openModal('schedule')", '<i class="fa-solid fa-calendar-days text-purple-700 mr-2"></i>', 'Schedule &amp; Calendar', 'SYSTEM')}

        <p class="text-[10px] font-mono font-bold text-gray-600 pt-1">MY APPS</p>
        ${mine || '<div class="p-2 text-center text-[11px] text-gray-500 font-mono italic">No apps added yet. Press ADD APPLICATION to plug in a web app.</div>'}
      </div>`;
  };

  window.appsOpenWhatsApp = function () { post({ op: 'openWhatsApp' }); };
  window.appsOpenWeb = function (id) { if (ID_OK.test(id)) post({ op: 'openWebApp', id: id }); };
  window.appsRemoveWeb = function (id) {
    if (!ID_OK.test(id)) return;
    if (!confirm('Remove this app from the launcher?')) return;
    post({ op: 'removeWebApp', id: id });
  };
  window.appsOpenPhone = function (pkg) { if (PKG_OK.test(pkg)) post({ op: 'openApp', pkg: pkg }); };

  window.showAddApp = function () {
    pickedHtml = null;
    setModalHeader('ADD APPLICATION', 'fa-solid fa-plus');
    const btn = $('modal-action-btn');
    if (btn) { btn.innerText = 'SAVE APP'; btn.setAttribute('onclick', 'submitAddApp()'); }
    $('modal-body').innerHTML = `
      <div class="space-y-2 font-sans text-xs">
        <button onclick="renderAppsModal(); post_getWebApps()" class="text-[10px] font-mono font-bold underline text-gray-700"><i class="fa-solid fa-arrow-left mr-1"></i>BACK TO APPS</button>
        <div class="p-2 bg-white rounded-lg border border-gray-400 space-y-1">
          <label class="font-bold block text-gray-800 font-mono">APP NAME:</label>
          <input id="addapp-name" type="text" maxlength="30" placeholder="e.g. Study Planner" class="w-full p-2 border border-gray-300 rounded font-sans text-xs focus:outline-none">
        </div>
        <div class="p-2 bg-white rounded-lg border border-gray-400 space-y-1">
          <label class="font-bold block text-gray-800 font-mono">WEB APP LINK:</label>
          <input id="addapp-url" type="url" placeholder="https://my-app.example.com" class="w-full p-2 border border-gray-300 rounded font-mono text-xs focus:outline-none">
        </div>
        <p class="text-center text-[10px] font-mono font-bold text-gray-500">- OR -</p>
        <div class="p-2 bg-white rounded-lg border border-gray-400 space-y-1">
          <label class="font-bold block text-gray-800 font-mono">HTML FILE FROM THIS PHONE:</label>
          <button onclick="pickHtmlFile()" class="tactile-btn w-full py-1.5 font-mono font-bold text-[11px] rounded border border-gray-600 text-gray-900"><i class="fa-solid fa-file-code mr-1"></i>CHOOSE .HTML FILE</button>
          <p id="addapp-file-label" class="text-[10px] text-gray-600 font-mono">No file chosen</p>
        </div>
        <p class="text-[10px] text-gray-500">Use either a link or a file, then press SAVE APP. A file must be a single self-contained .html page (it may load scripts and styles from the internet). Each app runs on its own and cannot read your messages or settings.</p>
      </div>`;
  };
  window.post_getWebApps = function () { post({ op: 'getWebApps' }); };
  window.pickHtmlFile = function () { post({ op: 'pickHtml' }); };

  window.submitAddApp = function () {
    const name = (($('addapp-name') || {}).value || '').trim();
    let url = (($('addapp-url') || {}).value || '').trim();
    if (!name) { showToast('Give the app a name'); return; }
    if (url && pickedHtml) { showToast('Use either a link or a file, not both'); return; }
    if (url) {
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
      post({ op: 'addWebAppUrl', name: name, url: url });
    } else if (pickedHtml) {
      post({ op: 'addWebAppFile', name: name });
    } else {
      showToast('Enter a link or choose an .html file');
    }
  };

  window.showPhoneApps = function () {
    setModalHeader('PHONE APPS', 'fa-solid fa-mobile-screen');
    $('modal-body').innerHTML = `
      <div class="space-y-2 font-sans text-xs">
        <button onclick="renderAppsModal(); post_getWebApps()" class="text-[10px] font-mono font-bold underline text-gray-700"><i class="fa-solid fa-arrow-left mr-1"></i>BACK TO APPS</button>
        <input id="phoneapps-search" type="text" placeholder="🔍 Search installed apps..." oninput="renderPhoneApps(this.value)" class="w-full p-1.5 border border-gray-400 rounded-lg text-xs font-sans focus:outline-none bg-white">
        <div id="phoneapps-list" class="space-y-1.5"><div class="p-2 text-center text-[11px] text-gray-500 font-mono italic">Loading apps...</div></div>
      </div>`;
    post({ op: 'listApps' });
  };

  window.renderPhoneApps = function (q) {
    const box = $('phoneapps-list');
    if (!box) return;
    const s = String(q || '').trim().toLowerCase();
    const list = phoneApps.filter((a) => PKG_OK.test(a.pkg) && (!s || String(a.label).toLowerCase().includes(s)));
    if (!list.length) {
      box.innerHTML = `<div class="p-2 text-center text-[11px] text-gray-500 font-mono italic">${phoneApps.length ? 'No app matches.' : 'No apps found.'}</div>`;
      return;
    }
    box.innerHTML = list.map((a) => `
      <div onclick="appsOpenPhone('${a.pkg}')" class="p-2 bg-white border border-gray-300 rounded-lg cursor-pointer active:bg-gray-200">
        <span class="font-bold text-gray-800 block truncate">${esc(a.label)}</span>
        <span class="text-[9px] text-gray-500 font-mono block truncate">${esc(a.pkg)}</span>
      </div>`).join('');
  };

  post({ op: 'sync' });
  post({ op: 'getContacts' });
  post({ op: 'getWebApps' });
  pushAiConfig();
  syncTimers();
})();
