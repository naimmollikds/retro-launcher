package com.retrolauncher

import android.content.Context
import org.json.JSONObject

/**
 * AI settings shared between the web UI and the background notification service.
 * The web UI sends them with the "saveAiConfig" bridge call; the service reads them here,
 * so messages are rated even when the launcher screen is not open.
 */
object AiConfig {
    private const val PREFS = "ai_config"
    const val DEFAULT_MODEL = "gemini-3-flash-preview"

    data class Snapshot(
        val apiKey: String,
        val model: String,
        val enabled: Boolean,
        val instructions: String,
        val name: String,
        val role: String,
        val people: String,
        val other: String,
        val subject: String
    ) {
        /** Plain-text description of the user, sent to the AI. */
        fun profileText(): String {
            val sb = StringBuilder()
            if (name.isNotBlank()) sb.append("Name: ").append(name.trim()).append('\n')
            if (role.isNotBlank()) sb.append("What they do: ").append(role.trim()).append('\n')
            if (subject.isNotBlank()) sb.append("Study/work context: ").append(subject.trim()).append('\n')
            if (people.isNotBlank()) sb.append("Key people: ").append(people.trim()).append('\n')
            if (other.isNotBlank()) sb.append("Other details: ").append(other.trim()).append('\n')
            return sb.toString().trim()
        }
    }

    fun load(ctx: Context): Snapshot {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Snapshot(
            apiKey = p.getString("apiKey", "") ?: "",
            model = (p.getString("model", "") ?: "").ifBlank { DEFAULT_MODEL },
            enabled = p.getBoolean("enabled", true),
            instructions = p.getString("instructions", "") ?: "",
            name = p.getString("name", "") ?: "",
            role = p.getString("role", "") ?: "",
            people = p.getString("people", "") ?: "",
            other = p.getString("other", "") ?: "",
            subject = p.getString("subject", "") ?: ""
        )
    }

    fun save(ctx: Context, o: JSONObject) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("apiKey", o.optString("apiKey").trim())
            .putString("model", o.optString("model").trim())
            .putBoolean("enabled", o.optBoolean("enabled", true))
            .putString("instructions", o.optString("instructions").take(4000))
            .putString("name", o.optString("name").take(200))
            .putString("role", o.optString("role").take(500))
            .putString("people", o.optString("people").take(2000))
            .putString("other", o.optString("other").take(2000))
            .putString("subject", o.optString("subject").take(500))
            .apply()
    }
}
