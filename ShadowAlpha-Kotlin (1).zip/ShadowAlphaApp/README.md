# Shadow Alpha (native Android / Kotlin + Jetpack Compose)

Native rebuild of the SHADOW_V200_SILENT web app. Same layout, colours, sizes, texts,
XP/SP/level rules, shop, contracts, tasbih/salah, archive, and Gemini prompts.

## What works offline
Everything except the Gemini calls: XP/levels/SP, hydration, quests, shop + skins,
timer + contracts, tasbih, salah, notes + attachments, logs, midnight reset,
battery/clock, spoken logs (Android TTS), voice input (phone recognizer),
3D bust (see below).

## What needs internet (and only this)
Neural Link chat, AI task generation, 10-log summary, quest-photo / screen-time verification.
When offline the app says so in the log and keeps working.

## Setup
1. Build (GitHub Actions workflow included, or Android Studio).
2. Open the app -> gear icon -> paste your Gemini API key(s) -> Save.
   (No keys are bundled in the app.)
3. Optional: add the original fonts, see app/src/main/assets/fonts/README.txt

## 3D model
Same model as the web version: `LeePerrySmith.glb` (head, neck, shoulders) drawn as a rotating red wireframe.
The GitHub Actions build downloads it into `app/src/main/assets/` so it is inside the APK (works offline).
You can also drop the .glb there yourself. If it is missing, the app downloads it once and caches it;
until then a built-in upper-body wireframe is shown.

## Automatic screen time
Open the app -> phone icon -> "Grant Usage Access" (one time). The app then reads your real screen time
from the phone, shows it live (SCR bar), warns at 80% / 100%, and gives every day a new limit:
`limit = 92% of your last-7-day average` (tune `LIMIT_FACTOR`, `LIMIT_MIN`, `LIMIT_MAX` in ShadowVM.kt).
At midnight the day is settled automatically (XP reward / penalty). Screenshots remain as a fallback.

## ElevenLabs voice
Gear icon -> ELEVENLABS VOICE: paste API key + Voice ID, switch ON, press TEST VOICE.
Every spoken line is rendered by ElevenLabs (mp3, cached) and falls back to the phone voice if offline or on error.
