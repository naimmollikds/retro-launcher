package com.shadow.alpha

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close

object Fonts {
    var title: FontFamily = FontFamily.SansSerif   // Archivo Black (if present in assets/fonts)
    var body: FontFamily = FontFamily.Monospace    // Space Mono (if present in assets/fonts)
    var hasTitleFont = false
}

object C {
    val Blood = Color(0xFFFF0000)
    val ShadowBlue = Color(0xFF0088FF)
    val Gold = Color(0xFFFFD700)
    val Black = Color(0xFF000000)
    val Z950 = Color(0xFF09090B)
    val Z900 = Color(0xFF18181B)
    val Z800 = Color(0xFF27272A)
    val Z700 = Color(0xFF3F3F46)
    val Z500 = Color(0xFF71717A)
    val Z400 = Color(0xFFA1A1AA)
    val Z300 = Color(0xFFD4D4D8)
    val Z200 = Color(0xFFE4E4E7)
    val Red900 = Color(0xFF7F1D1D)
    val Red600 = Color(0xFFDC2626)
    val Red500 = Color(0xFFEF4444)
    val Cyan400 = Color(0xFF22D3EE)
    val Cyan500 = Color(0xFF06B6D4)
    val Cyan600 = Color(0xFF0891B2)
    val Cyan900 = Color(0xFF164E63)
    val Cyan950 = Color(0xFF083344)
    val Cyan800 = Color(0xFF155E75)
    val Cyan700 = Color(0xFF0E7490)
    val Cyan300 = Color(0xFF67E8F9)
    val Yellow500 = Color(0xFFEAB308)
    val Amber400 = Color(0xFFFBBF24)
    val Amber500 = Color(0xFFF59E0B)
    val Amber600 = Color(0xFFD97706)
    val Amber900 = Color(0xFF78350F)
    val Blue500 = Color(0xFF3B82F6)
    val Blue600 = Color(0xFF2563EB)
    val Emerald400 = Color(0xFF34D399)
    val Purple400 = Color(0xFFC084FC)
    val Line = Color(0xFF222222)
    val Panel = Color(0xFF0A0A0A)
    val Hint = Color(0xFF9CA3AF)
}

@Composable
fun T(
    text: String, size: Float, color: Color = Color.White, bold: Boolean = false, title: Boolean = false,
    modifier: Modifier = Modifier, align: TextAlign? = null, spacing: Float = 0f,
    italic: Boolean = false, strike: Boolean = false, alpha: Float = 1f,
    maxLines: Int = Int.MAX_VALUE, weight: FontWeight? = null, family: FontFamily? = null
) {
    Text(
        text = text, modifier = modifier, maxLines = maxLines,
        color = color.copy(alpha = color.alpha * alpha),
        fontSize = size.sp,
        fontFamily = family ?: if (title) Fonts.title else Fonts.body,
        fontWeight = weight ?: if (title) FontWeight.Black else if (bold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
        letterSpacing = spacing.sp,
        textAlign = align,
        textDecoration = if (strike) TextDecoration.LineThrough else null
    )
}

@Composable
fun Ico(v: ImageVector, size: Float, tint: Color, modifier: Modifier = Modifier, alpha: Float = 1f) {
    Icon(v, null, tint = tint, modifier = modifier.size(size.dp).alpha(alpha))
}

fun Modifier.tap(onClick: () -> Unit): Modifier = composed2(onClick)

private fun Modifier.composed2(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(interactionSource = MutableInteractionSource(), indication = null, onClick = onClick))

/** .module */
@Composable
fun Mod(modifier: Modifier = Modifier, center: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier.padding(bottom = 12.dp).fillMaxWidth()
            .background(C.Panel).border(1.dp, C.Line).padding(12.dp),
        horizontalAlignment = if (center) Alignment.CenterHorizontally else Alignment.Start,
        content = content
    )
}

/** .tag */
@Composable
fun Tag(text: String, color: Color = C.Blood, size: Float = 8f, icon: ImageVector? = null, bold: Boolean = false, bottom: Float = 5f) {
    Row(Modifier.padding(bottom = bottom.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Ico(icon, size + 1, color); Spacer(Modifier.width(4.dp)) }
        T(text.uppercase(), size, color, title = true)
    }
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier,
    size: Float = 10f, color: Color = Color.White, number: Boolean = false, password: Boolean = false,
    singleLine: Boolean = true, center: Boolean = false, bold: Boolean = false, onSend: (() -> Unit)? = null,
    hintColor: Color = C.Hint
) {
    BasicTextField(
        value = value, onValueChange = onChange, modifier = modifier, singleLine = singleLine,
        textStyle = TextStyle(
            color = color, fontSize = size.sp, fontFamily = Fonts.body,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            textAlign = if (center) TextAlign.Center else TextAlign.Start
        ),
        cursorBrush = SolidColor(Color.White),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (number) KeyboardType.Number else if (password) KeyboardType.Password else KeyboardType.Text,
            imeAction = if (onSend != null) androidx.compose.ui.text.input.ImeAction.Send else androidx.compose.ui.text.input.ImeAction.Default
        ),
        keyboardActions = KeyboardActions(onSend = { onSend?.invoke() }),
        decorationBox = { inner ->
            Box(contentAlignment = if (center) Alignment.Center else if (singleLine) Alignment.CenterStart else Alignment.TopStart) {
                if (value.isEmpty()) T(hint, size, hintColor, align = if (center) TextAlign.Center else null)
                inner()
            }
        }
    )
}

/** Outlined small uppercase button, e.g. "Deploy Custom Task". */
@Composable
fun OutBtn(
    text: String, border: Color, textColor: Color, onClick: () -> Unit, modifier: Modifier = Modifier,
    size: Float = 8f, icon: ImageVector? = null, vPad: Float = 4f, hPad: Float = 8f, title: Boolean = false,
    bg: Color = Color.Transparent
) {
    Row(
        modifier.background(bg).border(1.dp, border).tap(onClick).padding(horizontal = hPad.dp, vertical = vPad.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Ico(icon, size + 1, textColor); Spacer(Modifier.width(4.dp)) }
        T(text.uppercase(), size, textColor, bold = !title, title = title)
    }
}

/** Full-screen dim layer + centered panel, used by every popup. */
@Composable
fun ModalBox(borderColor: Color, content: @Composable ColumnScope.() -> Unit) {
    BoxWithConstraints(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.85f)).tap { }.padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 384.dp).fillMaxWidth().heightIn(max = maxHeight * 0.9f)
                .background(C.Z950, RoundedCornerShape(4.dp))
                .border(1.dp, borderColor, RoundedCornerShape(4.dp))
                .padding(16.dp).verticalScroll(rememberScrollState()),
            content = content
        )
    }
}

@Composable
fun ModalHeader(titleText: String, color: Color, icon: ImageVector? = null, onClose: () -> Unit, bottom: Float = 12f) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = bottom.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Ico(icon, 14f, color); Spacer(Modifier.width(4.dp)) }
            T(titleText.uppercase(), 14f, color, title = true)
        }
        Ico(Icons.Filled.Close, 14f, Color.White, Modifier.tap(onClose), 0.7f)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(C.Z800))
    Spacer(Modifier.height(bottom.dp))
}

/** `<input type=file>` look-alike */
@Composable
fun FilePickRow(name: String, onPick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black).border(1.dp, C.Z800)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.background(Color(0xFFEFEFEF)).tap(onPick).padding(horizontal = 8.dp, vertical = 2.dp)) {
            T("Choose File", 10f, Color.Black)
        }
        Spacer(Modifier.width(8.dp))
        T(name.ifBlank { "No file chosen" }, 10f, Color.White, maxLines = 1)
    }
}
