package com.shadow.alpha

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/** Text -> speech through ElevenLabs (same idea as the MacroDroid HTTP request, but built into the app). */
object ElevenLabs {
    const val DEFAULT_MODEL = "eleven_flash_v2_5"   // fastest model; use eleven_multilingual_v2 for best quality

    class Result(val file: File?, val error: String = "")

    suspend fun synth(ctx: Context, key: String, voiceId: String, model: String, text: String): Result =
        withContext(Dispatchers.IO) {
            try {
                val dir = File(ctx.cacheDir, "eleven").apply { mkdirs() }
                val m = model.ifBlank { DEFAULT_MODEL }
                val hash = MessageDigest.getInstance("SHA-1").digest("$voiceId|$m|$text".toByteArray())
                    .joinToString("") { "%02x".format(it) }.take(24)
                val out = File(dir, "$hash.mp3")
                if (out.exists() && out.length() > 0) { out.setLastModified(System.currentTimeMillis()); return@withContext Result(out) }

                val url = URL("https://api.elevenlabs.io/v1/text-to-speech/${URLEncoder.encode(voiceId, "UTF-8")}?output_format=mp3_44100_64")
                val c = url.openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 10000; c.readTimeout = 30000
                c.doOutput = true
                c.setRequestProperty("xi-api-key", key)
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Accept", "audio/mpeg")
                val body = JSONObject().put("text", text).put("model_id", m).toString()
                c.outputStream.use { it.write(body.toByteArray()) }

                if (c.responseCode != 200) {
                    val err = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Exception) { "" }
                    val msg = try {
                        val d = JSONObject(err).opt("detail")
                        if (d is JSONObject) d.optString("message", d.optString("status")) else d?.toString() ?: ""
                    } catch (_: Exception) { "" }
                    val code = c.responseCode
                    c.disconnect()
                    return@withContext Result(null, "HTTP $code ${msg.take(80)}".trim())
                }
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                if (bytes.isEmpty()) return@withContext Result(null, "EMPTY AUDIO")
                val tmp = File(dir, "$hash.tmp")
                tmp.writeBytes(bytes)
                tmp.renameTo(out)
                trim(dir)
                Result(out)
            } catch (e: Exception) {
                Result(null, (e.message ?: e.javaClass.simpleName).take(80))
            }
        }

    /** Keep the cache small. */
    private fun trim(dir: File) {
        val files = dir.listFiles()?.filter { it.extension == "mp3" }?.sortedBy { it.lastModified() } ?: return
        if (files.size > 60) files.take(files.size - 40).forEach { it.delete() }
    }
}
