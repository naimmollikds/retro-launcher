package com.shadow.alpha

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.time.LocalDate
import java.time.ZoneId

fun fmtMin(m: Int): String = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"

/** Reads the phone's own screen-time data (needs the one-time "Usage access" permission). */
object UsageReader {
    class Today(val totalMin: Int, val top: List<Pair<String, Int>>)

    fun hasPermission(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        if (mode == AppOpsManager.MODE_DEFAULT)
            ctx.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED
        else mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun startOf(d: LocalDate) = d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    private fun ignored(ctx: Context): Set<String> {
        val s = hashSetOf("android", "com.android.systemui")
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) { }
        return s
    }

    /** Foreground milliseconds per package between start and end, built from resume/pause events (same idea as Digital Wellbeing). */
    private fun perPackage(ctx: Context, start: Long, end: Long): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(start, end) ?: return emptyMap()
        val e = UsageEvents.Event()
        val skip = ignored(ctx)
        val openSince = HashMap<String, Long>()
        val openCount = HashMap<String, Int>()
        val total = HashMap<String, Long>()

        fun close(pkg: String, ts: Long) {
            val st = openSince.remove(pkg) ?: return
            openCount.remove(pkg)
            if (ts > st) total[pkg] = (total[pkg] ?: 0L) + (ts - st)
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val type = e.eventType
            if (type == 16) { for (p in openSince.keys.toList()) close(p, e.timeStamp); continue }   // screen turned off
            val pkg = e.packageName ?: continue
            if (pkg in skip) continue
            when (type) {
                1 -> {                                                   // activity resumed / moved to foreground
                    val c = openCount[pkg] ?: 0
                    if (c == 0) openSince[pkg] = e.timeStamp
                    openCount[pkg] = c + 1
                }
                2 -> {                                                   // activity paused / moved to background
                    val c = (openCount[pkg] ?: 0) - 1
                    if (c <= 0) close(pkg, e.timeStamp) else openCount[pkg] = c
                }
            }
        }
        for (p in openSince.keys.toList()) close(p, end)
        return total
    }

    private fun label(ctx: Context, pkg: String): String = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() } }

    private fun minutes(ms: Long) = Math.round(ms / 60000.0).toInt()

    fun today(ctx: Context): Today {
        val now = System.currentTimeMillis()
        val map = perPackage(ctx, startOf(LocalDate.now()), now)
        val top = map.entries.sortedByDescending { it.value }.take(5)
            .map { Pair(label(ctx, it.key), minutes(it.value)) }.filter { it.second > 0 }
        return Today(minutes(map.values.sum()), top)
    }

    fun dayMinutes(ctx: Context, day: LocalDate): Int {
        val end = minOf(startOf(day.plusDays(1)), System.currentTimeMillis())
        return minutes(perPackage(ctx, startOf(day), end).values.sum())
    }

    /** The last [days] completed days (yesterday backwards) as (date, minutes). Days Android has no data for come back as 0. */
    fun history(ctx: Context, days: Int): List<Pair<String, Int>> =
        (1..days).map { LocalDate.now().minusDays(it.toLong()) }.map { Pair(it.toString(), dayMinutes(ctx, it)) }
}
