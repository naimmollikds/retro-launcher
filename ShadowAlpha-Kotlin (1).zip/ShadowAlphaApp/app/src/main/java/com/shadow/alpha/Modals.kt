package com.shadow.alpha

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import java.util.Locale

@Composable
fun Modals(vm: ShadowVM, a: Actions) {
    if (vm.stInitOpen) StInitModal(vm, a)
    if (vm.stProofOpen) StProofModal(vm, a)
    if (vm.taskProofIdx != null) TaskProofModal(vm, a)
    if (vm.taskInfoIdx != null) TaskInfoModal(vm)
    if (vm.purgeOpen) PurgeModal(vm)
    if (vm.settingsOpen) SettingsModal(vm, a)
    if (vm.guideOpen) GuideModal(vm)
}

@Composable
private fun FullBtn(text: String, bg: Color, border: Color, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier, bold: Boolean = true) {
    Box(modifier.background(bg).border(1.dp, border).tap(onClick).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        T(text.uppercase(), 9f, color, bold = bold)
    }
}

@Composable
private fun StInitModal(vm: ShadowVM, a: Actions) = ModalBox(C.Amber600) {
    Row(Modifier.padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Ico(Icons.Filled.PhoneAndroid, 14f, C.Amber500); Spacer(Modifier.width(4.dp))
        T("SCREEN TIME INITIALIZATION", 14f, C.Amber500, title = true)
    }
    Text(
        buildAnnotatedString {
            append("Shadow Alpha reads your phone's own screen-time data and sets a new limit for you every day from your ")
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("last 7 days of real usage") }
            append(". Allow \"Usage access\" once and everything is automatic - no screenshots.")
        }, fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp)
    )
    FullBtn("Grant Usage Access", C.Amber600, C.Amber400, Color.Black, { vm.openUsageSettings() }, Modifier.fillMaxWidth())
    Spacer(Modifier.height(6.dp))
    T("After allowing it, come back to the app - it detects it by itself.", 8f, C.Z400, modifier = Modifier.padding(bottom = 12.dp))

    Box(Modifier.fillMaxWidth().height(1.dp).background(C.Z900)); Spacer(Modifier.height(8.dp))
    T("FALLBACK: SCREENSHOT OF 5+ DAYS", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 6.dp))
    FilePickRow(vm.stInitName) { a.pickStInit() }
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        T("OPTIONAL API KEY (INSTANT SETUP):", 8f, C.Cyan400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
        Field(vm.stInitKey, { vm.stInitKey = it }, "Paste Gemini API Key (or leave blank to use stored)...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(6.dp), size = 9f, password = true)
    }
    FullBtn("Verify Screenshot & Initialize", C.Z900, C.Z700, C.Z300, { vm.verifyInitialScreenTime() }, Modifier.fillMaxWidth())
}

@Composable
private fun StProofModal(vm: ShadowVM, a: Actions) = ModalBox(C.Amber600) {
    ModalHeader("Daily Screen Time", C.Amber500, Icons.Filled.PhoneAndroid, { vm.stProofOpen = false })
    val lim = if (vm.s.targetMaxScreenTimeMinutes != 0) vm.s.targetMaxScreenTimeMinutes
        else Math.round((if (vm.s.targetMaxScreenTimeHours != 0.0) vm.s.targetMaxScreenTimeHours else 4.0) * 60).toInt()
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Amber900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("TODAY'S LIMIT (AUTO-ASSIGNED):", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T("${fmtMin(lim)} ($lim Mins)", 12f, C.Amber500, bold = true)
    }
    if (vm.usageGranted) {
        val used = vm.usageTodayMin
        val over = used > lim
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)).padding(8.dp)) {
            T("USED TODAY (LIVE FROM PHONE):", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
            T(fmtMin(used), 14f, if (over) C.Red500 else C.Cyan400, bold = true)
            T(if (over) "OVER LIMIT BY ${fmtMin(used - lim)}" else "REMAINING: ${fmtMin(lim - used)}", 9f, if (over) C.Red500 else C.Z300, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp))
            if (vm.usageTop.isNotEmpty()) {
                T("TOP APPS:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
                vm.usageTop.forEach { (name, m) -> T("$name  -  ${fmtMin(m)}", 8f, C.Z300) }
            }
        }
        Text("Updates live every 30 seconds. At midnight the day is settled automatically against your limit; tomorrow's limit is recalculated from your real usage.",
            fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
        if (vm.s.screenTimeProofSubmitted) T("TODAY'S RESULT IS ALREADY SETTLED", 9f, C.Cyan400, bold = true)
        else FullBtn("Settle Today Now", C.Amber600, C.Amber400, Color.Black, { vm.settleNow() }, Modifier.fillMaxWidth())
    } else {
        Text("Allow Usage access so the app can read your real screen time. Or submit a screenshot instead.",
            fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
        FullBtn("Grant Usage Access", C.Amber600, C.Amber400, Color.Black, { vm.openUsageSettings() }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        FilePickRow(vm.stProofName) { a.pickStProof() }
        FullBtn("Submit Screenshot Proof", C.Z900, C.Z700, C.Z300, { vm.submitScreenTimeProof() }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun TaskProofModal(vm: ShadowVM, a: Actions) = ModalBox(C.Cyan600) {
    val idx = vm.taskProofIdx ?: return@ModalBox
    val task = vm.s.tasks.getOrNull(idx)
    ModalHeader("Quest Proof Required", C.Cyan400, Icons.Filled.PhotoCamera, { vm.closeTaskProof() })
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Cyan900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("TARGET QUEST:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T(if (task != null) "#${idx + 1}: ${task.text}" else "--", 12f, C.Cyan400, bold = true)
    }
    if (task != null && task.proofInstruction.isNotBlank()) {
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(C.Z900, RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)).padding(8.dp)) {
            Row(Modifier.padding(bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Ico(Icons.Filled.Info, 8f, C.Yellow500); Spacer(Modifier.width(4.dp))
                T("REQUIRED PROOF:", 8f, C.Yellow500, bold = true)
            }
            T(task.proofInstruction, 9f, C.Z300)
        }
    }
    Text("Upload image evidence proving you completed this quest. The Neural System will verify its authenticity before awarding XP.", fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
    FilePickRow(vm.taskProofName) { a.pickTaskProof() }
    FullBtn("Verify Image & Complete Quest", C.Cyan600, C.Cyan400, Color.Black, { vm.submitTaskProof() }, Modifier.fillMaxWidth())
}

@Composable
private fun TaskInfoModal(vm: ShadowVM) = ModalBox(C.Cyan500) {
    val idx = vm.taskInfoIdx ?: return@ModalBox
    val task = vm.s.tasks.getOrNull(idx)
    ModalHeader("Quest Requirements", C.Cyan400, Icons.Filled.Info, { vm.taskInfoIdx = null })
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Cyan900, RoundedCornerShape(4.dp)).padding(8.dp)) {
        T("TARGET QUEST:", 8f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 2.dp))
        T(if (task != null) "#${idx + 1}: ${task.text}" else "--", 12f, C.Cyan400, bold = true)
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp).background(C.Z900, RoundedCornerShape(4.dp)).border(1.dp, C.Z800, RoundedCornerShape(4.dp)).padding(12.dp)) {
        Row(Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico(Icons.Filled.Checklist, 8f, C.Yellow500); Spacer(Modifier.width(4.dp))
            T("CAPTURE INSTRUCTIONS:", 8f, C.Yellow500, bold = true)
        }
        Text(
            task?.proofInstruction?.ifBlank { null } ?: "Capture clear image evidence proving completion of this task.",
            fontSize = 10.sp, color = C.Z200, fontFamily = Fonts.body, lineHeight = 16.sp
        )
    }
    FullBtn("Acknowledge", C.Cyan950, C.Cyan600, C.Cyan300, { vm.taskInfoIdx = null }, Modifier.fillMaxWidth())
}

@Composable
private fun PurgeModal(vm: ShadowVM) = ModalBox(C.Red600) {
    ModalHeader("System Purge", C.Red500, Icons.Filled.Warning, { vm.purgeOpen = false })
    Text("Enter authorization key to initiate a complete system wipe.", fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
    Field(vm.purgeCode, { vm.purgeCode = it }, "PURGE CODE...", Modifier.fillMaxWidth().padding(bottom = 12.dp).background(Color.Black).border(1.dp, C.Red900).padding(8.dp), password = true)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FullBtn("EXECUTE PURGE", C.Red900, C.Red600, Color.White, { vm.confirmPurge() }, Modifier.weight(1f))
        Box(Modifier.background(C.Z900).border(1.dp, C.Z800).tap { vm.purgeOpen = false }.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            T("CANCEL", 9f, C.Z400)
        }
    }
}

@Composable
private fun SettingsModal(vm: ShadowVM, a: Actions) = ModalBox(C.Red900) {
    ModalHeader("System_Settings", C.Red500, null, { vm.toggleSettings() }, bottom = 16f)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column {
            T("GEMINI API KEY 1 (TASK AI & CHAT)", 9f, C.Z400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fKey1, { vm.fKey1 = it }, "Enter Primary Task API Key...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp), password = true)
        }
        Column {
            T("GEMINI API KEY 2 (LOG SUMMARIZER - 10 LOG CYCLE)", 9f, C.Cyan400, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fKey2, { vm.fKey2 = it }, "Enter Second Summarizer API Key...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp), password = true)
        }
        Column(Modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Z900, RoundedCornerShape(4.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            T("ELEVENLABS VOICE (REPLACES PHONE TTS)", 9f, C.Cyan400, bold = true)
            OutBtn(if (vm.fElOn) "ELEVENLABS VOICE: ON" else "ELEVENLABS VOICE: OFF", if (vm.fElOn) C.Cyan400 else C.Z700,
                if (vm.fElOn) C.Cyan400 else C.Z400, { vm.fElOn = !vm.fElOn })
            Field(vm.fElKey, { vm.fElKey = it }, "ElevenLabs API Key (xi-api-key)...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp), password = true)
            Field(vm.fElVoice, { vm.fElVoice = it }, "Voice ID (from your ElevenLabs voice)...", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp))
            Field(vm.fElModel, { vm.fElModel = it }, "Model (default: eleven_flash_v2_5)", Modifier.fillMaxWidth().background(Color.Black).border(1.dp, C.Z800).padding(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                OutBtn("TEST VOICE", C.Cyan600, C.Cyan300, { vm.testVoice() })
                T(vm.fVoiceStatus, 7f, C.Cyan400)
            }
            T("Every spoken system line is rendered by ElevenLabs and played instantly. Needs internet; offline or on any error it falls back to the phone voice.", 7f, Color(0xFF52525B), italic = true)
        }
        Column {
            T("SYSTEM CONTEXT & LORE PROMPT", 9f, C.Red500, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Field(vm.fPrompt, { vm.fPrompt = it }, "Describe who you are, your goals, current scenario, habits, or drama series system rules...", Modifier.fillMaxWidth().height(96.dp).background(Color.Black).border(1.dp, C.Z800).padding(8.dp), singleLine = false)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.background(C.Z900).border(1.dp, C.Z700).tap { a.pickContext() }.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ico(Icons.Filled.FileUpload, 9f, C.Z300); Spacer(Modifier.width(4.dp))
                    T("LOAD FILE (.TXT, .MD)", 8f, C.Z300, bold = true)
                }
                T(vm.fPromptStatus, 7f, C.Cyan400)
            }
        }
        Column(Modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(4.dp)).border(1.dp, C.Z900, RoundedCornerShape(4.dp)).padding(8.dp)) {
            Row(Modifier.fillMaxWidth().tap { vm.summaryExpanded = !vm.summaryExpanded }, horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ico(Icons.Filled.Description, 9f, Color.White); Spacer(Modifier.width(4.dp))
                    T("TEMPORARY HIDDEN LOG SUMMARY", 9f, Color.White, bold = true)
                }
                Ico(if (vm.summaryExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, 10f, C.Z500)
            }
            if (vm.summaryExpanded) {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(C.Z900))
                    T("Auto-updated every 10 system logs via 2nd API. Resets at midnight.", 7f, Color(0xFF52525B), italic = true)
                    Box(Modifier.fillMaxWidth().heightIn(max = 128.dp).background(C.Z950, RoundedCornerShape(4.dp)).border(1.dp, C.Z900, RoundedCornerShape(4.dp)).padding(8.dp).verticalScroll(rememberScrollState())) {
                        T(vm.s.logSummary.ifBlank { "No daily log summary recorded yet." }, 8f, C.Z400)
                    }
                }
            }
        }
    }
    Row(Modifier.padding(top = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FullBtn("Save System Settings", C.Red900, C.Red600, Color.White, { vm.saveSettings() }, Modifier.weight(1f))
        Box(Modifier.background(C.Z900).border(1.dp, C.Z800).tap { vm.toggleSettings() }.padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
            T("CANCEL", 9f, C.Z400)
        }
    }
}

@Composable
private fun GuideModal(vm: ShadowVM) = ModalBox(C.Cyan800) {
    ModalHeader("System_User_Guide", C.Cyan400, Icons.Filled.MenuBook, { vm.guideOpen = false })
    @Composable fun sec(h: String, col: Color, body: androidx.compose.ui.text.AnnotatedString) {
        Column(Modifier.padding(bottom = 12.dp)) {
            T(h, 11f, col, bold = true, modifier = Modifier.padding(bottom = 4.dp))
            Text(body, fontSize = 10.sp, color = C.Z300, fontFamily = Fonts.body, lineHeight = 16.sp)
        }
    }
    fun plain(t: String) = buildAnnotatedString { append(t) }
    fun withBold(pre: String, b: String, post: String) = buildAnnotatedString { append(pre); withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(b) }; append(post) }

    sec("1. System Level & Stats (XP & SP)", C.Red500, plain("Gain XP by logging hydration, food, daily objectives, and prayer rituals. SP (Stat Points) is generated as you gain total XP and can be spent on Black Market items or Staking Contracts."))
    sec("2. AI Neural Link & Custom Lore", C.Cyan400, withBold("Configure your personal scenario and Gemini API Keys in ", "Settings (Gear Icon)", ". The AI will speak like an authoritative drama system and issue realistic, tailored tasks based on your background prompt."))
    sec("3. Dynamic AI Quest Valuation", C.Z300, plain("The AI automatically assigns relative XP values based on task difficulty (+10 to +20 for quick items, +25 to +40 for medium focus, +50 to +75 for intense drills). Completing a task awards its specific XP value."))
    sec("4. 10-Log Automated AI Summarizer", C.Emerald400, withBold("Every 10 system logs, the ", "2nd API Key", " creates a hidden daily summary. This summary is injected into your prompt file so the AI knows what you did during the day. Both raw logs and this summary reset automatically at midnight!"))
    sec("5. Automatic Screen Time", C.Purple400, plain("Allow Usage access once (phone icon, top right). Your real screen time is read live from the phone and every day gets a fresh limit based on your last 7 days. The day settles by itself at midnight: stay under the limit for XP, go over it for a penalty. Screenshot upload still works as a fallback."))
    sec("6. ElevenLabs Voice", C.Cyan400, plain("In Settings add your ElevenLabs API key and Voice ID, switch it ON and press TEST VOICE. Every spoken line then uses your ElevenLabs voice instead of the phone voice."))
    Spacer(Modifier.height(4.dp))
    FullBtn("Acknowledge & Exit", C.Cyan950, C.Cyan700, C.Cyan300, { vm.guideOpen = false }, Modifier.fillMaxWidth())
}
