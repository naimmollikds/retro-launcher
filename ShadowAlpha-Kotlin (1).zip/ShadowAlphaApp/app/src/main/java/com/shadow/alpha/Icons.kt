package com.shadow.alpha

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/** Ghost and skull aren't in the Material set, so they're drawn here. */
object ShadowIcons {
    val Ghost: ImageVector by lazy {
        ImageVector.Builder("Ghost", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(12f, 2f)
                curveTo(7.58f, 2f, 4f, 5.58f, 4f, 10f)
                lineTo(4f, 21f)
                lineTo(6.67f, 19f)
                lineTo(9.33f, 21f)
                lineTo(12f, 19f)
                lineTo(14.67f, 21f)
                lineTo(17.33f, 19f)
                lineTo(20f, 21f)
                lineTo(20f, 10f)
                curveTo(20f, 5.58f, 16.42f, 2f, 12f, 2f)
                close()
                moveTo(7.5f, 10f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, 3f, 0f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, -3f, 0f)
                close()
                moveTo(13.5f, 10f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, 3f, 0f)
                arcToRelative(1.5f, 1.5f, 0f, true, false, -3f, 0f)
                close()
            }
        }.build()
    }

    val Skull: ImageVector by lazy {
        ImageVector.Builder("Skull", 24.dp, 24.dp, 24f, 24f).apply {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                moveTo(12f, 2f)
                curveTo(7.58f, 2f, 4f, 5.13f, 4f, 9f)
                curveTo(4f, 11.38f, 5.19f, 13.47f, 7f, 14.74f)
                lineTo(7f, 19f)
                lineTo(9f, 19f)
                lineTo(9f, 21f)
                lineTo(11f, 21f)
                lineTo(11f, 19f)
                lineTo(13f, 19f)
                lineTo(13f, 21f)
                lineTo(15f, 21f)
                lineTo(15f, 19f)
                lineTo(17f, 19f)
                lineTo(17f, 14.74f)
                curveTo(18.81f, 13.47f, 20f, 11.38f, 20f, 9f)
                curveTo(20f, 5.13f, 16.42f, 2f, 12f, 2f)
                close()
                moveTo(7f, 10f)
                arcToRelative(2f, 2f, 0f, true, false, 4f, 0f)
                arcToRelative(2f, 2f, 0f, true, false, -4f, 0f)
                close()
                moveTo(13f, 10f)
                arcToRelative(2f, 2f, 0f, true, false, 4f, 0f)
                arcToRelative(2f, 2f, 0f, true, false, -4f, 0f)
                close()
            }
        }.build()
    }
}
