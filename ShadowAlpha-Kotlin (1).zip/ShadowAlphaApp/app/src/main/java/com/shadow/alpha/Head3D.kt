package com.shadow.alpha

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Vertices (x,y,z triples) + edges (vertex index pairs). Normalised so the model fits roughly in [-1, 1]. */
class WireMesh(val xyz: FloatArray, val edges: IntArray) {
    val vertexCount get() = xyz.size / 3
    val edgeCount get() = edges.size / 2
}

// ============================================================================
//  The ORIGINAL model from the web app: LeePerrySmith.glb (head + neck + shoulders scan).
//  Order of lookup:  1) app/src/main/assets/LeePerrySmith.glb  (bundled by the CI build)
//                    2) cached copy downloaded earlier       3) download once, then cache
//  If none is available yet, a built-in upper-body bust is shown (never a sphere).
// ============================================================================
object ModelLoader {
    const val FILE = "LeePerrySmith.glb"
    private const val ORIGINAL_URL =
        "https://raw.githubusercontent.com/mrdoob/three.js/master/examples/models/gltf/LeePerrySmith/LeePerrySmith.glb"

    suspend fun load(ctx: Context): WireMesh? = withContext(Dispatchers.IO) {
        val bundled: ByteArray? = try { ctx.assets.open(FILE).use { it.readBytes() } } catch (_: Exception) { null }
        var mesh: WireMesh? = bundled?.let { GlbParser.parse(it) }
        if (mesh != null) return@withContext mesh

        val cache = File(ctx.filesDir, FILE)
        if (cache.exists()) {
            mesh = try { GlbParser.parse(cache.readBytes()) } catch (_: Exception) { null }
            if (mesh != null) return@withContext mesh
            cache.delete()
        }
        try {
            val c = URL(ORIGINAL_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 30000
            if (c.responseCode == 200) {
                val data = c.inputStream.use { it.readBytes() }
                mesh = GlbParser.parse(data)
                if (mesh != null) cache.writeBytes(data)
            }
            c.disconnect()
        } catch (_: Exception) { }
        mesh
    }
}

/** Minimal binary-glTF (.glb) reader: positions + triangle indices -> unique wireframe edges. */
object GlbParser {
    private const val MAX_EDGES = 70000

    fun parse(data: ByteArray): WireMesh? = try { doParse(data) } catch (_: Throwable) { null }

    private fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val r = FloatArray(16)
        for (c in 0 until 4) for (row in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + row] * b[c * 4 + k]
            r[c * 4 + row] = s
        }
        return r
    }

    private fun nodeMatrix(n: JSONObject): FloatArray {
        val ma = n.optJSONArray("matrix")
        if (ma != null && ma.length() == 16) return FloatArray(16) { ma.getDouble(it).toFloat() }
        val t = n.optJSONArray("translation"); val r = n.optJSONArray("rotation"); val s = n.optJSONArray("scale")
        val tx = t?.getDouble(0)?.toFloat() ?: 0f; val ty = t?.getDouble(1)?.toFloat() ?: 0f; val tz = t?.getDouble(2)?.toFloat() ?: 0f
        val x = r?.getDouble(0)?.toFloat() ?: 0f; val y = r?.getDouble(1)?.toFloat() ?: 0f
        val z = r?.getDouble(2)?.toFloat() ?: 0f; val w = r?.getDouble(3)?.toFloat() ?: 1f
        val sx = s?.getDouble(0)?.toFloat() ?: 1f; val sy = s?.getDouble(1)?.toFloat() ?: 1f; val sz = s?.getDouble(2)?.toFloat() ?: 1f
        val xx = x * x; val yy = y * y; val zz = z * z
        val xy = x * y; val xz = x * z; val yz = y * z
        val wx = w * x; val wy = w * y; val wz = w * z
        return floatArrayOf(
            (1 - 2 * (yy + zz)) * sx, (2 * (xy + wz)) * sx, (2 * (xz - wy)) * sx, 0f,
            (2 * (xy - wz)) * sy, (1 - 2 * (xx + zz)) * sy, (2 * (yz + wx)) * sy, 0f,
            (2 * (xz + wy)) * sz, (2 * (yz - wx)) * sz, (1 - 2 * (xx + yy)) * sz, 0f,
            tx, ty, tz, 1f
        )
    }

    private fun doParse(data: ByteArray): WireMesh? {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        if (bb.int != 0x46546C67) return null          // "glTF"
        bb.int; bb.int                                  // version, total length
        var json: JSONObject? = null
        var binOff = -1
        while (bb.remaining() >= 8) {
            val len = bb.int; val type = bb.int
            val start = bb.position()
            if (type == 0x4E4F534A) json = JSONObject(String(data, start, len, Charsets.UTF_8))
            else if (type == 0x004E4942 && binOff < 0) binOff = start
            bb.position(start + len)
        }
        val j = json ?: return null
        if (binOff < 0) return null
        val accessors = j.optJSONArray("accessors") ?: return null
        val views = j.optJSONArray("bufferViews") ?: return null
        val meshes = j.optJSONArray("meshes") ?: return null

        val posChunks = ArrayList<FloatArray>()
        val idxChunks = ArrayList<IntArray>()
        var vBase = 0

        fun bounds(acc: JSONObject): IntArray? {
            val vi = acc.optInt("bufferView", -1)
            if (vi < 0) return null
            val v = views.getJSONObject(vi)
            return intArrayOf(binOff + v.optInt("byteOffset", 0) + acc.optInt("byteOffset", 0), v.optInt("byteStride", 0))
        }

        fun readPositions(ai: Int, m: FloatArray): FloatArray? {
            val acc = accessors.getJSONObject(ai)
            if (acc.optInt("componentType") != 5126 || acc.optString("type") != "VEC3") return null
            val st = bounds(acc) ?: return null
            val stride = if (st[1] > 0) st[1] else 12
            val n = acc.getInt("count")
            val out = FloatArray(n * 3)
            for (i in 0 until n) {
                val o = st[0] + i * stride
                val x = bb.getFloat(o); val y = bb.getFloat(o + 4); val z = bb.getFloat(o + 8)
                out[i * 3] = m[0] * x + m[4] * y + m[8] * z + m[12]
                out[i * 3 + 1] = m[1] * x + m[5] * y + m[9] * z + m[13]
                out[i * 3 + 2] = m[2] * x + m[6] * y + m[10] * z + m[14]
            }
            return out
        }

        fun readIndices(ai: Int): IntArray? {
            val acc = accessors.getJSONObject(ai)
            val st = bounds(acc) ?: return null
            val n = acc.getInt("count")
            val ct = acc.optInt("componentType")
            val size = when (ct) { 5121 -> 1; 5123 -> 2; 5125 -> 4; else -> return null }
            val stride = if (st[1] > 0) st[1] else size
            return IntArray(n) { i ->
                val o = st[0] + i * stride
                when (ct) {
                    5121 -> bb.get(o).toInt() and 0xFF
                    5123 -> bb.getShort(o).toInt() and 0xFFFF
                    else -> bb.getInt(o)
                }
            }
        }

        fun addMesh(mi: Int, world: FloatArray) {
            val prims = meshes.getJSONObject(mi).optJSONArray("primitives") ?: return
            for (p in 0 until prims.length()) {
                val prim = prims.getJSONObject(p)
                if (prim.optInt("mode", 4) != 4) continue
                val posIdx = prim.optJSONObject("attributes")?.optInt("POSITION", -1) ?: -1
                if (posIdx < 0) continue
                val pos = readPositions(posIdx, world) ?: continue        // Draco-compressed primitives are skipped
                val count = pos.size / 3
                val ii = if (prim.has("indices")) readIndices(prim.getInt("indices")) ?: continue
                         else IntArray(count - count % 3) { it }
                posChunks.add(pos)
                idxChunks.add(IntArray(ii.size) { ii[it] + vBase })
                vBase += count
            }
        }

        val nodes = j.optJSONArray("nodes")
        val identity = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
        fun visit(ni: Int, parent: FloatArray, depth: Int) {
            if (nodes == null || depth > 32) return
            val n = nodes.getJSONObject(ni)
            val world = mul(parent, nodeMatrix(n))
            if (n.has("mesh")) addMesh(n.getInt("mesh"), world)
            val ch = n.optJSONArray("children")
            if (ch != null) for (c in 0 until ch.length()) visit(ch.getInt(c), world, depth + 1)
        }

        if (nodes == null) {
            for (m in 0 until meshes.length()) addMesh(m, identity)
        } else {
            val scenes = j.optJSONArray("scenes")
            val roots = scenes?.optJSONObject(j.optInt("scene", 0))?.optJSONArray("nodes")
            if (roots != null) {
                for (r in 0 until roots.length()) visit(roots.getInt(r), identity, 0)
            } else {
                val child = BooleanArray(nodes.length())
                for (i in 0 until nodes.length()) {
                    val ch = nodes.getJSONObject(i).optJSONArray("children") ?: continue
                    for (c in 0 until ch.length()) child[ch.getInt(c)] = true
                }
                for (i in 0 until nodes.length()) if (!child[i]) visit(i, identity, 0)
            }
        }
        if (vBase == 0) return null

        // ---- merge + normalise (centre on origin, longest side = 2 units) ----
        val xyz = FloatArray(vBase * 3)
        var off = 0
        for (c in posChunks) { System.arraycopy(c, 0, xyz, off, c.size); off += c.size }
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
        for (k in 0 until vBase) {
            val x = xyz[3 * k]; val y = xyz[3 * k + 1]; val z = xyz[3 * k + 2]
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val ext = max(maxX - minX, max(maxY - minY, maxZ - minZ))
        if (ext <= 0f) return null
        val sc = 2f / ext
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f; val cz = (minZ + maxZ) / 2f
        for (k in 0 until vBase) {
            xyz[3 * k] = (xyz[3 * k] - cx) * sc
            xyz[3 * k + 1] = (xyz[3 * k + 1] - cy) * sc
            xyz[3 * k + 2] = (xyz[3 * k + 2] - cz) * sc
        }

        // ---- unique edges from triangles ----
        var triVerts = 0
        for (c in idxChunks) triVerts += c.size - c.size % 3
        val keys = LongArray(triVerts)
        var kc = 0
        for (c in idxChunks) {
            var t = 0
            while (t + 2 < c.size) {
                val a = c[t]; val b = c[t + 1]; val d = c[t + 2]
                t += 3
                if (a < 0 || b < 0 || d < 0 || a >= vBase || b >= vBase || d >= vBase) continue
                keys[kc++] = (min(a, b).toLong() shl 32) or max(a, b).toLong()
                keys[kc++] = (min(b, d).toLong() shl 32) or max(b, d).toLong()
                keys[kc++] = (min(d, a).toLong() shl 32) or max(d, a).toLong()
            }
        }
        if (kc == 0) return null
        val used = keys.copyOf(kc)
        used.sort()
        var uniq = 0
        for (i in used.indices) if (i == 0 || used[i] != used[i - 1]) used[uniq++] = used[i]
        val stride = max(1, ceil(uniq / MAX_EDGES.toDouble()).toInt())
        val outCount = (uniq + stride - 1) / stride
        val edges = IntArray(outCount * 2)
        var e = 0
        var i = 0
        while (i < uniq) {
            edges[e++] = (used[i] shr 32).toInt()
            edges[e++] = (used[i] and 0xFFFFFFFFL).toInt()
            i += stride
        }
        return WireMesh(xyz, edges)
    }
}

// ============================================================================
//  Fallback: procedural UPPER BODY (head, neck, shoulders, chest) - used until the real model is available.
// ============================================================================
object Bust {
    private const val LON = 40
    private const val ROWS = 52

    private fun smooth(t: Float): Float { val c = t.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }

    /** returns (halfWidth, halfDepth, zCentre) of the horizontal slice at height y (y in -1..1) */
    private fun section(y: Float): FloatArray {
        val t = (y - 0.62f) / 0.38f
        var ha = 0f; var hb = 0f
        if (abs(t) < 1f) {
            val s = sqrt(1f - t * t)
            val jaw = if (t < 0f) 1f - 0.32f * smooth(-t) else 1f
            ha = 0.30f * s * jaw
            hb = 0.34f * s * (if (t < 0f) 1f - 0.12f * smooth(-t) else 1f)
        }
        if (y >= 0.06f) {
            val inNeck = y <= 0.36f
            val na = if (inNeck) 0.135f else 0f
            val nb = if (inNeck) 0.15f else 0f
            return if (ha > na) floatArrayOf(ha, hb, 0f) else floatArrayOf(na, nb, -0.04f)
        }
        val u = smooth((0.06f - y) / 0.26f)
        var ta = 0.135f + (0.72f - 0.135f) * u
        var tb = 0.15f + (0.25f - 0.15f) * u
        if (y < -0.2f) { val v = ((-0.2f - y) / 0.8f).coerceIn(0f, 1f); ta = 0.72f - 0.08f * v; tb = 0.25f }
        return floatArrayOf(ta, tb, -0.02f)
    }

    fun build(): WireMesh {
        val n = (ROWS + 1) * LON
        val xyz = FloatArray(n * 3)
        for (i in 0..ROWS) {
            val y = 1f - 2f * i / ROWS
            val sec = section(y)
            val pw = if (y < 0.06f) 0.8f else 1f           // squarer torso
            for (j in 0 until LON) {
                val ph = (2.0 * PI * j / LON).toFloat()
                val sn = sin(ph); val cs = cos(ph)
                val x = sec[0] * sign(sn) * abs(sn).pow(pw)
                var z = sec[2] + sec[1] * sign(cs) * abs(cs).pow(pw)
                if (y > 0.3f && z > sec[2] + 0.02f) {
                    z += 0.11f * exp(-((x / 0.05f).pow(2) + ((y - 0.55f) / 0.11f).pow(2)))          // nose
                    for (ex in floatArrayOf(-0.11f, 0.11f))
                        z -= 0.035f * exp(-(((x - ex) / 0.06f).pow(2) + ((y - 0.70f) / 0.035f).pow(2))) // eye sockets
                    z += 0.025f * exp(-((y - 0.76f) / 0.03f).pow(2))                                    // brow
                    z += 0.025f * exp(-((x / 0.10f).pow(2) + ((y - 0.42f) / 0.03f).pow(2)))             // lips
                }
                val idx = (i * LON + j) * 3
                xyz[idx] = x; xyz[idx + 1] = y; xyz[idx + 2] = z
            }
        }
        val edges = IntArray((ROWS + 1) * LON * 2 + ROWS * LON * 2)
        var e = 0
        for (i in 0..ROWS) for (j in 0 until LON) {
            val a = i * LON + j
            edges[e++] = a; edges[e++] = i * LON + (j + 1) % LON
            if (i < ROWS) { edges[e++] = a; edges[e++] = (i + 1) * LON + j }
        }
        return WireMesh(xyz, edges.copyOf(e))
    }
}

private class RenderBuf(mesh: WireMesh) {
    val px = FloatArray(mesh.vertexCount)
    val py = FloatArray(mesh.vertexCount)
    val pz = FloatArray(mesh.vertexCount)
    val front = FloatArray(mesh.edgeCount * 4)
    val back = FloatArray(mesh.edgeCount * 4)
}

/** Rotating red wireframe bust (same look as the web version: dark wireframe, red emissive glow, slow Y spin). */
@Composable
fun Head3D(skin: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current.applicationContext
    val fallback = remember { Bust.build() }
    var loaded by remember { mutableStateOf<WireMesh?>(null) }
    LaunchedEffect(Unit) { loaded = ModelLoader.load(ctx) }
    val mesh = loaded ?: fallback
    val buf = remember(mesh) { RenderBuf(mesh) }

    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { t ->
                if (last != 0L) angle += 0.003f * ((t - last) / 16_666_667f)
                last = t
            }
        }
    }
    val base = when (skin) {
        "gold" -> Color(0xFFFFD700)
        "diamond" -> Color(0xFF00FFFF)
        "platinum" -> Color(0xFFE5E4E2)
        else -> Color(0xFFFF0000)
    }
    val frontPaint = remember { android.graphics.Paint().apply { isAntiAlias = true; style = android.graphics.Paint.Style.STROKE } }
    val backPaint = remember { android.graphics.Paint().apply { isAntiAlias = true; style = android.graphics.Paint.Style.STROKE } }

    Canvas(modifier) {
        val h = size.height
        val cx = size.width / 2f; val cy = h / 2f
        val camZ = 4.5f
        val f = (h / 2f) / tan(Math.toRadians(20.0)).toFloat()
        val scale = 1.35f
        val ca = cos(angle); val sa = sin(angle)
        val xyz = mesh.xyz
        for (k in 0 until mesh.vertexCount) {
            val x = xyz[3 * k] * scale
            val y = xyz[3 * k + 1] * scale - 0.05f
            val z = xyz[3 * k + 2] * scale
            val xr = x * ca + z * sa
            val zr = -x * sa + z * ca
            val d = camZ - zr
            buf.px[k] = cx + xr * f / d
            buf.py[k] = cy - y * f / d
            buf.pz[k] = zr
        }
        var fc = 0; var bc = 0
        val ed = mesh.edges
        for (m in 0 until mesh.edgeCount) {
            val a = ed[2 * m]; val b = ed[2 * m + 1]
            if (buf.pz[a] + buf.pz[b] > 0f) {
                buf.front[fc++] = buf.px[a]; buf.front[fc++] = buf.py[a]
                buf.front[fc++] = buf.px[b]; buf.front[fc++] = buf.py[b]
            } else {
                buf.back[bc++] = buf.px[a]; buf.back[bc++] = buf.py[a]
                buf.back[bc++] = buf.px[b]; buf.back[bc++] = buf.py[b]
            }
        }
        val dense = mesh.edgeCount > 8000
        frontPaint.color = base.copy(alpha = if (dense) 0.55f else 0.85f).toArgb()
        backPaint.color = base.copy(alpha = if (dense) 0.10f else 0.22f).toArgb()
        frontPaint.strokeWidth = (if (dense) 0.7f else 1.1f) * density
        backPaint.strokeWidth = frontPaint.strokeWidth
        drawIntoCanvas { cv ->
            cv.nativeCanvas.drawLines(buf.back, 0, bc, backPaint)
            cv.nativeCanvas.drawLines(buf.front, 0, fc, frontPaint)
        }
    }
}
