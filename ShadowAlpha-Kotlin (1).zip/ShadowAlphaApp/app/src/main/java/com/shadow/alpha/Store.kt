package com.shadow.alpha

import android.content.Context
import kotlinx.serialization.json.Json
import java.io.File
import java.util.concurrent.Executors

/** Everything is stored on the phone, so the whole app works with no internet. */
class Store(private val ctx: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; isLenient = true }
    private val main = File(ctx.filesDir, "shadow_state.json")
    private val backup = File(ctx.filesDir, "shadow_state.bak")
    private val io = Executors.newSingleThreadExecutor()
    val mediaDir: File get() = File(ctx.filesDir, "media").apply { mkdirs() }

    fun load(): AppState {
        for (f in listOf(main, backup)) {
            try {
                if (f.exists()) return json.decodeFromString(AppState.serializer(), f.readText())
            } catch (_: Exception) { /* try the backup copy */ }
        }
        return AppState()
    }

    fun save(s: AppState) {
        val text = try { json.encodeToString(AppState.serializer(), s) } catch (_: Exception) { return }
        io.execute {
            try {
                val tmp = File(ctx.filesDir, "shadow_state.tmp")
                tmp.writeText(text)
                if (main.exists()) main.copyTo(backup, overwrite = true)
                tmp.renameTo(main)
            } catch (_: Exception) { }
        }
    }

    fun wipe() {
        io.execute {
            main.delete(); backup.delete()
            mediaDir.deleteRecursively()
        }
    }
}
