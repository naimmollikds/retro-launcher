package com.shadow.alpha

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: ShadowVM by viewModels()
    private var recognizer: SpeechRecognizer? = null
    private var pendingVoice: (() -> Unit)? = null

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingVoice?.invoke() else vm.pushLog("MICROPHONE PERMISSION DENIED", true)
        pendingVoice = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.BLACK), SystemBarStyle.dark(AColor.BLACK))
        loadFonts()

        setContent {
            val attach = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::attachFile) }
            val stInit = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.stInitUri = u; vm.stInitName = vm.displayName(u) } }
            val stProof = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.stProofUri = u; vm.stProofName = vm.displayName(u) } }
            val taskProof = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.taskProofUri = u; vm.taskProofName = vm.displayName(u) } }
            val ctxFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::loadContextFile) }

            val actions = Actions(
                pickAttach = { attach.launch("*/*") },
                pickStInit = { stInit.launch("image/*") },
                pickStProof = { stProof.launch("image/*") },
                pickTaskProof = { taskProof.launch("image/*") },
                pickContext = { ctxFile.launch("text/*") },
                startVoice = { listen({ vm.micActive = it }) { t -> vm.noteInput += t } },
                startGhostVoice = { listen({ vm.ghostMicActive = it }) { t -> vm.aiQuery = t; vm.askGhost() } },
                openFile = { openFile(it) }
            )

            BackHandler(enabled = anyModal()) { closeTopModal() }
            ShadowApp(vm, actions)
        }
    }

    private fun anyModal() = vm.stProofOpen || vm.taskProofIdx != null || vm.taskInfoIdx != null ||
        vm.purgeOpen || vm.settingsOpen || vm.guideOpen

    private fun closeTopModal() {
        when {
            vm.guideOpen -> vm.guideOpen = false
            vm.settingsOpen -> vm.settingsOpen = false
            vm.purgeOpen -> vm.purgeOpen = false
            vm.taskInfoIdx != null -> vm.taskInfoIdx = null
            vm.taskProofIdx != null -> vm.closeTaskProof()
            vm.stProofOpen -> vm.stProofOpen = false
        }
    }

    /** Uses Archivo Black / Space Mono if you drop the .ttf files into app/src/main/assets/fonts/ */
    private fun loadFonts() {
        try {
            val have = assets.list("fonts")?.toSet() ?: emptySet()
            if ("ArchivoBlack-Regular.ttf" in have) {
                Fonts.title = FontFamily(Font("fonts/ArchivoBlack-Regular.ttf", assets, FontWeight.Black))
                Fonts.hasTitleFont = true
            }
            val list = ArrayList<Font>()
            if ("SpaceMono-Regular.ttf" in have) list.add(Font("fonts/SpaceMono-Regular.ttf", assets, FontWeight.Normal))
            if ("SpaceMono-Bold.ttf" in have) list.add(Font("fonts/SpaceMono-Bold.ttf", assets, FontWeight.Bold))
            if (list.isNotEmpty()) Fonts.body = FontFamily(list)
        } catch (_: Throwable) { }
    }

    /** Offline-capable speech-to-text (uses the phone's own recognizer; works offline if the language pack is installed). */
    private fun listen(setActive: (Boolean) -> Unit, onText: (String) -> Unit) {
        val start = {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                vm.pushLog("VOICE ENGINE UNAVAILABLE ON THIS DEVICE", true)
            } else {
                recognizer?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer = r
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) { setActive(true); vm.haptic(30) }
                    override fun onResults(res: Bundle?) {
                        setActive(false)
                        res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
                    }
                    override fun onError(e: Int) { setActive(false) }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(b: Bundle?) {}
                    override fun onEvent(t: Int, b: Bundle?) {}
                })
                r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                })
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
        else { pendingVoice = start; micPermission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun openFile(f: AttachedFile) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", File(f.path))
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, f.type.ifBlank { "*/*" })
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Exception) { vm.pushLog("NO APP FOUND TO OPEN THIS FILE", true) }
    }

    override fun onResume() { super.onResume(); vm.refreshUsage() }

    override fun onDestroy() { recognizer?.destroy(); super.onDestroy() }
}

@Composable
fun ShadowApp(vm: ShadowVM, a: Actions) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().imePadding()) {
            Header(vm)
            Column(
                Modifier.weight(1f).fillMaxWidth().background(Color.Black)
                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 15.dp)
            ) {
                when (vm.tab) {
                    0 -> NeuralPane(vm, a)
                    1 -> VitalsPane(vm)
                    2 -> QuestsPane(vm)
                    3 -> BoltPane(vm)
                    else -> CharPane(vm, a)
                }
            }
            Nav(vm)
        }
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) { Modals(vm, a) }
    }
}
