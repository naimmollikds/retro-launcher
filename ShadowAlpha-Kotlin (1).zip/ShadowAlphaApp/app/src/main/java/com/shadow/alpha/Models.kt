package com.shadow.alpha

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val text: String,
    val xp: Int = 20,
    val done: Boolean = false,
    val isScreenTime: Boolean = false,
    val requiresProof: Boolean = false,
    val proofInstruction: String = ""
)

@Serializable
data class LogEntry(val ts: String, val text: String)

@Serializable
data class AttachedFile(val name: String, val type: String, val path: String)

@Serializable
data class Note(val id: Long, val text: String, val file: AttachedFile? = null, val date: String)

@Serializable
data class Contract(val type: String, val cost: Int, val reward: Int)

@Serializable
data class AppState(
    val lvl: Int = 1,
    val xp: Double = 0.0,
    val totalXP: Double = 0.0,
    val spentSP: Double = 0.0,
    val water: Int = 0,
    val lastW: Int = 0,
    val hp: Int = 100,
    val tasks: List<Task> = emptyList(),
    val logs: List<LogEntry> = emptyList(),
    val noteArchive: List<Note> = emptyList(),
    val activeContract: Contract? = null,
    val tasbih: Int = 0,
    val salah: List<Boolean> = List(5) { false },
    val lastReset: String = "",
    val activeSkin: String = "default",
    val xpMult: Int = 1,
    val skinExpiry: Long = 0,
    val geminiKey1: String = "",
    val geminiKey2: String = "",
    val systemPrompt: String = "",
    val logCounter: Int = 0,
    val logSummary: String = "",
    val screenTimeInitialized: Boolean = false,
    val screenTimeHistory: String = "",
    val targetMaxScreenTimeHours: Double = 0.0,
    val targetMaxScreenTimeMinutes: Int = 0,
    val screenTimeProofSubmitted: Boolean = false,
    /** True when the 10-log summary could not run (offline) and should be retried once online. */
    val pendingSummary: Boolean = false,
    /** Day (yyyy-MM-dd) the automatic daily screen-time limit was last calculated for. */
    val limitDate: String = "",
    /** Minutes of phone usage at the moment today's result was settled (-1 = not settled). */
    val screenTimeSettledMin: Int = -1,
    val elevenOn: Boolean = false,
    val elevenKey: String = "",
    val elevenVoiceId: String = "",
    val elevenModel: String = "eleven_flash_v2_5"
)
