package com.shadow.alpha

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** The ONLY part of the app that needs internet. */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private val modelCache = HashMap<String, String>()

    private val priority = listOf(
        "models/gemini-3.1-flash-lite",
        "models/gemini-2.5-flash",
        "models/gemini-2.0-flash",
        "models/gemini-1.5-flash",
        "models/gemini-1.0-pro"
    )

    suspend fun bestModel(key: String): String? = withContext(Dispatchers.IO) {
        modelCache[key]?.let { return@withContext it }
        try {
            val c = URL("$BASE/models?key=$key").openConnection() as HttpURLConnection
            c.connectTimeout = 15000; c.readTimeout = 20000
            if (c.responseCode != 200) return@withContext null
            val models = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("models")
                ?: return@withContext null
            val usable = ArrayList<String>()
            for (i in 0 until models.length()) {
                val m = models.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                for (j in 0 until methods.length()) {
                    if (methods.getString(j) == "generateContent") { usable.add(m.getString("name")); break }
                }
            }
            if (usable.isEmpty()) return@withContext null
            val pick = priority.firstOrNull { it in usable } ?: usable[0]
            val id = pick.removePrefix("models/")
            modelCache[key] = id
            id
        } catch (_: Exception) { null }
    }

    /** Returns the model's text, or null on any failure. */
    suspend fun generate(
        key: String, model: String, prompt: String,
        imageB64: String? = null, mime: String = "image/jpeg"
    ): String? = withContext(Dispatchers.IO) {
        try {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            if (imageB64 != null) {
                parts.put(JSONObject().put("inline_data",
                    JSONObject().put("mime_type", mime).put("data", imageB64)))
            }
            val body = JSONObject().put("contents",
                JSONArray().put(JSONObject().put("parts", parts))).toString()

            val c = URL("$BASE/models/$model:generateContent?key=$key").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 20000; c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode != 200) return@withContext null
            val resp = JSONObject(c.inputStream.bufferedReader().readText())
            resp.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim()
        } catch (_: Exception) { null }
    }

    private fun stripFences(t: String) =
        t.replace(Regex("```json", RegexOption.IGNORE_CASE), "").replace("```", "").trim()

    fun parseObject(t: String): JSONObject? = try { JSONObject(stripFences(t)) } catch (_: Exception) { null }
    fun parseArray(t: String): JSONArray? = try { JSONArray(stripFences(t)) } catch (_: Exception) { null }

    /** Reads an image from the phone, shrinks it, and returns (base64, mime). */
    fun imageToBase64(ctx: Context, uri: Uri): Pair<String, String>? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) null else {
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
            Pair(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), "image/jpeg")
        }
    } catch (_: Exception) { null }
}
