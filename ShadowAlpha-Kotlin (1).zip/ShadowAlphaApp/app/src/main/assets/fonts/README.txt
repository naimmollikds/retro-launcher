OPTIONAL - exact fonts from the original web app
-------------------------------------------------
Drop these files in this folder (names must match exactly) and rebuild:

  ArchivoBlack-Regular.ttf   (headings, buttons, timer)
  SpaceMono-Regular.ttf      (body text)
  SpaceMono-Bold.ttf         (bold body text)

Both are free on Google Fonts. If a file is missing the app falls back to the
phone's built-in bold sans / monospace font.
