# Neural HUD — Cyberpunk RPG Focus Tracker (Android)

Kotlin · Jetpack Compose · Room · WorkManager · CameraX · Gemini REST API. Package `com.rpg.tracker`, minSdk 29, targetSdk 34.

## Run
1. Open the folder in **Android Studio Koala+** (JDK 17), let Gradle sync.
2. CLI builds: run `gradle wrapper --gradle-version 8.7` once to generate `gradlew`, then `./gradlew assembleDebug`.
3. In the app: add Gemini API key(s) in Settings → refresh model list → grant Camera, Usage access, Overlay → switch on the Neural Scanner.

## Push to GitHub
```bash
cd rpg-tracker
git init && git add . && git commit -m "Initial commit: Neural HUD"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
# or with GitHub CLI: gh repo create <repo> --private --source=. --push
```
Zip: `zip -r rpg-tracker.zip rpg-tracker -x "*/build/*" "*/.gradle/*"`. A CI workflow (`.github/workflows/android.yml`) builds the debug APK on every push.

## Game rules
- Productive scan: +10 XP, level-up at `100 + 50*(level-1)` XP (+20 HP). Distracted scan: -5 HP.
- AI returns `LOCKDOWN_INITIATED` (or 3 distracted scans in a row) → full-screen overlay. Blocked app in foreground = -10 HP per minute (`HpDrainWorker`). 3 clean minutes lift the lockdown.
- HP 0 → Game Over: bonus XP locked 24 h or until the Rest Task button is pressed (HP restored to 30).

## Platform limits worth knowing
- **Camera in background:** Android 11+ only allows camera access from a foreground service started while the app is visible. The scanner shows a persistent notification and the system camera indicator; it cannot be silent. Frames are kept in memory, downscaled, sent to Gemini, never saved. WorkManager's 15-minute minimum means the 2–5 min loop lives in the service; `UsageTrackerWorker` is the usage-only fallback.
- **Doze/battery:** the 1-minute HP drain job can be delayed by the OS. Exempt the app from battery optimisation for strict timing.
- **Play Store:** `SYSTEM_ALERT_WINDOW`, `PACKAGE_USAGE_STATS` and camera FGS need policy declarations; this is intended for sideload / personal use.
- Gemini model ids change; the Settings dropdown is populated from `models.list`. Default is `gemini-3.1-flash-lite`: pick another if it is not listed for your key.
- API keys are kept in `EncryptedSharedPreferences`; no keys live in the repo.
