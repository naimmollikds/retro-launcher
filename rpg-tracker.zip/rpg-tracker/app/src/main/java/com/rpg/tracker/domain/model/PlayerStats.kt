package com.rpg.tracker.domain.model

const val MAX_HP = 100
const val XP_PER_PRODUCTIVE_SCAN = 10
const val HP_PER_DISTRACTED_SCAN = 5
const val HP_DRAIN_PER_MINUTE = 10
const val LEVEL_UP_HEAL = 20
const val REST_RESTORE_HP = 30
const val GAME_OVER_LOCK_MS = 24L * 60 * 60 * 1000
const val DISTRACTION_STREAK_FOR_LOCKDOWN = 3
const val CLEAN_MINUTES_TO_RELEASE = 3
const val CMD_LOCKDOWN = "LOCKDOWN_INITIATED"

fun xpForLevel(level: Int): Int = 100 + (level - 1) * 50

enum class Verdict { PRODUCTIVE, NEUTRAL, DISTRACTED }
enum class LogType { INFO, XP, LEVEL_UP, DAMAGE, LOCKDOWN, SYSTEM }

/** Parsed result of one Gemini evaluation. */
data class AiVerdict(val verdict: Verdict, val summary: String, val command: String? = null)

data class PlayerStats(
    val level: Int = 1,
    val xp: Int = 0,
    val hp: Int = MAX_HP,
    val lockdownActive: Boolean = false,
    val bonusXpLockedUntil: Long = 0L,
    val restTaskPending: Boolean = false,
    val currentApp: String = "",
    val lastVerdict: String = "",
    val lastSummary: String = "",
    val distractedStreak: Int = 0,
    val lastDistractionPkg: String = ""
) {
    val xpToNext: Int get() = xpForLevel(level)
    /** Game over == HP hit 0 and the Rest Task has not been completed yet. */
    val isGameOver: Boolean get() = restTaskPending
}

data class ActivityLog(val id: Long, val timestamp: Long, val type: LogType, val message: String)
