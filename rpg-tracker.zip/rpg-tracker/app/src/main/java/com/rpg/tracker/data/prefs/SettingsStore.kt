package com.rpg.tracker.data.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API keys and settings, stored with AES-256 encrypted SharedPreferences. */
class SettingsStore private constructor(context: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "rpg_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun lines(key: String): List<String> =
        prefs.getString(key, null)?.split("\n")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()

    var apiKeys: List<String>
        get() = lines(K_KEYS)
        set(v) = prefs.edit().putString(K_KEYS, v.joinToString("\n")).apply()

    var activeKeyIndex: Int
        get() = prefs.getInt(K_ACTIVE, 0)
        set(v) = prefs.edit().putInt(K_ACTIVE, v).apply()

    var model: String
        get() = prefs.getString(K_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString(K_MODEL, v).apply()

    var cachedModels: List<String>
        get() = lines(K_MODELS)
        set(v) = prefs.edit().putString(K_MODELS, v.joinToString("\n")).apply()

    var snapshotIntervalMin: Int
        get() = prefs.getInt(K_INTERVAL, 3).coerceIn(2, 5)
        set(v) = prefs.edit().putInt(K_INTERVAL, v.coerceIn(2, 5)).apply()

    var scannerEnabled: Boolean
        get() = prefs.getBoolean(K_SCANNER, false)
        set(v) = prefs.edit().putBoolean(K_SCANNER, v).apply()

    var blockedPackages: Set<String>
        get() = if (prefs.contains(K_BLOCKED)) lines(K_BLOCKED).toSet() else DEFAULT_BLOCKED
        set(v) = prefs.edit().putString(K_BLOCKED, v.joinToString("\n")).apply()

    var lastHeartbeat: Long
        get() = prefs.getLong(K_HEARTBEAT, 0L)
        set(v) = prefs.edit().putLong(K_HEARTBEAT, v).apply()

    var cleanMinutes: Int
        get() = prefs.getInt(K_CLEAN, 0)
        set(v) = prefs.edit().putInt(K_CLEAN, v).apply()

    companion object {
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
        val DEFAULT_MODELS = listOf("gemini-3.1-flash-lite", "gemini-1.5-flash")
        val DEFAULT_BLOCKED = setOf(
            "com.instagram.android", "com.facebook.katana", "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill", "com.google.android.youtube", "com.twitter.android",
            "com.snapchat.android", "com.reddit.frontpage", "com.netflix.mediaclient"
        )
        private const val K_KEYS = "api_keys"
        private const val K_ACTIVE = "active_key"
        private const val K_MODEL = "model"
        private const val K_MODELS = "models"
        private const val K_INTERVAL = "interval_min"
        private const val K_SCANNER = "scanner_enabled"
        private const val K_BLOCKED = "blocked"
        private const val K_HEARTBEAT = "heartbeat"
        private const val K_CLEAN = "clean_minutes"

        @Volatile private var instance: SettingsStore? = null
        fun get(context: Context): SettingsStore = instance ?: synchronized(this) {
            instance ?: SettingsStore(context.applicationContext).also { instance = it }
        }
    }
}
