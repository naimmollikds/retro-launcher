package com.rpg.tracker.ui.theme

import androidx.compose.ui.graphics.Color

val CharcoalBlack = Color(0xFF0B0E14)
val NeonCyan = Color(0xFF00F0FF)
val NeonPurple = Color(0xFFBD00FF)
val CrimsonRed = Color(0xFFFF0055)   // HP / lockdown warnings
val EmeraldGreen = Color(0xFF00FF66) // XP / level ups
val SurfaceDark = Color(0xFF121722)
val TextPrimary = Color(0xFFE6F7FF)
val GlassHighlight = Color(0x1AFFFFFF)
val GlassBase = Color(0x08FFFFFF)
