package com.rpg.tracker.ui.lockdown

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rpg.tracker.R
import com.rpg.tracker.RpgTrackerApp
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.domain.model.*
import com.rpg.tracker.service.UsageStatsProvider
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

private val CYAN = Color.parseColor("#00F0FF")
private val CRIMSON = Color.parseColor("#FF0055")
private val CHARCOAL = Color.argb(245, 11, 14, 20)

/**
 * Full-screen futuristic restriction overlay (TYPE_APPLICATION_OVERLAY, needs "Display over other apps").
 * While a lockdown is active it re-appears whenever a blocked app comes to the foreground.
 * HP penalties are applied by [HpDrainWorker]; this service only warns and reflects the live HP.
 */
class LockdownOverlayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var repo: GameRepository
    private lateinit var usage: UsageStatsProvider
    private var overlay: View? = null
    private var hpBar: ProgressBar? = null
    private var hpLabel: TextView? = null
    private var observeJob: Job? = null
    private var guardJob: Job? = null
    private var suppressUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        repo = GameRepository.get(this)
        usage = UsageStatsProvider(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (observeJob == null) {
            observeJob = scope.launch {
                repo.player.collect { p ->
                    if (!p.lockdownActive) {
                        removeOverlay()
                        stopSelf()
                    } else {
                        hpBar?.progress = p.hp
                        hpLabel?.text = "HP ${p.hp}/$MAX_HP"
                    }
                }
            }
        }
        if (guardJob == null) {
            guardJob = scope.launch {
                while (isActive) {
                    guardTick()
                    delay(3_000)
                }
            }
        }
        showOverlay()
        return START_STICKY
    }

    private suspend fun guardTick() {
        val p = repo.currentStats()
        if (!p.lockdownActive || overlay != null || System.currentTimeMillis() < suppressUntil) return
        val pkg = withContext(Dispatchers.IO) { usage.foregroundPackage() }
        if (repo.isBlocked(pkg, p)) showOverlay()
    }

    private fun showOverlay() {
        if (overlay != null) return
        val view = buildView()
        val params = WindowManager.LayoutParams(
            MATCH_PARENT, MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(view, params)
            overlay = view
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        hpBar = null
        hpLabel = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildView(): View {
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(CHARCOAL)
            setPadding(dp(28), dp(48), dp(28), dp(48))
        }
        fun label(txt: String, size: Float, color: Int, glow: Boolean = false) = TextView(this).apply {
            text = txt; textSize = size; setTextColor(color); typeface = mono; gravity = Gravity.CENTER
            if (glow) setShadowLayer(28f, 0f, 0f, color)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        }
        root.addView(label("⚠ LOCKDOWN INITIATED ⚠", 26f, CRIMSON, glow = true))
        root.addView(label("Distraction protocol engaged.\nStop using blocked apps and return to your mission.", 14f, Color.WHITE))
        hpLabel = label("HP …", 16f, CRIMSON)
        root.addView(hpLabel)
        hpBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = MAX_HP
            progressTintList = ColorStateList.valueOf(CRIMSON)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(60, 255, 255, 255))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(14)).apply { topMargin = dp(8) }
        }
        root.addView(hpBar)
        root.addView(label("Penalty: -$HP_DRAIN_PER_MINUTE HP every minute you stay in a blocked app.", 12f, Color.argb(200, 255, 255, 255)))

        root.addView(neonButton("RETURN TO MISSION", CYAN) {
            suppressUntil = 0L
            removeOverlay()
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        root.addView(neonButton("IGNORE WARNING (HP DRAINS)", CRIMSON) {
            suppressUntil = System.currentTimeMillis() + 2 * 60_000L
            removeOverlay()
            scope.launch { repo.log(LogType.LOCKDOWN, "Lockdown warning ignored — HP drain continues") }
        })
        scope.launch { repo.currentStats().let { hpBar?.progress = it.hp; hpLabel?.text = "HP ${it.hp}/$MAX_HP" } }
        return root
    }

    private fun neonButton(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(color)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)))
            setStroke(dp(2), color)
            cornerRadius = dp(12).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) }
    }

    private fun startAsForeground() {
        val n: Notification = NotificationCompat.Builder(this, RpgTrackerApp.CH_LOCKDOWN)
            .setSmallIcon(R.drawable.ic_stat_hud)
            .setContentTitle("Lockdown protocol active")
            .setContentText("Blocked apps drain $HP_DRAIN_PER_MINUTE HP per minute.")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onDestroy() {
        removeOverlay()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 1002

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, LockdownOverlayService::class.java))
            } catch (_: Exception) { /* needs "Display over other apps" to start from background */ }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LockdownOverlayService::class.java))
        }
    }
}

/**
 * HP penalty engine: a self-rescheduling one-minute WorkManager job.
 * Each tick, if a blocked app is in the foreground it deducts [HP_DRAIN_PER_MINUTE];
 * after [CLEAN_MINUTES_TO_RELEASE] clean minutes the lockdown is lifted.
 * HP 0 triggers Game Over (24h bonus-XP lockout until a Rest Task is completed).
 */
class HpDrainWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val repo = GameRepository.get(applicationContext)
        val p = repo.currentStats()
        if (!p.lockdownActive) return Result.success()

        val pkg = UsageStatsProvider(applicationContext).foregroundPackage()
        if (repo.isBlocked(pkg, p)) {
            repo.settings.cleanMinutes = 0
            repo.drainHp(HP_DRAIN_PER_MINUTE, "-$HP_DRAIN_PER_MINUTE HP · lockdown ignored ($pkg)")
        } else {
            val clean = repo.settings.cleanMinutes + 1
            repo.settings.cleanMinutes = clean
            if (clean >= CLEAN_MINUTES_TO_RELEASE) repo.endLockdown("Focus restored — lockdown lifted")
        }
        if (repo.currentStats().lockdownActive) schedule(applicationContext)
        return Result.success()
    }

    companion object {
        private const val TAG = "hp_drain"

        fun schedule(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<HpDrainWorker>()
                .setInitialDelay(1, TimeUnit.MINUTES)
                .addTag(TAG)
                .build()
            WorkManager.getInstance(ctx).enqueue(req)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelAllWorkByTag(TAG)
        }
    }
}
