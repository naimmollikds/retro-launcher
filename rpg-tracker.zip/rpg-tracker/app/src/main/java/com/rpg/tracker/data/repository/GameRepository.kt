package com.rpg.tracker.data.repository

import android.content.Context
import com.rpg.tracker.data.local.ActivityLogEntity
import com.rpg.tracker.data.local.AppDatabase
import com.rpg.tracker.data.local.PlayerEntity
import com.rpg.tracker.data.local.toDomain
import com.rpg.tracker.data.prefs.SettingsStore
import com.rpg.tracker.data.remote.GeminiKeyRotator
import com.rpg.tracker.domain.model.*
import com.rpg.tracker.ui.lockdown.HpDrainWorker
import com.rpg.tracker.ui.lockdown.LockdownOverlayService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Single source of truth for the game rules: XP, HP, levels, lockdown, game over. */
class GameRepository private constructor(context: Context) {

    private val ctx = context.applicationContext
    private val db = AppDatabase.get(ctx)
    private val playerDao = db.playerDao()
    private val logDao = db.logDao()
    private val lock = Mutex()

    val settings = SettingsStore.get(ctx)
    val rotator = GeminiKeyRotator(settings)

    val player: Flow<PlayerStats> = playerDao.observe().map { (it ?: PlayerEntity()).toDomain() }
    val logs: Flow<List<com.rpg.tracker.domain.model.ActivityLog>> =
        logDao.observeRecent().map { list -> list.map { it.toDomain() } }

    private suspend fun current(): PlayerEntity = playerDao.get() ?: PlayerEntity().also { playerDao.upsert(it) }

    suspend fun currentStats(): PlayerStats = current().toDomain()

    suspend fun log(type: LogType, message: String) {
        logDao.insert(ActivityLogEntity(timestamp = System.currentTimeMillis(), type = type.name, message = message))
        logDao.trim()
    }

    fun isBlocked(pkg: String?, p: PlayerStats): Boolean =
        pkg != null && pkg != ctx.packageName &&
            (pkg in settings.blockedPackages || (p.lastDistractionPkg.isNotEmpty() && pkg == p.lastDistractionPkg))

    // ---------------------------------------------------------------- AI verdicts

    /** Applies one Gemini evaluation: XP / HP changes, level-ups, optional lockdown. */
    suspend fun applyVerdict(v: AiVerdict, pkg: String, label: String) {
        val events = mutableListOf<Pair<LogType, String>>()
        val now = System.currentTimeMillis()
        var startLockdown = false
        var enteredGameOver = false

        lock.withLock {
            var p = current()
            if (p.restTaskPending && now >= p.bonusXpLockedUntil) {
                p = p.copy(restTaskPending = false, bonusXpLockedUntil = 0L, hp = REST_RESTORE_HP)
                events += LogType.SYSTEM to "24h lockout expired — systems rebooted at $REST_RESTORE_HP HP"
            }
            p = p.copy(currentApp = label, lastVerdict = v.verdict.name, lastSummary = v.summary)
            events += LogType.INFO to "AI scan · ${v.verdict.name} · $label — ${v.summary}"

            when (v.verdict) {
                Verdict.PRODUCTIVE -> {
                    p = p.copy(distractedStreak = 0)
                    if (now < p.bonusXpLockedUntil) {
                        events += LogType.INFO to "Productive focus detected — bonus XP locked (rest protocol)"
                    } else {
                        p = gainXp(p, XP_PER_PRODUCTIVE_SCAN, events)
                    }
                }
                Verdict.NEUTRAL -> p = p.copy(distractedStreak = 0)
                Verdict.DISTRACTED -> {
                    p = p.copy(
                        distractedStreak = p.distractedStreak + 1,
                        lastDistractionPkg = pkg,
                        hp = (p.hp - HP_PER_DISTRACTED_SCAN).coerceAtLeast(0)
                    )
                    events += LogType.DAMAGE to "-$HP_PER_DISTRACTED_SCAN HP · distraction: $label"
                }
            }

            if (p.hp <= 0 && !p.restTaskPending) {
                p = enterGameOver(p, now, events)
                enteredGameOver = true
            } else if (!p.lockdownActive && !p.restTaskPending &&
                (v.command == CMD_LOCKDOWN || p.distractedStreak >= DISTRACTION_STREAK_FOR_LOCKDOWN)
            ) {
                startLockdown = true
            }
            playerDao.upsert(p)
        }
        events.forEach { log(it.first, it.second) }
        if (enteredGameOver) stopLockdownMachinery()
        if (startLockdown) startLockdown(if (v.command == CMD_LOCKDOWN) "AI command" else "distraction streak")
    }

    private fun gainXp(p0: PlayerEntity, amount: Int, ev: MutableList<Pair<LogType, String>>): PlayerEntity {
        var p = p0.copy(xp = p0.xp + amount)
        ev += LogType.XP to "+$amount XP · focus confirmed"
        while (p.xp >= xpForLevel(p.level)) {
            p = p.copy(
                xp = p.xp - xpForLevel(p.level),
                level = p.level + 1,
                hp = (p.hp + LEVEL_UP_HEAL).coerceAtMost(MAX_HP)
            )
            ev += LogType.LEVEL_UP to "LEVEL UP ▲ now level ${p.level} (+$LEVEL_UP_HEAL HP)"
        }
        return p
    }

    private fun enterGameOver(p: PlayerEntity, now: Long, ev: MutableList<Pair<LogType, String>>): PlayerEntity {
        ev += LogType.DAMAGE to "GAME OVER · HP 0 — bonus XP locked 24h. Complete a Rest Task to reboot early."
        return p.copy(hp = 0, lockdownActive = false, restTaskPending = true, bonusXpLockedUntil = now + GAME_OVER_LOCK_MS)
    }

    // ---------------------------------------------------------------- lockdown

    suspend fun startLockdown(reason: String) {
        val started = lock.withLock {
            val p = current()
            if (p.lockdownActive || p.restTaskPending || p.hp <= 0) {
                false
            } else {
                playerDao.upsert(p.copy(lockdownActive = true))
                settings.cleanMinutes = 0
                true
            }
        }
        if (!started) return
        log(LogType.LOCKDOWN, "LOCKDOWN INITIATED ($reason) · blocked apps drain $HP_DRAIN_PER_MINUTE HP/min")
        LockdownOverlayService.start(ctx)
        HpDrainWorker.schedule(ctx)
    }

    suspend fun endLockdown(reason: String) {
        val ended = lock.withLock {
            val p = current()
            if (!p.lockdownActive) false else {
                playerDao.upsert(p.copy(lockdownActive = false, distractedStreak = 0))
                true
            }
        }
        if (ended) log(LogType.SYSTEM, reason)
        stopLockdownMachinery()
    }

    /** Called by [HpDrainWorker] once per minute while a blocked app is in the foreground. */
    suspend fun drainHp(amount: Int, reason: String) {
        val events = mutableListOf<Pair<LogType, String>>()
        var over = false
        lock.withLock {
            var p = current()
            if (!p.lockdownActive) return
            p = p.copy(hp = (p.hp - amount).coerceAtLeast(0))
            events += LogType.DAMAGE to reason
            if (p.hp <= 0) {
                p = enterGameOver(p, System.currentTimeMillis(), events)
                over = true
            }
            playerDao.upsert(p)
        }
        events.forEach { log(it.first, it.second) }
        if (over) stopLockdownMachinery()
    }

    private fun stopLockdownMachinery() {
        LockdownOverlayService.stop(ctx)
        HpDrainWorker.cancel(ctx)
    }

    suspend fun completeRestTask() {
        val done = lock.withLock {
            val p = current()
            if (!p.restTaskPending) false else {
                playerDao.upsert(p.copy(restTaskPending = false, bonusXpLockedUntil = 0L, hp = REST_RESTORE_HP, distractedStreak = 0))
                true
            }
        }
        if (done) log(LogType.SYSTEM, "Rest Task complete — bonus XP unlocked, HP restored to $REST_RESTORE_HP")
    }

    companion object {
        @Volatile private var instance: GameRepository? = null
        fun get(context: Context): GameRepository = instance ?: synchronized(this) {
            instance ?: GameRepository(context).also { instance = it }
        }
    }
}
