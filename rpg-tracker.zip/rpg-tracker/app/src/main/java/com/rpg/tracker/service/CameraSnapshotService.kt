package com.rpg.tracker.service

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.util.Base64
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.rpg.tracker.MainActivity
import com.rpg.tracker.R
import com.rpg.tracker.RpgTrackerApp
import com.rpg.tracker.data.prefs.SettingsStore
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.domain.model.LogType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * Camera foreground service. Keeps a CameraX ImageCapture bound to the service lifecycle and grabs
 * one in-memory JPEG frame every 2-5 minutes (no preview, nothing written to disk), then asks
 * [SnapshotEvaluator] to judge it together with the foreground app.
 *
 * Android restricts camera use from the background: this service must be started while the app is
 * visible, shows a mandatory notification (with a STOP action), and the system shows its camera indicator.
 */
class CameraSnapshotService : LifecycleService() {

    private var loopJob: Job? = null
    private var imageCapture: ImageCapture? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val settings = SettingsStore.get(this)
        if (intent?.action == ACTION_STOP) {
            settings.scannerEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (loopJob == null) loopJob = lifecycleScope.launch { runLoop() }
        return START_STICKY
    }

    private suspend fun runLoop() {
        val repo = GameRepository.get(this)
        try {
            bindCamera()
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            repo.log(LogType.SYSTEM, "Camera unavailable (${e.message}); scanning app usage only")
        }
        while (lifecycleScope.isActive) {
            val frame = try { captureFrame() } catch (e: Exception) { null }
            try {
                SnapshotEvaluator.evaluate(applicationContext, frame)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
            }
            delay(SettingsStore.get(this).snapshotIntervalMin * 60_000L)
        }
    }

    private suspend fun bindCamera() {
        val provider = ProcessCameraProvider.getInstance(this).await()
        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setFlashMode(ImageCapture.FLASH_MODE_OFF)
            .build()
        val selector = if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA))
            CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        provider.unbindAll()
        provider.bindToLifecycle(this, selector, capture)
        imageCapture = capture
    }

    private suspend fun captureFrame(): String? = suspendCancellableCoroutine { cont ->
        val capture = imageCapture
        if (capture == null) {
            cont.resume(null)
        } else {
            capture.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val encoded = try { encode(image) } catch (e: Exception) { null } finally { image.close() }
                    if (cont.isActive) cont.resume(encoded)
                }

                override fun onError(exception: ImageCaptureException) {
                    if (cont.isActive) cont.resume(null)
                }
            })
        }
    }

    /** Rotate upright, downscale to <=640px, JPEG q70, base64. Lives in memory only. */
    private fun encode(image: ImageProxy): String {
        var bmp = image.toBitmap()
        val rotation = image.imageInfo.rotationDegrees
        if (rotation != 0) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation.toFloat()) }, true)
        }
        val scale = 640f / maxOf(bmp.width, bmp.height)
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CameraSnapshotService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, RpgTrackerApp.CH_SCANNER)
            .setSmallIcon(R.drawable.ic_stat_hud)
            .setContentTitle("Neural scanner online")
            .setContentText("Front camera + app usage sampled every ${SettingsStore.get(this).snapshotIntervalMin} min. Frames are not stored.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .build()
    }

    override fun onDestroy() {
        ioExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 1001
        private const val ACTION_STOP = "com.rpg.tracker.STOP_SCANNER"

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, CameraSnapshotService::class.java))
            } catch (_: Exception) { /* background-start restrictions: user must open the app */ }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, CameraSnapshotService::class.java))
        }
    }
}
