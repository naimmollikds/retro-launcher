package com.rpg.tracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rpg.tracker.data.prefs.SettingsStore
import com.rpg.tracker.service.CameraSnapshotService
import com.rpg.tracker.service.UsageStatsProvider
import com.rpg.tracker.ui.chat.CompanionChatScreen
import com.rpg.tracker.ui.dashboard.DashboardScreen
import com.rpg.tracker.ui.dashboard.PermissionStatus
import com.rpg.tracker.ui.settings.SettingsScreen
import com.rpg.tracker.ui.theme.RpgTrackerTheme

class MainActivity : ComponentActivity() {

    private val permState = mutableStateOf(PermissionStatus())
    private val scannerState = mutableStateOf(false)

    private val runtimePermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent { RpgTrackerTheme { AppRoot() } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Re-arm the scanner while the app is visible (camera FGS may only be started from the foreground).
        val p = permState.value
        if (SettingsStore.get(this).scannerEnabled && p.camera && p.usage) CameraSnapshotService.start(this)
    }

    private fun refresh() {
        permState.value = PermissionStatus(
            camera = granted(Manifest.permission.CAMERA),
            usage = UsageStatsProvider(this).hasPermission(),
            overlay = Settings.canDrawOverlays(this),
            notifications = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)
        )
        scannerState.value = SettingsStore.get(this).scannerEnabled
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestRuntime() {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        runtimePermissions.launch(list.toTypedArray())
    }

    private fun openUsageAccess() = startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    private fun openOverlaySettings() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun setScanner(on: Boolean) {
        val settings = SettingsStore.get(this)
        if (on) {
            val p = permState.value
            if (!p.camera || !p.usage) {
                Toast.makeText(this, "Grant camera and usage access first", Toast.LENGTH_SHORT).show()
                return
            }
            settings.scannerEnabled = true
            CameraSnapshotService.start(this)
        } else {
            settings.scannerEnabled = false
            CameraSnapshotService.stop(this)
        }
        scannerState.value = settings.scannerEnabled
    }

    @Composable
    private fun AppRoot() {
        val nav = rememberNavController()
        var chatOpen by remember { mutableStateOf(false) }
        val perms by permState
        val scanner by scannerState
        BackHandler(enabled = chatOpen) { chatOpen = false }

        Box(Modifier.fillMaxSize()) {
            NavHost(nav, startDestination = "dashboard") {
                composable("dashboard") {
                    DashboardScreen(
                        permissions = perms,
                        scannerRunning = scanner,
                        onRequestRuntime = ::requestRuntime,
                        onOpenUsageAccess = ::openUsageAccess,
                        onOpenOverlay = ::openOverlaySettings,
                        onToggleScanner = ::setScanner,
                        onOpenChat = { chatOpen = true },
                        onOpenSettings = { nav.navigate("settings") }
                    )
                }
                composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
            }

            // Slide-out AI companion drawer (from the right edge)
            AnimatedVisibility(chatOpen, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(
                        interactionSource = remember { MutableInteractionSource() }, indication = null
                    ) { chatOpen = false }
                )
            }
            AnimatedVisibility(
                chatOpen,
                modifier = Modifier.align(Alignment.CenterEnd),
                enter = slideInHorizontally { it },
                exit = slideOutHorizontally { it }
            ) {
                CompanionChatScreen(onClose = { chatOpen = false }, modifier = Modifier.fillMaxHeight().fillMaxWidth(0.92f))
            }
        }
    }
}
