package com.rpg.tracker

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.rpg.tracker.service.UsageTrackerWorker

class RpgTrackerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SCANNER, "Neural scanner", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_LOCKDOWN, "Lockdown protocol", NotificationManager.IMPORTANCE_LOW))
        UsageTrackerWorker.schedule(this)
    }

    companion object {
        const val CH_SCANNER = "scanner"
        const val CH_LOCKDOWN = "lockdown"
    }
}
