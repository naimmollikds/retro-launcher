package com.rpg.tracker.data.remote

import com.rpg.tracker.data.prefs.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class NoApiKeysException : IOException("No Gemini API keys configured. Add one in Settings.")
class AllKeysExhaustedException(detail: String) : IOException("All API keys exhausted ($detail)")

/**
 * Multi-key pool for the Gemini REST API.
 * - Starts from the last working key; on HTTP 429 / 403 (or an invalid-key 400) it rotates to the next key.
 * - Keys that hit quota are put on a short cooldown so they are skipped on following calls.
 */
class GeminiKeyRotator(private val settings: SettingsStore) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val cooldownUntil = ConcurrentHashMap<String, Long>()

    private data class Raw(val code: Int, val body: String)

    /** Calls models.list and returns model ids that support generateContent (e.g. "gemini-1.5-flash"). */
    suspend fun fetchModels(): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            rotate(
                call = { key -> get("$BASE/models?pageSize=200&key=$key") },
                parse = { body ->
                    val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
                    (0 until arr.length()).map { arr.getJSONObject(it) }
                        .filter { m ->
                            m.optJSONArray("supportedGenerationMethods")?.let { a ->
                                (0 until a.length()).any { i -> a.getString(i) == "generateContent" }
                            } == true
                        }
                        .map { it.getString("name").removePrefix("models/") }
                        .filter { it.startsWith("gemini") }
                        .sorted()
                }
            ).also { settings.cachedModels = it }
        }
    }

    /** generateContent with the currently selected model. [contents] follows the Gemini REST schema. */
    suspend fun generate(contents: JSONArray, systemPrompt: String?, json: Boolean): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val body = JSONObject().put("contents", contents)
                if (systemPrompt != null) {
                    body.put(
                        "systemInstruction",
                        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                    )
                }
                body.put("generationConfig", JSONObject().apply {
                    put("temperature", 0.4)
                    if (json) put("responseMimeType", "application/json")
                })
                val url = "$BASE/models/${settings.model}:generateContent"
                rotate(call = { key -> post(url, key, body.toString()) }, parse = ::extractText)
            }
        }

    private fun <T> rotate(call: (String) -> Raw, parse: (String) -> T): T {
        val keys = settings.apiKeys
        if (keys.isEmpty()) throw NoApiKeysException()
        val start = settings.activeKeyIndex.coerceIn(0, keys.lastIndex)
        val order = List(keys.size) { (start + it) % keys.size }
        val now = System.currentTimeMillis()
        val ready = order.filter { (cooldownUntil[keys[it]] ?: 0L) <= now }.ifEmpty { order }
        var last = "no response"
        for (idx in ready) {
            val key = keys[idx]
            val r = call(key)
            when {
                r.code in 200..299 -> {
                    settings.activeKeyIndex = idx
                    return parse(r.body)
                }
                r.code == 429 -> {
                    cooldownUntil[key] = now + 60_000
                    last = "key #${idx + 1}: quota exceeded (429)"
                }
                r.code == 403 || (r.code == 400 && r.body.contains("API_KEY_INVALID")) -> {
                    cooldownUntil[key] = now + 600_000
                    last = "key #${idx + 1}: rejected (HTTP ${r.code})"
                }
                else -> throw IOException("Gemini HTTP ${r.code}: ${r.body.take(240)}")
            }
        }
        throw AllKeysExhaustedException(last)
    }

    private fun extractText(body: String): String {
        val parts = JSONObject(body).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("Model returned no content (possibly blocked by safety filters)")
        return buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim()
    }

    private fun execute(req: Request): Raw =
        client.newCall(req).execute().use { Raw(it.code, it.body?.string().orEmpty()) }

    private fun get(url: String) = execute(Request.Builder().url(url).get().build())

    private fun post(url: String, key: String, json: String) = execute(
        Request.Builder().url(url).header("x-goog-api-key", key)
            .post(json.toRequestBody("application/json".toMediaType())).build()
    )

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    }
}
