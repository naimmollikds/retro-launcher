package com.rpg.tracker.service

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import java.util.Calendar

data class AppUsage(val pkg: String, val label: String, val minutes: Long, val opens: Int)

data class UsageSnapshot(
    val foregroundPackage: String?,
    val foregroundLabel: String,
    val screenTimeTodayMin: Long,
    val topApps: List<AppUsage>,
    val openCounts: Map<String, Int>
)

/** Thin wrapper over UsageStatsManager (the data source behind Android Digital Wellbeing). */
class UsageStatsProvider(private val ctx: Context) {

    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    private val launcherPkg: String? by lazy {
        ctx.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            ?.activityInfo?.packageName
    }

    fun hasPermission(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) ==
            AppOpsManager.MODE_ALLOWED
    }

    /** Package currently in the foreground, reconstructed from the last few hours of usage events. */
    fun foregroundPackage(lookbackMs: Long = 3 * 60 * 60_000L): String? {
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - lookbackMs, now)
        val e = UsageEvents.Event()
        var current: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> current = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED ->
                    if (e.packageName == current) current = null
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> current = null
            }
        }
        return current
    }

    fun snapshot(): UsageSnapshot {
        val now = System.currentTimeMillis()
        val dayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val fg = foregroundPackage()
        val stats = usm.queryAndAggregateUsageStats(dayStart, now).values.filter {
            it.totalTimeInForeground > 0 && it.packageName != ctx.packageName &&
                it.packageName != launcherPkg && it.packageName != "com.android.systemui"
        }
        val opens = openCounts(dayStart, now)
        val top = stats.sortedByDescending { it.totalTimeInForeground }.take(5).map {
            AppUsage(it.packageName, label(it.packageName), it.totalTimeInForeground / 60_000, opens[it.packageName] ?: 0)
        }
        return UsageSnapshot(
            foregroundPackage = fg,
            foregroundLabel = fg?.let { label(it) }.orEmpty(),
            screenTimeTodayMin = stats.sumOf { it.totalTimeInForeground } / 60_000,
            topApps = top,
            openCounts = opens
        )
    }

    private fun openCounts(from: Long, to: Long): Map<String, Int> {
        val map = HashMap<String, Int>()
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when {
                e.eventType == UsageEvents.Event.ACTIVITY_RESUMED && e.packageName != last -> {
                    map[e.packageName] = (map[e.packageName] ?: 0) + 1
                    last = e.packageName
                }
                e.eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE -> last = null
            }
        }
        return map
    }

    fun label(pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
