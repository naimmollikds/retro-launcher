package com.rpg.tracker.ui.chat

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.domain.model.CMD_LOCKDOWN
import com.rpg.tracker.domain.model.MAX_HP
import com.rpg.tracker.domain.model.PlayerStats
import com.rpg.tracker.service.UsageSnapshot
import com.rpg.tracker.service.UsageStatsProvider
import com.rpg.tracker.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class ChatMsg(val fromUser: Boolean, val text: String, val isError: Boolean = false)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = GameRepository.get(app)
    private val usage = UsageStatsProvider(app)

    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages
    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || _sending.value) return
        _messages.update { it + ChatMsg(true, clean) }
        viewModelScope.launch {
            _sending.value = true
            val stats = repo.currentStats()
            val snap = if (usage.hasPermission()) withContext(Dispatchers.IO) { usage.snapshot() } else null
            val contents = JSONArray()
            _messages.value.filter { !it.isError }.takeLast(20).forEach { m ->
                contents.put(
                    JSONObject().put("role", if (m.fromUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                )
            }
            repo.rotator.generate(contents, systemPrompt(stats, snap), json = false)
                .onSuccess { reply ->
                    var out = reply
                    if (out.contains("[[$CMD_LOCKDOWN]]")) {
                        out = out.replace("[[$CMD_LOCKDOWN]]", "").trim()
                        repo.startLockdown("companion command")
                    }
                    _messages.update { it + ChatMsg(false, out) }
                }
                .onFailure { err -> _messages.update { it + ChatMsg(false, "Uplink failed: ${err.message}", isError = true) } }
            _sending.value = false
        }
    }

    private fun systemPrompt(p: PlayerStats, s: UsageSnapshot?): String = """
        You are NOVA, a concise, encouraging cyberpunk RPG companion inside the user's focus-tracking HUD. Keep replies under 80 words.
        Help with current tasks, focus levels and daily goals. Be honest; tough-love is fine, never insulting.
        Live context: level ${p.level}, HP ${p.hp}/$MAX_HP, XP ${p.xp}/${p.xpToNext}.
        Active app: ${s?.foregroundLabel?.ifBlank { null } ?: p.currentApp.ifBlank { "unknown" }}.
        Screen time today: ${s?.screenTimeTodayMin ?: "unknown"} min. Lockdown active: ${p.lockdownActive}.
        Latest camera/app scan: ${p.lastVerdict.ifBlank { "none yet" }} — ${p.lastSummary.ifBlank { "n/a" }}.
        If the user says they want to keep procrastinating and asks to be forced to focus, append the exact token [[$CMD_LOCKDOWN]] at the end of your reply.
    """.trimIndent()
}

@Composable
fun CompanionChatScreen(onClose: () -> Unit, modifier: Modifier = Modifier, vm: ChatViewModel = viewModel()) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val sending by vm.sending.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    Column(
        modifier
            .background(Brush.verticalGradient(listOf(Color(0xFF0E1220), CharcoalBlack)))
            .border(1.dp, NeonPurple.copy(alpha = 0.6f))
            .statusBarsPadding().navigationBarsPadding().imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("COMPANION//NOVA", color = NeonPurple, fontWeight = FontWeight.Black, fontSize = 18.sp, letterSpacing = 2.sp)
                Text("online · context-aware", color = EmeraldGreen, style = MaterialTheme.typography.labelMedium)
            }
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = NeonCyan) }
        }
        HorizontalDivider(color = NeonPurple.copy(alpha = 0.4f))

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    GlassCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
                        Text(
                            "Link established. Ask me about your tasks, focus or today's goals — I can see your HP, active app and latest scan.",
                            color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            items(messages) { m ->
                val color = when {
                    m.isError -> CrimsonRed
                    m.fromUser -> NeonPurple
                    else -> NeonCyan
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text,
                        Modifier.widthIn(max = 280.dp)
                            .background(color.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        color = Color.White, style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            if (sending) item { Text("NOVA is processing…", color = NeonCyan.copy(alpha = 0.7f), style = MaterialTheme.typography.labelMedium) }
        }

        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Transmit message…") },
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan, unfocusedBorderColor = NeonCyan.copy(alpha = 0.4f), cursorColor = NeonCyan
                )
            )
            IconButton(onClick = { vm.send(input); input = "" }, enabled = !sending && input.isNotBlank()) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = if (sending) Color.Gray else NeonCyan)
            }
        }
    }
}
