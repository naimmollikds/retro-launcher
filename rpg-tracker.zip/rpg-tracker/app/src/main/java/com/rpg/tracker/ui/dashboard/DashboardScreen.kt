package com.rpg.tracker.ui.dashboard

import android.app.Application
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.domain.model.*
import com.rpg.tracker.service.UsageSnapshot
import com.rpg.tracker.service.UsageStatsProvider
import com.rpg.tracker.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PermissionStatus(
    val camera: Boolean = false,
    val usage: Boolean = false,
    val overlay: Boolean = false,
    val notifications: Boolean = true
) {
    val allGranted get() = camera && usage && overlay && notifications
}

class DashboardViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = GameRepository.get(app)
    private val usage = UsageStatsProvider(app)

    val player = repo.player.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlayerStats())
    val logs = repo.logs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Real-time foreground app, screen time and open counts (polled every 5 s while visible). */
    val usageSnapshot: StateFlow<UsageSnapshot?> = flow {
        while (true) {
            emit(if (usage.hasPermission()) withContext(Dispatchers.IO) { usage.snapshot() } else null)
            delay(5_000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun completeRestTask() {
        viewModelScope.launch { repo.completeRestTask() }
    }
}

@Composable
fun DashboardScreen(
    permissions: PermissionStatus,
    scannerRunning: Boolean,
    onRequestRuntime: () -> Unit,
    onOpenUsageAccess: () -> Unit,
    onOpenOverlay: () -> Unit,
    onToggleScanner: (Boolean) -> Unit,
    onOpenChat: () -> Unit,
    onOpenSettings: () -> Unit,
    vm: DashboardViewModel = viewModel()
) {
    val player by vm.player.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val usage by vm.usageSnapshot.collectAsStateWithLifecycle()
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(CharcoalBlack, Color(0xFF120A1F), CharcoalBlack)))
    ) {
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("NEURAL//HUD", color = NeonCyan, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 2.sp)
                        Text("OPERATOR LVL ${player.level}", color = NeonPurple, style = MaterialTheme.typography.labelLarge)
                    }
                    NeonButton("NOVA AI", NeonPurple, onOpenChat)
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = NeonCyan)
                    }
                }
            }
            item {
                GlassCard {
                    NeonBar(player.hp / MAX_HP.toFloat(), CrimsonRed, "HP", "${player.hp}/$MAX_HP")
                    Spacer(Modifier.height(14.dp))
                    NeonBar(player.xp / player.xpToNext.toFloat(), EmeraldGreen, "XP · LVL ${player.level}", "${player.xp}/${player.xpToNext}")
                }
            }
            if (player.lockdownActive) item { LockdownBanner() }
            if (player.restTaskPending) item { GameOverCard(player, vm::completeRestTask) }
            if (!permissions.allGranted) {
                item { PermissionsCard(permissions, onRequestRuntime, onOpenUsageAccess, onOpenOverlay) }
            }
            item { LiveStatusCard(player, usage) }
            item {
                GlassCard(borderColor = NeonCyan.copy(alpha = 0.35f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NEURAL SCANNER", color = NeonCyan, fontWeight = FontWeight.Bold)
                            Text(
                                "Camera + app-usage scan every few minutes. Shows a persistent notification.",
                                color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Switch(
                            checked = scannerRunning,
                            onCheckedChange = onToggleScanner,
                            colors = SwitchDefaults.colors(checkedTrackColor = NeonCyan, checkedThumbColor = CharcoalBlack)
                        )
                    }
                }
            }
            item { Text("LIVE ACTIVITY FEED", color = NeonPurple, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
            if (logs.isEmpty()) {
                item { Text("> awaiting first scan…", color = Color.White.copy(alpha = 0.4f), fontFamily = FontFamily.Monospace) }
            }
            items(logs, key = { it.id }) { log ->
                val c = when (log.type) {
                    LogType.XP, LogType.LEVEL_UP -> EmeraldGreen
                    LogType.DAMAGE, LogType.LOCKDOWN -> CrimsonRed
                    LogType.SYSTEM -> NeonPurple
                    LogType.INFO -> NeonCyan
                }
                Row {
                    Text(timeFmt.format(Date(log.timestamp)), color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(8.dp))
                    Text(log.message, color = c, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun LockdownBanner() {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.5f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha"
    )
    GlassCard(Modifier.alpha(pulse), borderColor = CrimsonRed) {
        Text("⚠ LOCKDOWN ACTIVE", color = CrimsonRed, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text(
            "Blocked apps drain $HP_DRAIN_PER_MINUTE HP per minute. Stay off them for $CLEAN_MINUTES_TO_RELEASE minutes to lift lockdown.",
            color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun GameOverCard(p: PlayerStats, onComplete: () -> Unit) {
    val remainingMin = ((p.bonusXpLockedUntil - System.currentTimeMillis()) / 60_000).coerceAtLeast(0)
    GlassCard(borderColor = CrimsonRed) {
        Text("GAME OVER · SYSTEMS OFFLINE", color = CrimsonRed, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text(
            "Bonus XP locked for ${remainingMin / 60}h ${remainingMin % 60}m. " +
                "Complete a Rest Task (10 min away from your phone) to reboot early.",
            color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        NeonButton("REST TASK COMPLETED", EmeraldGreen, onComplete, Modifier.fillMaxWidth())
    }
}

@Composable
private fun PermissionsCard(p: PermissionStatus, onRuntime: () -> Unit, onUsage: () -> Unit, onOverlay: () -> Unit) {
    GlassCard(borderColor = NeonPurple.copy(alpha = 0.6f)) {
        Text("SYSTEM CALIBRATION", color = NeonPurple, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (!p.camera || !p.notifications) PermRow("Camera & notifications", onRuntime)
        if (!p.usage) PermRow("Usage access (Digital Wellbeing data)", onUsage)
        if (!p.overlay) PermRow("Display over other apps (lockdown)", onOverlay)
    }
}

@Composable
private fun PermRow(label: String, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall)
        NeonButton("GRANT", NeonCyan, onGrant)
    }
}

@Composable
private fun LiveStatusCard(player: PlayerStats, usage: UsageSnapshot?) {
    GlassCard(borderColor = NeonPurple.copy(alpha = 0.5f)) {
        Text("ACTIVE TARGET", color = NeonPurple, style = MaterialTheme.typography.labelMedium)
        val active = usage?.foregroundLabel?.takeIf { it.isNotBlank() } ?: player.currentApp.ifBlank { "—" }
        Text(active, color = NeonCyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        val vc = when (player.lastVerdict) {
            "PRODUCTIVE" -> EmeraldGreen
            "DISTRACTED" -> CrimsonRed
            else -> NeonCyan
        }
        Text("AI VERDICT: ${player.lastVerdict.ifBlank { "PENDING" }}", color = vc, fontWeight = FontWeight.Bold)
        if (player.lastSummary.isNotBlank()) {
            Text(player.lastSummary, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
        }
        if (usage != null) {
            Spacer(Modifier.height(10.dp))
            Text("SCREEN TIME TODAY: ${usage.screenTimeTodayMin} min", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelLarge)
            usage.topApps.forEach { a ->
                Row(Modifier.fillMaxWidth()) {
                    Text(a.label, Modifier.weight(1f), color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    Text("${a.minutes}m · ${a.opens} opens", color = NeonCyan.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            Text("Grant usage access to see live app stats.", color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall)
        }
    }
}
