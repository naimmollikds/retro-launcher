package com.rpg.tracker.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val HudColors = darkColorScheme(
    primary = NeonCyan,
    onPrimary = CharcoalBlack,
    secondary = NeonPurple,
    onSecondary = Color.White,
    tertiary = EmeraldGreen,
    error = CrimsonRed,
    background = CharcoalBlack,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    outline = NeonCyan.copy(alpha = 0.4f)
)

private val Base = Typography()
private val HudTypography = Typography(
    headlineMedium = Base.headlineMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
    titleMedium = Base.titleMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
    bodyLarge = Base.bodyLarge.copy(fontFamily = FontFamily.Monospace),
    bodyMedium = Base.bodyMedium.copy(fontFamily = FontFamily.Monospace),
    bodySmall = Base.bodySmall.copy(fontFamily = FontFamily.Monospace),
    labelLarge = Base.labelLarge.copy(fontFamily = FontFamily.Monospace),
    labelMedium = Base.labelMedium.copy(fontFamily = FontFamily.Monospace),
)

@Composable
fun RpgTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = HudColors, typography = HudTypography, content = content)
}

// ------------------------------------------------------------------ HUD building blocks

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NeonCyan.copy(alpha = 0.35f),
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(GlassHighlight, GlassBase)))
            .border(1.dp, borderColor, shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun NeonBar(progress: Float, color: Color, label: String, trailing: String, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(progress.coerceIn(0f, 1f), tween(600), label = "bar")
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = color, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(trailing, color = color, style = MaterialTheme.typography.labelLarge)
        }
        Spacer(Modifier.height(6.dp))
        val shape = RoundedCornerShape(7.dp)
        Box(
            Modifier.fillMaxWidth().height(14.dp).clip(shape)
                .background(Color.White.copy(alpha = 0.08f))
                .border(1.dp, color.copy(alpha = 0.4f), shape)
        ) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth(animated)
                    .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.55f), color)))
            )
        }
    }
}

@Composable
fun NeonButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}
