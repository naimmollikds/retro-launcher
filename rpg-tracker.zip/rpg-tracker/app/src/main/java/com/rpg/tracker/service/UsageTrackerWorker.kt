package com.rpg.tracker.service

import android.content.Context
import androidx.work.*
import com.rpg.tracker.data.repository.GameRepository
import com.rpg.tracker.domain.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Builds the Gemini payload (foreground app + Digital Wellbeing stats + optional camera frame)
 * and applies the verdict to the game state.
 */
object SnapshotEvaluator {

    private val SYSTEM_PROMPT = """
        You are the focus-judging engine of a personal gamified productivity HUD that the device owner installed on their own phone.
        You receive the foreground app, today's usage statistics and, optionally, one small front-camera frame.
        Decide whether the owner is currently doing productive work (IDEs, documents, study or learning tools, note-taking, work email, reading)
        or unproductive distraction (social media feeds, short-video, games, streaming).
        If a camera frame is present, use it ONLY to judge presence and attention (at the screen, looking away, absent). Never identify or describe the person.
        Reply with JSON only, exactly: {"verdict":"PRODUCTIVE|NEUTRAL|DISTRACTED","summary":"<max 20 words>","command":"NONE|LOCKDOWN_INITIATED"}
        Use LOCKDOWN_INITIATED only when distraction clearly persists (long time in distracting apps, many repeated opens, repeated DISTRACTED streak).
    """.trimIndent()

    suspend fun evaluate(ctx: Context, frameBase64: String?): kotlin.Result<AiVerdict> {
        val repo = GameRepository.get(ctx)
        val usage = UsageStatsProvider(ctx)
        if (!usage.hasPermission()) return kotlin.Result.failure(IllegalStateException("Usage access not granted"))
        val snap = usage.snapshot()
        val pkg = snap.foregroundPackage
        if (pkg == null || pkg == ctx.packageName) {
            return kotlin.Result.failure(IllegalStateException("Idle or HUD in foreground — scan skipped"))
        }
        val p = repo.currentStats()
        repo.settings.lastHeartbeat = System.currentTimeMillis()

        val parts = JSONArray().put(JSONObject().put("text", buildPrompt(snap, p, frameBase64 != null)))
        if (frameBase64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", frameBase64)))
        }
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))

        return repo.rotator.generate(contents, SYSTEM_PROMPT, json = true)
            .mapCatching { parseVerdict(it) }
            .onSuccess { repo.applyVerdict(it, pkg, snap.foregroundLabel) }
            .onFailure { repo.log(LogType.SYSTEM, "AI scan failed: ${it.message}") }
    }

    private fun buildPrompt(s: UsageSnapshot, p: PlayerStats, hasFrame: Boolean): String = buildString {
        appendLine("Foreground app: ${s.foregroundLabel} (${s.foregroundPackage})")
        appendLine("Screen time today: ${s.screenTimeTodayMin} min")
        appendLine("Top apps today: " + s.topApps.joinToString("; ") { "${it.label} ${it.minutes}m/${it.opens} opens" })
        appendLine("Player: level ${p.level}, HP ${p.hp}/$MAX_HP, consecutive distracted scans ${p.distractedStreak}")
        appendLine(if (hasFrame) "A front-camera frame is attached." else "No camera frame available; judge from app context only.")
    }

    private fun parseVerdict(raw: String): AiVerdict {
        val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = JSONObject(clean)
        val v = runCatching { Verdict.valueOf(o.optString("verdict").uppercase()) }.getOrDefault(Verdict.NEUTRAL)
        val cmd = o.optString("command").takeIf { it.equals(CMD_LOCKDOWN, ignoreCase = true) }
        return AiVerdict(v, o.optString("summary").take(200), cmd)
    }
}

/**
 * WorkManager fallback (15 min minimum period): evaluates app usage without a camera frame
 * whenever the camera foreground service has not produced a scan recently.
 */
class UsageTrackerWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val settings = GameRepository.get(applicationContext).settings
        if (System.currentTimeMillis() - settings.lastHeartbeat < 6 * 60_000L) return Result.success()
        SnapshotEvaluator.evaluate(applicationContext, null)
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<UsageTrackerWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("usage_tracker", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
