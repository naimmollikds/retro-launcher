package com.rpg.tracker.data.local

import android.content.Context
import androidx.room.*
import com.rpg.tracker.domain.model.ActivityLog
import com.rpg.tracker.domain.model.LogType
import com.rpg.tracker.domain.model.MAX_HP
import com.rpg.tracker.domain.model.PlayerStats
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "player")
data class PlayerEntity(
    @PrimaryKey val id: Int = 1,
    val level: Int = 1,
    val xp: Int = 0,
    val hp: Int = MAX_HP,
    val lockdownActive: Boolean = false,
    val bonusXpLockedUntil: Long = 0L,
    val restTaskPending: Boolean = false,
    val currentApp: String = "",
    val lastVerdict: String = "",
    val lastSummary: String = "",
    val distractedStreak: Int = 0,
    val lastDistractionPkg: String = ""
)

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val type: String,
    val message: String
)

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player WHERE id = 1")
    fun observe(): Flow<PlayerEntity?>

    @Query("SELECT * FROM player WHERE id = 1")
    suspend fun get(): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(player: PlayerEntity)
}

@Dao
interface LogDao {
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC, id DESC LIMIT 60")
    fun observeRecent(): Flow<List<ActivityLogEntity>>

    @Insert
    suspend fun insert(log: ActivityLogEntity)

    @Query("DELETE FROM activity_logs WHERE id NOT IN (SELECT id FROM activity_logs ORDER BY timestamp DESC, id DESC LIMIT 500)")
    suspend fun trim()
}

@Database(entities = [PlayerEntity::class, ActivityLogEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun logDao(): LogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "rpg_tracker.db")
                .fallbackToDestructiveMigration()
                .build()
                .also { instance = it }
        }
    }
}

fun PlayerEntity.toDomain() = PlayerStats(
    level, xp, hp, lockdownActive, bonusXpLockedUntil, restTaskPending,
    currentApp, lastVerdict, lastSummary, distractedStreak, lastDistractionPkg
)

fun ActivityLogEntity.toDomain() = ActivityLog(
    id, timestamp, runCatching { LogType.valueOf(type) }.getOrDefault(LogType.INFO), message
)
