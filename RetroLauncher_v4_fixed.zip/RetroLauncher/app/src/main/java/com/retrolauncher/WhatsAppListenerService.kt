package com.retrolauncher

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput

class WhatsAppListenerService : NotificationListenerService() {

    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b", "com.facebook.orca")

    private val countSuffix = Regex("\\s*\\(\\d+ messages?\\)$")
    private val BAD_CHARS = "\\'\"`<>&\${}"

    override fun onCreate() {
        super.onCreate()
        MessageStore.init(this)
    }

    override fun onListenerConnected() {
        // Rebuild reply handles and pick up anything already in the shade.
        try { activeNotifications?.forEach { handle(it) } } catch (e: Exception) {}
        // Rate anything that arrived while the AI was unreachable.
        ImportanceClassifier.sweep(this)
    }

    override fun onListenerDisconnected() {
        requestRebind(ComponentName(this, WhatsAppListenerService::class.java))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn)

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName !in packages) return
        val platform = if (sbn.packageName == "com.facebook.orca") "Messenger" else "WhatsApp"
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_CALL || cat == Notification.CATEGORY_SERVICE ||
            cat == Notification.CATEGORY_PROGRESS || cat == Notification.CATEGORY_STATUS ||
            cat == Notification.CATEGORY_TRANSPORT
        ) return

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val reply = findReply(n)
        // Plain notifications are accepted if they look like chat messages or can be replied to.
        if (style == null && cat != Notification.CATEGORY_MESSAGE && reply == null) return

        val extras = n.extras
        val rawTitle = style?.conversationTitle
            ?: extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)
            ?: return
        val title = sanitizeKey(rawTitle.toString().replace(countSuffix, ""))
        if (title.isEmpty() || title.equals("WhatsApp", ignoreCase = true)) return

        if (reply != null) ReplyRegistry.put(title, reply.first, reply.second, platform)

        val baseTime = if (n.`when` > 0) n.`when` else sbn.postTime
        val msgs = style?.messages ?: emptyList()

        if (style != null && msgs.isNotEmpty()) {
            val allNull = msgs.all { it.person == null }
            val userKey = style.user.key
            val userName = style.user.name?.toString()
            val group = style.isGroupConversation

            for (m in msgs) {
                val text = m.text?.toString() ?: continue
                val time = if (m.timestamp > 0) m.timestamp else baseTime

                if (allNull) {
                    // WhatsApp didn't attach senders: treat everything as received.
                    store(title, title, text, time, platform)
                    continue
                }
                val p = m.person ?: continue                       // null person = my own message
                val senderName = p.name?.toString() ?: ""
                if (senderName.equals("You", true) || senderName.equals("Me", true)) continue
                if (userKey != null && p.key != null && p.key == userKey) continue
                if (userName != null && senderName.isNotEmpty() && senderName == userName) continue

                val shown = if (group && senderName.isNotEmpty()) "$senderName: $text" else text
                store(title, if (senderName.isEmpty()) title else senderName, shown, time, platform)
            }
        } else {
            val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null && lines.isNotEmpty()) {
                for (l in lines) store(title, title, l.toString(), baseTime, platform)
            } else {
                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
                store(title, title, text, baseTime, platform)
            }
        }
    }

    /** Contact/group names are placed inside inline onclick="fn('NAME')" in the UI. */
    private fun sanitizeKey(raw: String): String =
        raw.filter { it !in BAD_CHARS && !it.isISOControl() }.trim().take(40)

    /**
     * Saves the message as "not important, not rated yet" and sends it to the AI.
     * Only the AI's answer can flag it as important.
     */
    private fun store(contact: String, sender: String, text: String, time: Long, platform: String) {
        if (text.isBlank()) return
        val msg = MessageStore.Msg(sender, text, time, "received", platform = platform)
        if (MessageStore.add(contact, msg)) {
            ImportanceClassifier.classifyAsync(applicationContext, contact, msg)
        }
    }

    private fun findReply(n: Notification): Pair<PendingIntent, Array<RemoteInput>>? {
        for (i in 0 until NotificationCompat.getActionCount(n)) {
            val a = NotificationCompat.getAction(n, i) ?: continue
            val ri = a.remoteInputs
            val pi = a.actionIntent
            if (!ri.isNullOrEmpty() && pi != null) return Pair(pi, ri)
        }
        // Older WhatsApp versions expose Reply through the Wearable extender
        for (a in NotificationCompat.WearableExtender(n).actions) {
            val ri = a.remoteInputs
            val pi = a.actionIntent
            if (!ri.isNullOrEmpty() && pi != null) return Pair(pi, ri)
        }
        return null
    }
}
