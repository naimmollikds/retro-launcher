package com.retrolauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom

/**
 * Registry of "plug-in" web apps added from Apps -> ADD APPLICATION.
 *  kind "url":  opens a web address.
 *  kind "file": an .html file copied into app-private storage (files/webapps/<id>.html).
 */
object WebAppStore {
    private const val PREFS = "webapps"
    private const val KEY = "apps"
    const val MAX_HTML_BYTES = 8 * 1024 * 1024
    private const val STAGED = "_staged.html"

    data class App(val id: String, val name: String, val kind: String, val url: String) {
        fun toJson(): JSONObject = JSONObject()
            .put("id", id).put("name", name).put("kind", kind).put("url", url)
    }

    private fun dir(ctx: Context): File =
        File(ctx.applicationContext.filesDir, "webapps").also { if (!it.exists()) it.mkdirs() }

    fun fileFor(ctx: Context, id: String): File = File(dir(ctx), "$id.html")

    /** The host a file app is served from: every app gets its own origin, so apps cannot read each other's data. */
    fun hostFor(id: String) = "$id.webapp.invalid"

    @Synchronized
    fun list(ctx: Context): List<App> {
        val raw = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                App(o.getString("id"), o.getString("name"), o.getString("kind"), o.optString("url"))
            }
        } catch (e: Exception) { emptyList() }
    }

    fun get(ctx: Context, id: String): App? = list(ctx).firstOrNull { it.id == id }

    fun listJson(ctx: Context): JSONArray {
        val arr = JSONArray()
        list(ctx).forEach { arr.put(it.toJson()) }
        return arr
    }

    @Synchronized
    private fun save(ctx: Context, apps: List<App>) {
        val arr = JSONArray()
        apps.forEach { arr.put(it.toJson()) }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun newId(): String {
        val b = ByteArray(5)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun cleanName(n: String) = n.filter { !it.isISOControl() }.trim().take(30)

    /** @return the new app, or null when the name/address is not acceptable. */
    fun addUrl(ctx: Context, name: String, url: String): App? {
        val u = url.trim()
        val n = cleanName(name)
        if (n.isEmpty() || !(u.startsWith("http://", true) || u.startsWith("https://", true)) || u.length > 2000) return null
        val app = App(newId(), n, "url", u)
        save(ctx, list(ctx) + app)
        return app
    }

    /** Keeps picked file bytes until the user presses SAVE APP. */
    fun stage(ctx: Context, bytes: ByteArray) {
        File(dir(ctx), STAGED).writeBytes(bytes)
    }

    fun hasStaged(ctx: Context) = File(dir(ctx), STAGED).exists()

    fun clearStaged(ctx: Context) { File(dir(ctx), STAGED).delete() }

    fun addStagedFile(ctx: Context, name: String): App? {
        val n = cleanName(name)
        val staged = File(dir(ctx), STAGED)
        if (n.isEmpty() || !staged.exists()) return null
        val app = App(newId(), n, "file", "")
        if (!staged.renameTo(fileFor(ctx, app.id))) return null
        save(ctx, list(ctx) + app)
        return app
    }

    fun remove(ctx: Context, id: String) {
        val apps = list(ctx)
        if (apps.none { it.id == id }) return
        save(ctx, apps.filter { it.id != id })
        fileFor(ctx, id).delete()
    }
}
