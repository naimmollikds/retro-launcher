package com.retrolauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full-screen alarm UI shown over the lock screen. */
class AlarmActivity : ComponentActivity() {

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val title = intent.getStringExtra("title") ?: "Alarm"
        val body = intent.getStringExtra("body") ?: ""
        val density = resources.displayMetrics.density
        val pad = (24 * density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#E2E5DE"))
        root.setPadding(pad, pad, pad, pad)

        val clock = TextView(this)
        clock.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        clock.textSize = 56f
        clock.setTextColor(Color.parseColor("#111827"))
        clock.typeface = android.graphics.Typeface.MONOSPACE
        clock.gravity = Gravity.CENTER
        root.addView(clock)

        val label = TextView(this)
        label.text = "⏰ $title"
        label.textSize = 22f
        label.setTextColor(Color.parseColor("#1F2937"))
        label.gravity = Gravity.CENTER
        label.setPadding(0, pad, 0, 0)
        root.addView(label)

        if (body.isNotEmpty()) {
            val sub = TextView(this)
            sub.text = body
            sub.textSize = 14f
            sub.setTextColor(Color.parseColor("#4B5563"))
            sub.gravity = Gravity.CENTER
            root.addView(sub)
        }

        val snooze = Button(this)
        snooze.text = "SNOOZE 10 MIN"
        snooze.setOnClickListener {
            val i = Intent(this@AlarmActivity, AlarmService::class.java).setAction(AlarmService.ACTION_SNOOZE)
            i.putExtra("title", title)
            i.putExtra("body", body)
            startService(i)
            finish()
        }

        val dismiss = Button(this)
        dismiss.text = "DISMISS"
        dismiss.setOnClickListener {
            startService(Intent(this@AlarmActivity, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
            finish()
        }

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = pad
        root.addView(snooze, lp)
        root.addView(dismiss, lp)

        setContentView(root)

        ContextCompat.registerReceiver(
            this, finishReceiver, IntentFilter(AlarmService.ACTION_FINISH),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onDestroy() {
        try { unregisterReceiver(finishReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }
}
