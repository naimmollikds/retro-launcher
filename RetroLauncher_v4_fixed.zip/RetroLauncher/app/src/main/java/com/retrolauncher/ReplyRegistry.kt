package com.retrolauncher

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.app.RemoteInput
import java.util.concurrent.ConcurrentHashMap

/**
 * Keeps the most recent "Reply" action WhatsApp attached to each conversation's
 * notification, so we can fire it later with our own text.
 */
object ReplyRegistry {
    private class Handle(val pi: PendingIntent, val inputs: Array<RemoteInput>)

    private val map = ConcurrentHashMap<String, Handle>()

    private fun key(platform: String, contact: String) = platform + "|" + contact

    fun put(contact: String, pi: PendingIntent, inputs: Array<RemoteInput>, platform: String = "WhatsApp") {
        map[key(platform, contact)] = Handle(pi, inputs)
    }

    /** @return null on success, or a short error message. */
    fun send(ctx: Context, contact: String, text: String, platform: String = "WhatsApp"): String? {
        val mapKey = key(platform, contact)
        val h = map[mapKey] ?: return "Can't reply: no live notification for this chat"
        val results = Bundle()
        h.inputs.forEach { results.putCharSequence(it.resultKey, text) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(h.inputs, intent, results)
        RemoteInput.setResultsSource(intent, RemoteInput.SOURCE_FREE_FORM_INPUT)
        return try {
            h.pi.send(ctx, 0, intent)
            null
        } catch (e: PendingIntent.CanceledException) {
            map.remove(mapKey)
            "Can't reply: notification expired"
        }
    }
}
