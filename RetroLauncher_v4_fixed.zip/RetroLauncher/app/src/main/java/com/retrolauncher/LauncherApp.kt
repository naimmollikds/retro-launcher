package com.retrolauncher

import android.app.Application

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        MessageStore.init(this)
    }
}
