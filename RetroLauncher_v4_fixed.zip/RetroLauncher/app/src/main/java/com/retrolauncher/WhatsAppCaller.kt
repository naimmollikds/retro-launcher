package com.retrolauncher

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * Starts a real WhatsApp voice/video call, or opens the real WhatsApp app.
 *
 * WhatsApp has no public "call this person" API. What it does do: for every contact that is on
 * WhatsApp it adds "Voice call" / "Video call" rows to the phone's contacts database, and
 * Android's own Contacts app uses those rows to start calls. We do the same. This is unofficial:
 * it only works for contacts WhatsApp has synced, and a WhatsApp update could change it.
 */
object WhatsAppCaller {
    private val PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")
    private const val BAD_CHARS = "\\'\"`<>&\${}"

    private fun installed(ctx: Context): List<String> = PACKAGES.filter {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (e: Exception) { false }
    }

    private fun digits(s: String?) = (s ?: "").filter { it.isDigit() }

    private fun sameNumber(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        if (a.length >= 9 && b.length >= 9) return a.takeLast(9) == b.takeLast(9)
        return a == b
    }

    private fun cleanName(raw: String) = raw.filter { it !in BAD_CHARS && !it.isISOControl() }.trim()

    /** Opens the real WhatsApp app. Returns null on success, or an error message. */
    fun openApp(ctx: Context): String? {
        val pkg = installed(ctx).firstOrNull() ?: return "WhatsApp is not installed on this phone."
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "Could not open WhatsApp."
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); null } catch (e: Exception) { "Could not open WhatsApp." }
    }

    /**
     * Starts a WhatsApp call to the contact matching [name] or [number].
     * Returns null when the call screen was opened, otherwise a short message for the user.
     */
    fun call(ctx: Context, name: String, number: String, video: Boolean): String? {
        val pkgs = installed(ctx)
        if (pkgs.isEmpty()) return "WhatsApp is not installed on this phone."
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Allow the Contacts permission first (open PEOPLE)."
        }
        val wantNumber = digits(number)
        val wantName = cleanName(name)

        for (pkg in pkgs) {
            val mime = "vnd.android.cursor.item/vnd.$pkg." + if (video) "video.call" else "voip.call"
            var byNumber: Long = -1
            var byName: Long = -1
            try {
                ctx.contentResolver.query(
                    ContactsContract.Data.CONTENT_URI,
                    arrayOf("_id", "display_name", "data1"),
                    "mimetype=?", arrayOf(mime), null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val disp = c.getString(1) ?: ""
                        val jid = digits((c.getString(2) ?: "").substringBefore('@'))
                        if (byNumber < 0 && sameNumber(wantNumber, jid)) byNumber = id
                        if (byName < 0 && wantName.isNotEmpty() && cleanName(disp).equals(wantName, ignoreCase = true)) byName = id
                    }
                }
            } catch (e: Exception) { /* try next package */ }

            val rowId = if (byNumber >= 0) byNumber else byName
            if (rowId < 0) continue
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, rowId.toString()), mime)
                .setPackage(pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(intent)
                return null
            } catch (e: ActivityNotFoundException) {
                // fall through to the fallback below
            } catch (e: SecurityException) {
                // fall through to the fallback below
            }
        }

        // No call entry for this contact (not synced, a group, or not a saved contact):
        // open the real WhatsApp so the call can be started there.
        val err = openApp(ctx)
        return err ?: "Could not start a WhatsApp call from here. WhatsApp opened instead: call from there."
    }
}
