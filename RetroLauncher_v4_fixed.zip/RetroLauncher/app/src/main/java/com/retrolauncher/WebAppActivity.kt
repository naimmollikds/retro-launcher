package com.retrolauncher

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream
import java.io.FileInputStream

/**
 * Full-screen host for the web apps added in Apps -> ADD APPLICATION.
 * No native bridge is attached, so a web app can never reach the launcher's data (messages, API key).
 * File apps are served from their own private origin (https://<id>.webapp.invalid), so even their
 * localStorage is separate from the launcher and from other apps.
 */
class WebAppActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var app: WebAppStore.App? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uris = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id") ?: ""
        val a = WebAppStore.get(this, id)
        if (a == null) { finish(); return }
        app = a
        title = a.name

        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = true
            displayZoomControls = false
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val cur = app ?: return null
                val u = request.url
                if (cur.kind != "file" || u.host != WebAppStore.hostFor(cur.id)) return null
                val path = u.path ?: "/"
                if (path == "/" || path == "/index.html") {
                    val f = WebAppStore.fileFor(this@WebAppActivity, cur.id)
                    if (f.exists()) return WebResourceResponse("text/html", "utf-8", FileInputStream(f))
                }
                // A single .html file has no other files to serve.
                return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                return when (u.scheme) {
                    "http", "https" -> false
                    "tel", "mailto", "sms" -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                        true
                    }
                    else -> true
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    chooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        if (a.kind == "file") web.loadUrl("https://${WebAppStore.hostFor(a.id)}/index.html")
        else web.loadUrl(a.url)
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
