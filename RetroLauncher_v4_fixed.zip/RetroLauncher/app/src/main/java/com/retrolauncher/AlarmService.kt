package com.retrolauncher

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Rings (sound + vibration) until dismissed, snoozed, or 90 seconds pass. */
class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "com.retrolauncher.ALARM_STOP"
        const val ACTION_SNOOZE = "com.retrolauncher.ALARM_SNOOZE"
        const val ACTION_FINISH = "com.retrolauncher.ALARM_FINISH_UI"
        private const val CH = "alarm_ring"
        private const val NOTIF_ID = 4242
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var title = "Alarm"
    private var body = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopRinging()
            return START_NOT_STICKY
        }
        if (action == ACTION_SNOOZE) {
            TimerScheduler.scheduleSnooze(
                this,
                intent?.getStringExtra("title") ?: "Alarm",
                intent?.getStringExtra("body") ?: ""
            )
            stopRinging()
            return START_NOT_STICKY
        }
        title = intent?.getStringExtra("title") ?: "Alarm"
        body = intent?.getStringExtra("body") ?: ""
        startRinging()
        return START_NOT_STICKY
    }

    private fun startRinging() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH) == null) {
                val ch = NotificationChannel(CH, "Alarm ringing", NotificationManager.IMPORTANCE_HIGH)
                ch.setSound(null, null)       // sound is played by this service
                ch.enableVibration(false)
                nm.createNotificationChannel(ch)
            }
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val uiIntent = Intent(this, AlarmActivity::class.java)
        uiIntent.putExtra("title", title)
        uiIntent.putExtra("body", body)
        uiIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val fullScreen = PendingIntent.getActivity(this, 2, uiIntent, flags)

        val stopPi = PendingIntent.getService(
            this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val snoozeIntent = Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE)
        snoozeIntent.putExtra("title", title)
        snoozeIntent.putExtra("body", body)
        val snoozePi = PendingIntent.getService(this, 4, snoozeIntent, flags)

        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("⏰ $title")
            .setContentText(if (body.isEmpty()) "Alarm" else body)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .addAction(0, "Snooze 10 min", snoozePi)
            .addAction(0, "Dismiss", stopPi)
            .build()

        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)

        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            // no sound available; vibration + notification still work
        }

        try {
            @Suppress("DEPRECATION")
            val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
            vibrator = v
        } catch (e: Exception) {
        }

        handler.postDelayed({ stopRinging() }, 90_000L)
    }

    private fun stopRinging() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (e: Exception) {}
        player?.release()
        player = null
        vibrator?.cancel()
        sendBroadcast(Intent(ACTION_FINISH).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { player?.release() } catch (e: Exception) {}
        player = null
        vibrator?.cancel()
        super.onDestroy()
    }
}
