package com.retrolauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TimerScheduler.ACTION_FIRE) return
        val key = intent.getStringExtra("key") ?: return
        val item = TimerScheduler.Item(
            key,
            intent.getStringExtra("kind") ?: "reminder",
            intent.getStringExtra("title") ?: "",
            intent.getStringExtra("body") ?: "",
            intent.getIntExtra("hour", 0),
            intent.getIntExtra("minute", 0),
            intent.getLongExtra("atMs", 0L),
            intent.getBooleanExtra("repeat", false)
        )

        // Daily alarms: arm tomorrow's ring first, in case anything below fails.
        if (item.repeat) TimerScheduler.schedule(ctx, item)

        if (item.kind == "alarm") {
            val svc = Intent(ctx, AlarmService::class.java)
            svc.putExtra("title", item.title)
            svc.putExtra("body", item.body)
            ContextCompat.startForegroundService(ctx, svc)
        } else {
            Notifier.post(ctx, item)
        }
    }
}

object Notifier {
    const val CH_REMINDERS = "reminders"

    fun ensureReminderChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH_REMINDERS) == null) {
                val ch = NotificationChannel(CH_REMINDERS, "Reminders & schedule", NotificationManager.IMPORTANCE_HIGH)
                nm.createNotificationChannel(ch)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun post(ctx: Context, item: TimerScheduler.Item) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureReminderChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CH_REMINDERS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(item.title)
            .setContentText(item.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        NotificationManagerCompat.from(ctx).notify(item.key.hashCode(), n)
    }
}
