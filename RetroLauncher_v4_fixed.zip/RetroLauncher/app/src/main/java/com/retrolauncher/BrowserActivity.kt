package com.retrolauncher

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.ComponentActivity
import androidx.activity.addCallback

/**
 * Full-screen browser used by the launcher's BROWSER tile.
 * A real top-level WebView, so every site works (the old iframe was blocked by
 * most sites with X-Frame-Options). Retro grayscale look, with a COLOR toggle.
 */
class BrowserActivity : ComponentActivity() {

    private lateinit var web: WebView
    private lateinit var urlField: EditText
    private lateinit var progress: ProgressBar
    private var gray = true

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val dp = { v: Int -> (v * d).toInt() }

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#E2E5DE"))
        bar.setPadding(dp(6), dp(4), dp(6), dp(4))

        val back = Button(this)
        back.text = "◀"
        back.minWidth = 0
        back.minimumWidth = 0
        back.setOnClickListener { if (web.canGoBack()) web.goBack() }
        bar.addView(back, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        urlField = EditText(this)
        urlField.setSingleLine(true)
        urlField.textSize = 13f
        urlField.hint = "Search or enter URL"
        urlField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlField.imeOptions = EditorInfo.IME_ACTION_GO
        urlField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                load(urlField.text.toString())
                true
            } else {
                false
            }
        }
        bar.addView(urlField, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val color = Button(this)
        color.text = "COLOR"
        color.minWidth = 0
        color.minimumWidth = 0
        color.setOnClickListener {
            gray = !gray
            applyGray()
        }
        bar.addView(color, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val close = Button(this)
        close.text = "✕"
        close.minWidth = 0
        close.minimumWidth = 0
        close.setOnClickListener { finish() }
        bar.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.visibility = View.GONE

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                val host = (u.host ?: "").lowercase()
                // Google intentionally blocks account sign-in inside embedded WebViews.
                // Hand authentication pages to the user's trusted system browser instead.
                if (u.scheme == "https" && (host == "accounts.google.com" || host.endsWith(".accounts.google.com"))) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                    return true
                }
                return when (u.scheme) {
                    "http", "https" -> false
                    "tel", "mailto", "sms" -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                        true
                    }
                    else -> true
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) urlField.setText(url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this) {
            if (web.canGoBack()) web.goBack() else finish()
        }

        applyGray()
        load(intent.getStringExtra("url") ?: "https://www.google.com")
    }

    private fun applyGray() {
        if (gray) {
            val cm = ColorMatrix()
            cm.setSaturation(0.1f)
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(cm)
            web.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        } else {
            web.setLayerType(View.LAYER_TYPE_NONE, null)
        }
    }

    private fun normalize(raw: String): String {
        val q = raw.trim()
        if (q.isEmpty()) return "https://www.google.com"
        if (q.startsWith("http://") || q.startsWith("https://")) return q
        if (q.contains('.') && !q.contains(' ')) return "https://$q"
        return "https://www.google.com/search?q=" + Uri.encode(q)
    }

    private fun load(raw: String) {
        web.loadUrl(normalize(raw))
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
