package com.retrolauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.JsResult
import androidx.fragment.app.FragmentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : FragmentActivity() {

    private val origin = "https://appassets.androidplatform.net"
    private lateinit var web: WebView
    private var promptedForAccess = false
    private var askedPerms = false
    private var pendingCall: String? = null

    private val storeListener: (String, MessageStore.Msg) -> Unit = { contact, msg ->
        runOnUiThread {
            push(JSONObject().put("type", "message").put("contact", contact).put("msg", msg.toJson()))
        }
    }

    // The AI finished rating a message: tell the web UI so the important list updates.
    private val flagListener: (String, MessageStore.Msg) -> Unit = { contact, msg ->
        runOnUiThread {
            push(JSONObject().put("type", "flag").put("contact", contact).put("msg", msg.toJson()))
        }
    }

    // File picker for Apps -> ADD APPLICATION -> CHOOSE .HTML FILE
    private val htmlPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            push(JSONObject().put("type", "htmlPicked").put("ok", false).put("error", ""))
            return@registerForActivityResult
        }
        Thread {
            var err = ""
            var name = ""
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    name = if (c.moveToFirst()) (c.getString(0) ?: "") else ""
                }
                val bytes = contentResolver.openInputStream(uri)?.use { readLimited(it, WebAppStore.MAX_HTML_BYTES) }
                if (bytes == null) {
                    err = "Could not read that file (maximum size is 8 MB)."
                } else {
                    val head = String(bytes, 0, minOf(bytes.size, 8192), Charsets.UTF_8).lowercase()
                    val looksHtml = name.lowercase().let { it.endsWith(".html") || it.endsWith(".htm") } ||
                        head.contains("<html") || head.contains("<!doctype") || head.contains("<body") || head.contains("<script")
                    if (!looksHtml) err = "That does not look like an HTML file."
                    else WebAppStore.stage(this, bytes)
                }
            } catch (e: Exception) {
                err = "Could not read that file."
            }
            val shown = name.substringBeforeLast('.', name)
            runOnUiThread {
                push(JSONObject().put("type", "htmlPicked").put("ok", err.isEmpty()).put("error", err).put("name", shown))
            }
        }.start()
    }

    private val homeRoleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { pushLauncherState() }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            pushContacts()
            val pc = pendingCall
            pendingCall = null
            if (pc != null) {
                if (result[Manifest.permission.CALL_PHONE] == true) placeCall(pc) else dialOnly(pc)
            }
            promptIfNeeded()
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MessageStore.init(this)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message ?: "Are you sure?")
                    .setNegativeButton("CANCEL") { _, _ -> result?.cancel() }
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Never let the top-level page navigate away from our bundled UI.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.isForMainFrame && !request.url.toString().startsWith(origin)
        }

        // Secure bridge: only exposed to our own https origin, never to iframes.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "nativeBridge", setOf(origin)) { _, message, sourceOrigin, isMainFrame, _ ->
                if (isMainFrame && sourceOrigin.toString() == origin) {
                    message.data?.let { handleMessage(it) }
                }
            }
        } else {
            AlertDialog.Builder(this)
                .setMessage("Please update Android System WebView / Chrome. This launcher needs a newer WebView.")
                .setPositiveButton("OK", null).show()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
            }
        })

        web.loadUrl("$origin/assets/www/index.html")
    }

    override fun onStart() {
        super.onStart()
        MessageStore.addListener(storeListener)
        MessageStore.addFlagListener(flagListener)
    }

    override fun onStop() {
        MessageStore.removeListener(storeListener)
        MessageStore.removeFlagListener(flagListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        val missing = missingPerms()
        if (missing.isNotEmpty() && !askedPerms) {
            askedPerms = true
            permLauncher.launch(missing)
        } else {
            if (hasPerm(Manifest.permission.READ_CONTACTS)) pushContacts()
            promptIfNeeded()
        }
        pushLauncherState()
        TimerScheduler.rescheduleAll(this)
        // Rate any message the AI could not reach earlier (no network, key just added, ...).
        ImportanceClassifier.sweep(this)
    }

    // Home pressed while launcher is already showing -> back to home screen
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
    }

    // ---------- permissions & prompts ----------

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun missingPerms(): Array<String> {
        val all = mutableListOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        return all.filter { !hasPerm(it) }.toTypedArray()
    }

    private fun hasAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openAccessSettings() =
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun promptIfNeeded() {
        val prefs = getSharedPreferences("launcher_prefs", MODE_PRIVATE)
        if (!hasAccess()) {
            if (promptedForAccess) return
            promptedForAccess = true
            AlertDialog.Builder(this)
                .setTitle("Allow notification access")
                .setMessage("To show your WhatsApp and Messenger messages and send replies, enable Notification access for Retro Launcher.\n\nOn Android 13+, if the switch is greyed out: App info → ⋮ menu → \"Allow restricted settings\", then try again.")
                .setPositiveButton("Open settings") { _, _ -> openAccessSettings() }
                .setNegativeButton("Later", null)
                .show()
        } else if (!prefs.getBoolean("battery_prompted", false)) {
            prefs.edit().putBoolean("battery_prompted", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Keep running in background")
                .setMessage("Some phones (Xiaomi etc.) kill background apps, which makes you miss WhatsApp messages and alarms.\n\nOn the next screen set Retro Launcher to \"Don't optimize\" / \"No restrictions\". Also enable Autostart for it in Security → Permissions.")
                .setPositiveButton("Open settings") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) {}
                }
                .setNegativeButton("Later", null)
                .show()
        } else if (!isDefaultHome() && !prefs.getBoolean("home_prompted", false)) {
            prefs.edit().putBoolean("home_prompted", true).apply()
            AlertDialog.Builder(this)
                .setTitle("Use Retro Launcher as your home screen?")
                .setMessage("Choose Retro Launcher as your Home app so it opens when you press Home. You can change this any time in Settings → SET AS DEFAULT LAUNCHER.")
                .setPositiveButton("Set as home app") { _, _ -> requestDefaultHome() }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    // ---------- default launcher ----------

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun requestDefaultHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    homeRoleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                }
            } catch (e: Exception) { /* use the settings screen below */ }
        }
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun pushLauncherState() {
        push(JSONObject().put("type", "launcherState").put("isDefault", isDefaultHome()))
    }

    // ---------- installed phone apps ----------

    private fun listInstalledApps() {
        Thread {
            val arr = JSONArray()
            try {
                val pm = packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                val found = if (Build.VERSION.SDK_INT >= 33)
                    pm.queryIntentActivities(q, PackageManager.ResolveInfoFlags.of(0L))
                else pm.queryIntentActivities(q, 0)
                val seen = HashSet<String>()
                val items = ArrayList<Pair<String, String>>()
                for (ri in found) {
                    val pkg = ri.activityInfo?.packageName ?: continue
                    if (pkg == packageName || !seen.add(pkg)) continue
                    items.add(Pair(ri.loadLabel(pm).toString(), pkg))
                }
                items.sortBy { it.first.lowercase() }
                items.forEach { arr.put(JSONObject().put("label", it.first).put("pkg", it.second)) }
            } catch (e: Exception) { /* send what we have */ }
            runOnUiThread { push(JSONObject().put("type", "apps").put("apps", arr)) }
        }.start()
    }

    private fun openInstalledApp(pkg: String) {
        if (!Regex("^[A-Za-z0-9._]+$").matches(pkg)) return
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { toast("Cannot open that app."); return }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { toast("Cannot open that app.") }
    }

    private fun readLimited(ins: java.io.InputStream, max: Int): ByteArray? {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            total += n
            if (total > max) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun toast(msg: String) {
        push(JSONObject().put("type", "toast").put("msg", msg))
    }

    private fun pushWebApps() {
        push(JSONObject().put("type", "webapps").put("apps", WebAppStore.listJson(this)))
    }

    // ---------- calls ----------

    private fun cleanNumber(raw: String) = raw.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

    private fun dialOnly(number: String) {
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) } catch (e: Exception) {}
    }

    private fun placeCall(raw: String) {
        val number = cleanNumber(raw)
        if (number.isEmpty()) return
        if (hasPerm(Manifest.permission.CALL_PHONE)) {
            try {
                startActivity(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)))
            } catch (e: Exception) {
                dialOnly(number)
            }
        } else {
            pendingCall = number
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE))
        }
    }

    // ---------- contacts ----------

    private fun roleOf(type: Int) = when (type) {
        1 -> "Home"
        2 -> "Mobile"
        3 -> "Work"
        else -> "Phone"
    }

    private fun loadContacts(): JSONArray {
        val out = JSONArray()
        val seen = HashSet<String>()
        val cols = arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER, Phone.TYPE)
        contentResolver.query(Phone.CONTENT_URI, cols, null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                val key = name + "|" + num.filter { it.isDigit() }
                if (!seen.add(key)) continue
                out.put(JSONObject().put("name", name).put("phone", num).put("role", roleOf(c.getInt(2))))
            }
        }
        return out
    }

    private fun pushContacts() {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            push(JSONObject().put("type", "contacts").put("contacts", JSONArray()).put("denied", true))
            return
        }
        Thread {
            val arr = try { loadContacts() } catch (e: Exception) { JSONArray() }
            runOnUiThread {
                push(JSONObject().put("type", "contacts").put("contacts", arr).put("denied", false))
            }
        }.start()
    }

    private fun requestPermsOrSettings() {
        val missing = missingPerms()
        if (missing.isEmpty()) return
        val canAsk = !askedPerms || missing.any { shouldShowRequestPermissionRationale(it) }
        if (canAsk) {
            askedPerms = true
            permLauncher.launch(missing)
        } else {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        }
    }

    private fun securePeoplePrefs() = EncryptedSharedPreferences.create(
        this,
        "private_key_people",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private fun authenticateKeyPeople() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            push(JSONObject().put("type", "keyPeopleBiometric").put("ok", false)
                .put("message", "Set up a fingerprint, face unlock, or phone screen lock first."))
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    val privatePrefs = securePeoplePrefs()
                    val people = privatePrefs.getString("people", "") ?: ""
                    val instructions = privatePrefs.getString("aiInstructions", "") ?: ""
                    val other = privatePrefs.getString("profileOther", "") ?: ""
                    push(JSONObject().put("type", "keyPeopleBiometric").put("ok", true).put("message", "Unlocked")
                        .put("people", people).put("instructions", instructions).put("other", other))
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    push(JSONObject().put("type", "keyPeopleBiometric").put("ok", false).put("message", errString.toString()))
                }
                override fun onAuthenticationFailed() {
                    push(JSONObject().put("type", "keyPeopleBiometric").put("ok", false).put("message", "Fingerprint not recognized. Try again."))
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Key People")
            .setSubtitle("Authenticate to view private relationship details")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    // ---------- bridge ----------

    private fun handleMessage(data: String) {
        try {
            val o = JSONObject(data)
            when (o.getString("op")) {
                "sync" -> push(
                    JSONObject().put("type", "threads")
                        .put("threads", MessageStore.snapshotJson()).put("access", hasAccess())
                        .put("aiError", ImportanceClassifier.lastError)
                )

                "sendReply" -> {
                    val id = o.getInt("id")
                    val contact = o.getString("contact")
                    val text = o.getString("text")
                    val platform = o.optString("platform", "WhatsApp").let { if (it == "Messenger") it else "WhatsApp" }
                    val err = ReplyRegistry.send(this, contact, text, platform)
                    if (err == null) {
                        MessageStore.add(contact, MessageStore.Msg("Me", text, System.currentTimeMillis(), "sent", urgent = false, checked = true, platform = platform))
                    }
                    push(
                        JSONObject().put("type", "sendResult").put("id", id)
                            .put("ok", err == null).put("error", err ?: "")
                    )
                }

                "clearRecentChats" -> {
                    MessageStore.clear()
                    push(JSONObject().put("type", "threads").put("threads", MessageStore.snapshotJson())
                        .put("access", hasAccess()).put("aiError", ImportanceClassifier.lastError))
                    push(JSONObject().put("type", "toast").put("msg", "Recent chats cleared"))
                }

                "openAccessSettings" -> openAccessSettings()
                "getContacts" -> pushContacts()
                "requestPerms" -> requestPermsOrSettings()
                "call" -> placeCall(o.getString("number"))

                "openBrowser" -> {
                    val url = o.getString("url")
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        val i = Intent(this, BrowserActivity::class.java)
                        i.putExtra("url", url)
                        startActivity(i)
                    }
                }

                // ----- biometric protection for private key people -----
                "biometricUnlock" -> authenticateKeyPeople()
                "saveKeyPeople" -> securePeoplePrefs().edit().putString("people", o.optString("people").take(2000)).apply()
                "savePrivateAiProfile" -> securePeoplePrefs().edit()
                    .putString("aiInstructions", o.optString("instructions").take(4000))
                    .putString("profileOther", o.optString("other").take(2000))
                    .putString("people", o.optString("people").take(2000)).apply()

                // ----- AI settings -----
                "saveAiConfig" -> {
                    AiConfig.save(this, o)
                    ImportanceClassifier.sweep(this)
                }
                "aiStatus" -> push(JSONObject().put("type", "aiStatus").put("error", ImportanceClassifier.lastError))
                "testAi" -> ImportanceClassifier.test(this) { ok, text ->
                    runOnUiThread { push(JSONObject().put("type", "aiTest").put("ok", ok).put("text", text)) }
                }

                // ----- launcher / apps -----
                "setDefaultLauncher" -> requestDefaultHome()
                "getLauncherState" -> pushLauncherState()
                "listApps" -> listInstalledApps()
                "openApp" -> openInstalledApp(o.getString("pkg"))
                "openWhatsApp" -> WhatsAppCaller.openApp(this)?.let { toast(it) }
                "waCall" -> WhatsAppCaller.call(
                    this, o.optString("name"), o.optString("number"), o.optBoolean("video")
                )?.let { toast(it) }

                // ----- plug-in web apps -----
                "getWebApps" -> pushWebApps()
                "pickHtml" -> htmlPicker.launch(arrayOf("*/*"))
                "addWebAppUrl" -> {
                    val app = WebAppStore.addUrl(this, o.optString("name"), o.optString("url"))
                    if (app == null) toast("Enter a name and a full web address starting with http:// or https://")
                    else { toast("✓ " + app.name + " added"); pushWebApps() }
                }
                "addWebAppFile" -> {
                    val app = WebAppStore.addStagedFile(this, o.optString("name"))
                    if (app == null) toast("Enter a name and choose an .html file first.")
                    else { toast("✓ " + app.name + " added"); pushWebApps() }
                }
                "removeWebApp" -> {
                    val id = o.getString("id")
                    if (Regex("^[0-9a-f]{10}$").matches(id)) { WebAppStore.remove(this, id); pushWebApps() }
                }
                "openWebApp" -> {
                    val id = o.getString("id")
                    if (Regex("^[0-9a-f]{10}$").matches(id) && WebAppStore.get(this, id) != null) {
                        startActivity(Intent(this, WebAppActivity::class.java).putExtra("id", id))
                    }
                }

                "syncTimers" -> {
                    if (Build.VERSION.SDK_INT >= 31) {
                        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                        val exactPrefs = getSharedPreferences("launcher_prefs", MODE_PRIVATE)
                        if (!am.canScheduleExactAlarms() && !exactPrefs.getBoolean("exact_alarm_prompted", false)) {
                            exactPrefs.edit().putBoolean("exact_alarm_prompted", true).apply()
                            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
                        }
                    }
                    val arr = o.getJSONArray("items")
                    val list = (0 until arr.length()).map { TimerScheduler.Item.fromJson(arr.getJSONObject(it)) }
                    val count = TimerScheduler.sync(this, list)
                    if (o.has("id")) push(JSONObject().put("type", "sendResult").put("id", o.getInt("id"))
                        .put("ok", count == list.size).put("scheduled", count).put("error", if (count == list.size) "" else "Some timers could not be scheduled"))
                }
            }
        } catch (e: Exception) { /* ignore malformed messages */ }
    }

    private fun push(payload: JSONObject) {
        val js = "window.__nativeIn && window.__nativeIn(${JSONObject.quote(payload.toString())});"
        web.evaluateJavascript(js, null)
    }
}
