package com.mealtracker.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/** type: 0 = lunch, 1 = dinner */
data class MealEntry(val date: LocalDate, val type: Int)

data class PackInfo(
    val index: Int,
    val taken: Int,
    val size: Int,
    val price: Int,
    val firstDate: LocalDate?,
    val lastDate: LocalDate?,
    val byMonth: List<Pair<YearMonth, Int>>,
    val paid: Boolean,
    val paidDate: String?
) {
    val number: Int get() = index + 1
    val complete: Boolean get() = taken >= size
    val remaining: Int get() = (size - taken).coerceAtLeast(0)
}

data class Summary(
    val entries: List<MealEntry>,
    val packs: List<PackInfo>,
    val current: PackInfo,
    val totalTaken: Int,
    val dueCount: Int,
    val paidCount: Int
)

class MealViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("meal_tracker", Context.MODE_PRIVATE)

    /** date (yyyy-MM-dd) -> bitmask: 1 = lunch, 2 = dinner */
    val days = mutableStateMapOf<String, Int>()

    /** pack index -> date paid (yyyy-MM-dd) */
    val paidPacks = mutableStateMapOf<Int, String>()

    var packSize by mutableIntStateOf(60)
        private set
    var packPrice by mutableIntStateOf(3500)
        private set
    var today by mutableStateOf(LocalDate.now())
        private set

    val summary: Summary by derivedStateOf { computeSummary() }

    init {
        load()
    }

    fun refreshToday() {
        today = LocalDate.now()
    }

    fun mask(date: LocalDate): Int = days[date.toString()] ?: 0

    fun isTaken(date: LocalDate, type: Int): Boolean = (mask(date) and (1 shl type)) != 0

    fun setMeal(date: LocalDate, type: Int, on: Boolean) {
        val key = date.toString()
        val bit = 1 shl type
        var m = days[key] ?: 0
        m = if (on) (m or bit) else (m and bit.inv())
        if (m == 0) days.remove(key) else days[key] = m
        save()
    }

    fun setBoth(date: LocalDate, on: Boolean) {
        val key = date.toString()
        if (on) days[key] = 3 else days.remove(key)
        save()
    }

    fun setPaid(index: Int, paid: Boolean) {
        if (paid) paidPacks[index] = LocalDate.now().toString() else paidPacks.remove(index)
        save()
    }

    fun updateSettings(size: Int, price: Int) {
        packSize = size.coerceAtLeast(1)
        packPrice = price.coerceAtLeast(0)
        save()
    }

    fun resetAll() {
        days.clear()
        paidPacks.clear()
        save()
    }

    private fun makePack(index: Int, chunk: List<MealEntry>, size: Int, price: Int): PackInfo {
        val byMonth = chunk.groupBy { YearMonth.from(it.date) }.map { it.key to it.value.size }
        return PackInfo(
            index = index,
            taken = chunk.size,
            size = size,
            price = price,
            firstDate = chunk.firstOrNull()?.date,
            lastDate = chunk.lastOrNull()?.date,
            byMonth = byMonth,
            paid = paidPacks.containsKey(index),
            paidDate = paidPacks[index]
        )
    }

    private fun computeSummary(): Summary {
        val size = packSize
        val price = packPrice
        val all = ArrayList<MealEntry>()
        for (k in days.keys.sorted()) {
            val m = days[k] ?: 0
            val d = LocalDate.parse(k)
            if ((m and 1) != 0) all.add(MealEntry(d, 0))
            if ((m and 2) != 0) all.add(MealEntry(d, 1))
        }
        val packs = ArrayList<PackInfo>()
        all.chunked(size).forEachIndexed { i, chunk -> packs.add(makePack(i, chunk, size, price)) }
        if (packs.isEmpty() || packs.last().complete) {
            packs.add(makePack(packs.size, emptyList(), size, price))
        }
        val dueCount = packs.count { it.complete && !it.paid }
        val paidCount = packs.count { it.complete && it.paid }
        return Summary(all, packs, packs.last(), all.size, dueCount, paidCount)
    }

    fun exportText(): String {
        val s = summary
        val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
        val sb = StringBuilder()
        sb.append("Meal Tracker summary (").append(today.format(fmt)).append(")\n")
        sb.append("Pack: ").append(packSize).append(" meals = ").append(packPrice).append(" BDT\n\n")
        for (p in s.packs) {
            sb.append("Pack #").append(p.number).append(": ")
                .append(p.taken).append("/").append(p.size).append(" meals")
            val status = when {
                p.paid -> "PAID" + (p.paidDate?.let { " on $it" } ?: "")
                p.complete -> "DUE " + p.price + " BDT"
                else -> "in progress"
            }
            sb.append(" - ").append(status).append("\n")
            for ((ym, c) in p.byMonth) {
                sb.append("   ").append(ym.format(DateTimeFormatter.ofPattern("MMM yyyy", Locale.ENGLISH)))
                    .append(": ").append(c).append(" meals\n")
            }
        }
        return sb.toString()
    }

    private fun load() {
        packSize = prefs.getInt("size", 60)
        packPrice = prefs.getInt("price", 3500)
        runCatching {
            val o = JSONObject(prefs.getString("days", "{}") ?: "{}")
            for (k in o.keys()) days[k] = o.getInt(k)
        }
        runCatching {
            val o = JSONObject(prefs.getString("paid", "{}") ?: "{}")
            for (k in o.keys()) paidPacks[k.toInt()] = o.getString(k)
        }
    }

    private fun save() {
        val d = JSONObject()
        for ((k, v) in days) d.put(k, v)
        val p = JSONObject()
        for ((k, v) in paidPacks) p.put(k.toString(), v)
        prefs.edit()
            .putString("days", d.toString())
            .putString("paid", p.toString())
            .putInt("size", packSize)
            .putInt("price", packPrice)
            .apply()
    }
}

fun money(v: Double): String = "৳" + String.format(Locale.US, "%,.0f", v)
fun money2(v: Double): String = "৳" + String.format(Locale.US, "%,.2f", v)
