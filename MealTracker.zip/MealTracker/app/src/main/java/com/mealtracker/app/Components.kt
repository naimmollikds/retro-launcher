package com.mealtracker.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    brush: Brush? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(brush ?: Brush.linearGradient(listOf(CardBg, CardBg)))
            .border(1.dp, Color.White.copy(alpha = 0.07f), shape)
            .padding(18.dp),
        content = content
    )
}

@Composable
fun Pill(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun Stat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, color = TextDim, fontSize = 12.sp)
        Text(value, color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 12.dp)
    )
}

@Composable
fun ProgressRing(
    progress: Float,
    top: String,
    bottom: String,
    size: Dp = 150.dp
) {
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f), tween(700), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val stroke = 16.dp.toPx()
            drawArc(
                color = Color.White.copy(alpha = 0.12f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            rotate(-90f) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Cyan, Violet, Pink, Cyan)),
                    startAngle = 0f,
                    sweepAngle = 360f * anim,
                    useCenter = false,
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(top, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(bottom, color = TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
fun MealToggleCard(
    title: String,
    emoji: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onChange: (Boolean) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val bg by animateColorAsState(
        if (checked) Green.copy(alpha = 0.20f) else Card2,
        label = "mealBg"
    )
    val borderColor = if (checked) Green else Color.White.copy(alpha = 0.08f)
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .border(1.5.dp, borderColor, shape)
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onChange(!checked)
            }
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if (checked) Green else Color.Transparent)
                    .border(2.dp, if (checked) Green else TextDim, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (checked) Text("✓", color = Bg, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
            if (checked) "Taken" else "Not taken",
            color = if (checked) Green else TextDim,
            fontSize = 13.sp
        )
    }
}

@Composable
fun DayEditor(vm: MealViewModel, date: LocalDate) {
    val m = vm.mask(date)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        MealToggleCard("Lunch", "🍛", (m and 1) != 0, Modifier.weight(1f)) { vm.setMeal(date, 0, it) }
        MealToggleCard("Dinner", "🍽️", (m and 2) != 0, Modifier.weight(1f)) { vm.setMeal(date, 1, it) }
    }
}

@Composable
fun MiniDot(label: String, on: Boolean) {
    Text(
        label,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        color = if (on) Bg else TextDim,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (on) Green else Color.White.copy(alpha = 0.08f))
            .size(16.dp)
            .padding(top = 2.dp)
    )
}
