package com.mealtracker.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B1020)
val CardBg = Color(0xFF151B33)
val Card2 = Color(0xFF1E2750)
val Cyan = Color(0xFF22D3EE)
val Violet = Color(0xFF8B5CF6)
val Pink = Color(0xFFF472B6)
val Amber = Color(0xFFFBBF24)
val Green = Color(0xFF34D399)
val Red = Color(0xFFF87171)
val TextDim = Color(0xFF94A3B8)

@Composable
fun MealTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            onPrimary = Bg,
            secondary = Violet,
            background = Bg,
            onBackground = Color.White,
            surface = CardBg,
            onSurface = Color.White,
            surfaceVariant = Card2,
            onSurfaceVariant = TextDim,
            error = Red
        ),
        content = content
    )
}
