package com.mealtracker.app

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

private val dayFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.ENGLISH)
private val fullFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)
private val monthFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
private val monthShortFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM yyyy", Locale.ENGLISH)

@Composable
fun DayDialog(vm: MealViewModel, date: LocalDate, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(date.format(dayFmt), color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                DayEditor(vm, date)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.setBoth(date, true) }) { Text("Both ✓") }
                    OutlinedButton(onClick = { vm.setBoth(date, false) }) { Text("Clear") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

// ───────────────────────── HOME ─────────────────────────

@Composable
fun HomeScreen(vm: MealViewModel) {
    val s = vm.summary
    val today = vm.today
    val cur = s.current
    val perMeal = vm.packPrice.toDouble() / vm.packSize
    var editDate by remember { mutableStateOf<LocalDate?>(null) }

    val monthMeals = s.entries.count { YearMonth.from(it.date) == YearMonth.from(today) }
    val last14 = s.entries.count { !it.date.isBefore(today.minusDays(13)) && !it.date.isAfter(today) }
    val rate = max(last14 / 14.0, 0.5)
    val daysLeft = if (cur.remaining > 0) ceil(cur.remaining / rate).toLong() else 0L
    val finish = today.plusDays(daysLeft)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(Modifier.padding(top = 8.dp)) {
                Text("Meal Tracker", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(today.format(dayFmt), color = TextDim, fontSize = 14.sp)
            }
        }

        // Hero
        item {
            AppCard(brush = Brush.linearGradient(listOf(Color(0xFF1B2A5E), Color(0xFF3B1F6B)))) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        progress = cur.taken.toFloat() / cur.size,
                        top = "${cur.taken}/${cur.size}",
                        bottom = "meals taken"
                    )
                    Spacer(Modifier.padding(start = 12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("PACK #${cur.number}", Cyan)
                        Stat("Remaining", "${cur.remaining} meals", Amber)
                        Stat("Money used", money(cur.taken * perMeal), Pink)
                        Stat("Money left", money(cur.remaining * perMeal), Green)
                    }
                }
            }
        }

        // Dues
        if (s.dueCount > 0) {
            item {
                val unpaid = s.packs.filter { it.complete && !it.paid }
                AppCard(brush = Brush.linearGradient(listOf(Color(0xFF5B1A2B), Color(0xFF3A1230)))) {
                    Text("💸 Payment due", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${money((s.dueCount * vm.packPrice).toDouble())} for ${s.dueCount} completed pack(s)",
                        color = Red, fontSize = 15.sp, modifier = Modifier.padding(vertical = 6.dp)
                    )
                    for (p in unpaid) {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Pack #${p.number} • ${money(p.price.toDouble())}", color = Color.White, modifier = Modifier.weight(1f))
                            Button(
                                onClick = { vm.setPaid(p.index, true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
                            ) { Text("Mark paid") }
                        }
                    }
                }
            }
        }

        // Today
        item {
            AppCard {
                SectionTitle("Today")
                DayEditor(vm, today)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.setBoth(today, true) }) { Text("Both ✓") }
                    OutlinedButton(onClick = { vm.setBoth(today, false) }) { Text("Clear") }
                }
            }
        }

        // Last 7 days
        item {
            AppCard {
                SectionTitle("Last 7 days  (tap to edit)")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 6 downTo 0) {
                        val d = today.minusDays(i.toLong())
                        val m = vm.mask(d)
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (d == today) Card2 else Color.White.copy(alpha = 0.04f))
                                .clickable { editDate = d }
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale.ENGLISH),
                                color = TextDim, fontSize = 11.sp
                            )
                            Text(d.dayOfMonth.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                MiniDot("L", (m and 1) != 0)
                                MiniDot("D", (m and 2) != 0)
                            }
                        }
                    }
                }
            }
        }

        // Insights
        item {
            AppCard {
                SectionTitle("Insights")
                Row(Modifier.fillMaxWidth()) {
                    Stat("This month", "$monthMeals meals", Cyan, Modifier.weight(1f))
                    Stat("Month cost", money2(monthMeals * perMeal), Pink, Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth()) {
                    Stat("Cost per meal", money2(perMeal), Amber, Modifier.weight(1f))
                    Stat("Pace (14 days)", String.format(Locale.US, "%.1f / day", last14 / 14.0), Violet, Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                if (cur.remaining > 0) {
                    Text(
                        "At your pace this pack ends around ${finish.format(fullFmt)} (~$daysLeft days).",
                        color = TextDim, fontSize = 13.sp
                    )
                }
                Text(
                    "Lifetime meals logged: ${s.totalTaken}",
                    color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }

    editDate?.let { d -> DayDialog(vm, d) { editDate = null } }
}

// ───────────────────────── CALENDAR ─────────────────────────

@Composable
fun CalendarScreen(vm: MealViewModel) {
    var ym by remember { mutableStateOf(YearMonth.from(vm.today)) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    val s = vm.summary
    val perMeal = vm.packPrice.toDouble() / vm.packSize
    val monthMeals = s.entries.count { YearMonth.from(it.date) == ym }
    val monthLunch = s.entries.count { YearMonth.from(it.date) == ym && it.type == 0 }
    val monthDinner = monthMeals - monthLunch

    val first = ym.atDay(1)
    val offset = first.dayOfWeek.value % 7 // Sunday = 0
    val len = ym.lengthOfMonth()
    val rows = (offset + len + 6) / 7
    val labels = listOf("S", "M", "T", "W", "T", "F", "S")

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                TextButton(onClick = { ym = ym.minusMonths(1) }) { Text("‹", fontSize = 28.sp) }
                Text(
                    ym.format(monthFmt),
                    color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { ym = ym.plusMonths(1) }) { Text("›", fontSize = 28.sp) }
            }
        }
        item {
            AppCard {
                Row(Modifier.fillMaxWidth()) {
                    for (l in labels) {
                        Text(l, color = TextDim, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(8.dp))
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (c in 0 until 7) {
                            val dayNum = r * 7 + c - offset + 1
                            if (dayNum < 1 || dayNum > len) {
                                Box(Modifier.weight(1f).aspectRatio(0.85f))
                            } else {
                                val d = ym.atDay(dayNum)
                                val m = vm.mask(d)
                                val bg = when (m) {
                                    3 -> Green.copy(alpha = 0.30f)
                                    0 -> Color.White.copy(alpha = 0.04f)
                                    else -> Amber.copy(alpha = 0.28f)
                                }
                                val shape = RoundedCornerShape(12.dp)
                                Column(
                                    Modifier
                                        .weight(1f)
                                        .aspectRatio(0.85f)
                                        .clip(shape)
                                        .background(bg)
                                        .border(if (d == vm.today) 2.dp else 0.dp, if (d == vm.today) Cyan else Color.Transparent, shape)
                                        .clickable { selected = d },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(dayNum.toString(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(3.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        MiniDot("L", (m and 1) != 0)
                                        MiniDot("D", (m and 2) != 0)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Green = both meals • Yellow = one meal • Tap a day to edit", color = TextDim, fontSize = 12.sp)
            }
        }
        item {
            AppCard {
                SectionTitle("${ym.format(monthShortFmt)} summary")
                Row(Modifier.fillMaxWidth()) {
                    Stat("Meals", "$monthMeals", Cyan, Modifier.weight(1f))
                    Stat("Lunch", "$monthLunch", Amber, Modifier.weight(1f))
                    Stat("Dinner", "$monthDinner", Violet, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Stat("Cost of these meals", money2(monthMeals * perMeal), Pink)
            }
        }
    }

    selected?.let { d -> DayDialog(vm, d) { selected = null } }
}

// ───────────────────────── PACKS ─────────────────────────

@Composable
fun PacksScreen(vm: MealViewModel) {
    val s = vm.summary
    val totalPaid = s.paidCount * vm.packPrice
    val totalDue = s.dueCount * vm.packPrice

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Packs & Payments", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            AppCard(brush = Brush.linearGradient(listOf(Color(0xFF14325A), Color(0xFF2A1F5E)))) {
                Row(Modifier.fillMaxWidth()) {
                    Stat("Paid so far", money(totalPaid.toDouble()), Green, Modifier.weight(1f))
                    Stat("Due now", money(totalDue.toDouble()), if (totalDue > 0) Red else TextDim, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "${vm.packSize} meals = ${money(vm.packPrice.toDouble())} per pack",
                    color = TextDim, fontSize = 13.sp
                )
            }
        }
        items(s.packs.reversed()) { p ->
            PackCard(p, vm)
        }
    }
}

@Composable
fun PackCard(p: PackInfo, vm: MealViewModel) {
    val (statusText, statusColor) = when {
        p.paid -> "PAID ✓" to Green
        p.complete -> "PAYMENT DUE" to Red
        else -> "IN PROGRESS" to Cyan
    }
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pack #${p.number}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Pill(statusText, statusColor)
        }
        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(
            progress = { (p.taken.toFloat() / p.size).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
            color = statusColor,
            trackColor = Color.White.copy(alpha = 0.10f)
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("${p.taken}/${p.size} meals", color = Color.White, modifier = Modifier.weight(1f))
            Text(money(p.price.toDouble()), color = Amber, fontWeight = FontWeight.Bold)
        }
        if (p.firstDate != null && p.lastDate != null) {
            Text(
                "${p.firstDate.format(fullFmt)} → ${p.lastDate.format(fullFmt)}",
                color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
            )
        }
        if (p.byMonth.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            for ((ym, count) in p.byMonth) {
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(ym.format(monthShortFmt), color = TextDim, modifier = Modifier.weight(1f))
                    Text("$count meals", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (p.paid && p.paidDate != null) {
            Text("Paid on ${p.paidDate}", color = Green, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        if (p.complete) {
            Spacer(Modifier.height(12.dp))
            if (p.paid) {
                OutlinedButton(onClick = { vm.setPaid(p.index, false) }) { Text("Mark unpaid") }
            } else {
                Button(
                    onClick = { vm.setPaid(p.index, true) },
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
                ) { Text("Mark as paid") }
            }
        }
    }
}

// ───────────────────────── SETTINGS ─────────────────────────

@Composable
fun SettingsScreen(vm: MealViewModel) {
    val ctx = LocalContext.current
    var sizeText by remember { mutableStateOf(vm.packSize.toString()) }
    var priceText by remember { mutableStateOf(vm.packPrice.toString()) }
    var confirmReset by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Settings", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            AppCard {
                SectionTitle("Meal pack")
                OutlinedTextField(
                    value = sizeText,
                    onValueChange = { sizeText = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Meals per pack") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { c -> c.isDigit() }.take(7) },
                    label = { Text("Pack price (BDT)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val sz = sizeText.toIntOrNull() ?: 0
                    val pr = priceText.toIntOrNull() ?: -1
                    if (sz < 1 || pr < 0) {
                        Toast.makeText(ctx, "Enter valid numbers", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.updateSettings(sz, pr)
                        Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Save") }
                Text(
                    "Changing pack size re-splits all your logged meals into packs.",
                    color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        item {
            AppCard {
                SectionTitle("Share")
                Button(onClick = {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, vm.exportText())
                    }
                    ctx.startActivity(Intent.createChooser(i, "Share summary"))
                }) { Text("Share meal summary") }
            }
        }
        item {
            AppCard {
                SectionTitle("Danger zone")
                OutlinedButton(
                    onClick = { confirmReset = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)
                ) { Text("Erase all data") }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = CardBg,
            title = { Text("Erase everything?", color = Color.White) },
            text = { Text("All meal logs and paid marks will be deleted.", color = TextDim) },
            confirmButton = {
                TextButton(onClick = { vm.resetAll(); confirmReset = false }) { Text("Erase", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}
