# Meal Tracker (Kotlin + Jetpack Compose)

Counts lunch/dinner per **60-meal pack** (default 3500 BDT), not per month.

## Build on GitHub (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Push to `main`. Open the **Actions** tab -> "Build APK" runs automatically.
3. When it finishes, open the run and download the **MealTracker-debug-apk** artifact, unzip, install the APK.

## Build in Android Studio
Open the folder, let Gradle sync (it will create the wrapper), then Run.
