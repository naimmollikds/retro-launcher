# Retro Launcher v3

## Build (GitHub Actions, same as before)
Replace RetroLauncher.zip in your repo with this one, run the workflow, download the APK.
This version uses a FIXED signing key (app/retro-debug.keystore): future builds install
OVER this one and keep your data. Uninstall the old v1 once (it used a random key).
Keep the GitHub repo PRIVATE: anyone with the keystore could sign look-alike updates.

## First run on the phone
1. Allow Contacts, Phone (calls) and Notifications when asked.
2. Notification access (WhatsApp). Android 13+: App info -> ⋮ -> Allow restricted settings first.
3. Battery: set to "No restrictions", enable Autostart (Xiaomi: Security -> Permissions -> Autostart),
   and lock the app in the recents screen. Otherwise MIUI kills the listener and you MISS messages.
4. Make it the default Home app: accept the prompt on first start, or Settings -> SET AS DEFAULT LAUNCHER
   (or Android Settings -> Apps -> Default apps -> Home app).
5. Settings: paste your Gemini API key, press TEST AI CONNECTION, fill AI INSTRUCTIONS and MY PROFILE, SAVE.

## What is real now
- WhatsApp: every notification message is captured (up to 200 per chat); reply via notification.
- Important messages: NOTHING is flagged by keywords any more. Every received WhatsApp message is sent to the
  Gemini API (with your profile + AI instructions + the last 3 messages of that chat for context) and only
  messages the AI rates important show in the IMPORTANT banner / list. "hi", "hello" etc. are ignored.
  No API key, filter switched off, or API error = nothing is flagged; unrated messages are retried later.
  The banner says "No important message" when the list is empty. CLEAR LIST hides what was rated so far.
- Contacts: your phone contacts, searchable in PEOPLE and in the dial pad.
- Calls: PEOPLE / dial pad buttons place a real phone call (system call screen).
- WhatsApp calls: phone buttons in the WhatsApp chat header (voice + video) and in PEOPLE start a real WhatsApp
  call through WhatsApp's own entry in your contacts. Unofficial: needs Contacts permission and a contact WhatsApp
  has synced. If it cannot start the call, the real WhatsApp app opens instead. Apps -> "WhatsApp (real app)"
  also opens it directly.
- Alarms: ring daily at the set time (sound+vibration, lock-screen screen, snooze 10 min, survive reboot).
- Reminders: optional "REMIND AT" date/time -> notification. No time = plain to-do.
- Schedule: time (e.g. 10:00 AM) + optional date -> alert 10 minutes before. No date = today.
- Browser: opens a full-screen browser (any site). COLOR button toggles grayscale.
- Apps -> ADD APPLICATION: plug in your own web apps without touching this code. Give a name and either a web
  link or pick a single .html file from the phone. They appear under MY APPS and open full screen. Each app has
  its own storage and cannot read your messages, API key or other apps. A file app is ONE .html file (it may load
  scripts/styles from the internet, but cannot include other local files).
- Apps -> PHONE APPS: searchable list of every app installed on the phone; tap to open.

## Privacy
Each received WhatsApp message (text, chat name, a few earlier messages of that chat) and your profile text are
sent to Google's Gemini API for rating. The API key and settings are stored on the phone (not encrypted).

## Limits
- The UI loads Tailwind and Font Awesome from the internet (CDN). Offline, the launcher looks unstyled.
- WhatsApp does not allow reading chat history. Only messages that produced a notification
  while the listener was running are captured (muted chats, chat open on screen, or a killed
  background service = missed).
- Reply works only while WhatsApp still has a notification for that chat.
- Calendar/class schedule is local to this app (not synced with Google Calendar).
