package com.retrolauncher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Holds WhatsApp conversations captured from notifications.
 * Persisted as JSON in app-private storage (not encrypted, not backed up).
 *
 * "urgent" is only ever set by the AI (ImportanceClassifier). No keyword rules.
 * "checked" = the AI has already rated this message.
 */
object MessageStore {
    private const val PREFS = "wa_store"
    private const val KEY = "threads"
    private const val MAX_PER_THREAD = 200

    data class Msg(
        val sender: String,
        val text: String,
        val timeMs: Long,
        val type: String,      // "received" | "sent"
        val urgent: Boolean = false,
        val checked: Boolean = false,
        val reason: String = "",
        val id: String = UUID.randomUUID().toString()
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("sender", sender).put("text", text).put("timeMs", timeMs)
            .put("type", type).put("urgent", urgent)
            .put("checked", checked).put("reason", reason).put("id", id)
    }

    private val threads = LinkedHashMap<String, MutableList<Msg>>()
    private var prefs: SharedPreferences? = null
    private val listeners = CopyOnWriteArraySet<(String, Msg) -> Unit>()
    private val flagListeners = CopyOnWriteArraySet<(String, Msg) -> Unit>()

    fun addListener(l: (String, Msg) -> Unit) { listeners.add(l) }
    fun removeListener(l: (String, Msg) -> Unit) { listeners.remove(l) }

    /** Called when the AI has rated a stored message. */
    fun addFlagListener(l: (String, Msg) -> Unit) { flagListeners.add(l) }
    fun removeFlagListener(l: (String, Msg) -> Unit) { flagListeners.remove(l) }

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs?.getString(KEY, null) ?: return
        try {
            val root = JSONObject(raw)
            for (contact in root.keys()) {
                val arr = root.getJSONArray(contact)
                val list = mutableListOf<Msg>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    // Messages saved by older versions were flagged by a keyword list and never
                    // rated by the AI: they come back as "not important, not checked yet".
                    val checked = o.optBoolean("checked", false)
                    list.add(
                        Msg(
                            o.getString("sender"), o.getString("text"), o.getLong("timeMs"),
                            o.getString("type"),
                            urgent = checked && o.optBoolean("urgent"),
                            checked = checked,
                            reason = o.optString("reason", ""),
                            id = o.optString("id", "").ifEmpty { UUID.randomUUID().toString() }
                        )
                    )
                }
                threads[contact] = list
            }
        } catch (_: Exception) { threads.clear() }
    }

    /** Returns true if the message was new. */
    fun add(contact: String, msg: Msg): Boolean {
        val added: Boolean
        synchronized(this) {
            val list = threads.getOrPut(contact) { mutableListOf() }
            val dup = list.any { it.timeMs == msg.timeMs && it.text == msg.text && it.sender == msg.sender }
            if (dup) return false
            list.add(msg)
            list.sortBy { it.timeMs }
            while (list.size > MAX_PER_THREAD) list.removeAt(0)
            persist()
            added = true
        }
        if (added) listeners.forEach { it(contact, msg) }
        return added
    }

    /** Stores the AI verdict for one message and tells the UI. */
    fun setImportance(contact: String, id: String, urgent: Boolean, reason: String) {
        var updated: Msg? = null
        synchronized(this) {
            val list = threads[contact] ?: return
            val i = list.indexOfFirst { it.id == id }
            if (i < 0) return
            val m = list[i].copy(urgent = urgent, checked = true, reason = reason)
            list[i] = m
            persist()
            updated = m
        }
        updated?.let { m -> flagListeners.forEach { it(contact, m) } }
    }

    /** Received messages the AI has not rated yet (newest first), recent ones only. */
    @Synchronized
    fun unchecked(maxAgeMs: Long, limit: Int): List<Pair<String, Msg>> {
        val cutoff = System.currentTimeMillis() - maxAgeMs
        val out = ArrayList<Pair<String, Msg>>()
        for ((c, list) in threads) {
            for (m in list) {
                if (m.type == "received" && !m.checked && m.timeMs >= cutoff) out.add(Pair(c, m))
            }
        }
        out.sortByDescending { it.second.timeMs }
        return if (out.size > limit) out.subList(0, limit).toList() else out
    }

    /** Up to [n] messages that came before [msg] in the same chat (oldest first). */
    @Synchronized
    fun contextBefore(contact: String, msg: Msg, n: Int): List<Msg> {
        val list = threads[contact] ?: return emptyList()
        val earlier = list.filter { it.timeMs < msg.timeMs }
        return if (earlier.size > n) earlier.subList(earlier.size - n, earlier.size).toList() else earlier.toList()
    }

    @Synchronized
    fun snapshotJson(): JSONObject {
        val root = JSONObject()
        for ((c, list) in threads) {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            root.put(c, arr)
        }
        return root
    }

    @Synchronized
    fun clear() { threads.clear(); persist() }

    private fun persist() {
        prefs?.edit()?.putString(KEY, snapshotJson().toString())?.apply()
    }
}
