package com.retrolauncher

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Schedules alarms, reminders and schedule alerts with AlarmManager.
 * The web UI sends the full list every time something changes (syncTimers).
 */
object TimerScheduler {
    const val ACTION_FIRE = "com.retrolauncher.TIMER_FIRE"
    private const val PREFS = "timers"
    private const val KEY_ITEMS = "items"
    private const val SNOOZE_MS = 10 * 60 * 1000L

    data class Item(
        val key: String,
        val kind: String,      // "alarm" | "reminder" | "schedule"
        val title: String,
        val body: String,
        val hour: Int,
        val minute: Int,
        val atMs: Long,        // one-shot time (ignored when repeat = true)
        val repeat: Boolean    // true = every day at hour:minute
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("key", key).put("kind", kind).put("title", title).put("body", body)
            .put("hour", hour).put("minute", minute).put("atMs", atMs).put("repeat", repeat)

        companion object {
            fun fromJson(o: JSONObject): Item = Item(
                o.getString("key"), o.getString("kind"), o.optString("title"), o.optString("body"),
                o.optInt("hour"), o.optInt("minute"), o.optLong("atMs"), o.optBoolean("repeat")
            )
        }
    }

    fun nextDaily(hour: Int, minute: Int, after: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = after
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= after) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private fun pendingFor(ctx: Context, item: Item): PendingIntent {
        val intent = Intent(ctx, TimerReceiver::class.java)
        intent.action = ACTION_FIRE
        intent.data = Uri.parse("timer://" + Uri.encode(item.key))
        intent.putExtra("key", item.key)
        intent.putExtra("kind", item.kind)
        intent.putExtra("title", item.title)
        intent.putExtra("body", item.body)
        intent.putExtra("hour", item.hour)
        intent.putExtra("minute", item.minute)
        intent.putExtra("atMs", item.atMs)
        intent.putExtra("repeat", item.repeat)
        return PendingIntent.getBroadcast(
            ctx, item.key.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** @return true if something was scheduled (trigger time is in the future). */
    fun schedule(ctx: Context, item: Item): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val trigger = if (item.repeat) nextDaily(item.hour, item.minute) else item.atMs
        if (trigger <= System.currentTimeMillis()) return false
        val pi = pendingFor(ctx, item)
        try {
            if (item.kind == "alarm") {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(trigger, showIntent(ctx)), pi)
            } else if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
        return true
    }

    private fun cancel(ctx: Context, item: Item) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingFor(ctx, item))
    }

    @Synchronized
    fun sync(ctx: Context, items: List<Item>) {
        loadItems(ctx).forEach { cancel(ctx, it) }
        items.forEach { schedule(ctx, it) }
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    fun loadItems(ctx: Context): List<Item> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, null)
            ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { Item.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** After reboot / app update all AlarmManager entries are gone. */
    fun rescheduleAll(ctx: Context) {
        loadItems(ctx).forEach { schedule(ctx, it) }
    }

    fun scheduleSnooze(ctx: Context, title: String, body: String) {
        val now = System.currentTimeMillis()
        schedule(ctx, Item("snooze:$now", "alarm", title, body, 0, 0, now + SNOOZE_MS, false))
    }
}
