/*
 * Native bridge for the Retro Launcher.
 * Loaded AFTER the original UI script. It leaves all markup/styling alone and only:
 *   - replaces the mock chatThreads with real WhatsApp data from Android
 *   - routes replies through Android's notification Reply action
 * Outside the Android app (plain browser) it does nothing, so the original demo still works.
 */
(function () {
  'use strict';
  if (!window.nativeBridge) { console.info('[bridge] not inside launcher, mock mode'); return; }

  const post = (o) => nativeBridge.postMessage(JSON.stringify(o));
  const pending = {};
  let seq = 0;

  // Real message text is untrusted: the UI injects it via innerHTML, so escape it.
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function fmt(ms) {
    const d = new Date(ms);
    let h = d.getHours();
    const m = String(d.getMinutes()).padStart(2, '0');
    const ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return h + ':' + m + ' ' + ap;
  }

  const toUi = (m) => ({
    sender: esc(m.sender), text: esc(m.text), time: fmt(m.timeMs),
    type: m.type, urgent: !!m.urgent
  });

  // Don't keep a second copy of message content in WebView localStorage.
  const origSet = Storage.prototype.setItem;
  Storage.prototype.setItem = function (k, v) {
    if (k === 'whatsapp_chat_threads') return;
    return origSet.call(this, k, v);
  };

  // The home banner uses innerText, so it would show escaped entities (&#39;) literally.
  // Wrap the feed renderer and decode that one element back to plain text (textarea = inert).
  const decode = (str) => { const t = document.createElement('textarea'); t.innerHTML = str; return t.value; };
  const origRender = window.renderRecentNotifications;
  window.renderRecentNotifications = function () {
    origRender();
    const el = document.getElementById('ai-summary-text');
    if (el) el.innerText = decode(el.innerText);
  };

  // Start empty instead of showing mock chats until native data arrives.
  chatThreads = {};
  renderRecentNotifications();

  function refreshUi() {
    renderRecentNotifications();
    const modal = document.getElementById('app-modal');
    const open = modal && !modal.classList.contains('translate-y-full');
    const title = (document.getElementById('modal-title') || {}).innerText || '';
    if (!open || !title.includes('WHATSAPP')) return;

    const input = document.getElementById('whatsapp-reply-input');
    if (input) {
      // Re-render the open conversation without losing what the user is typing.
      const v = input.value, focused = document.activeElement === input, pos = input.selectionStart;
      renderWhatsAppConversation(activeWhatsAppContact);
      const n = document.getElementById('whatsapp-reply-input');
      if (n) {
        n.value = v;
        if (focused) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} }
      }
    } else if (document.getElementById('whatsapp-chat-container')) {
      renderWhatsAppContactsOverview();
    }
  }

  // Native -> JS
  window.__nativeIn = function (json) {
    const m = JSON.parse(json);
    switch (m.type) {
      case 'threads': {
        const t = {};
        Object.keys(m.threads).forEach((c) => { t[c] = m.threads[c].map(toUi); });
        chatThreads = t;
        refreshUi();
        break;
      }
      case 'message':
        if (!chatThreads[m.contact]) chatThreads[m.contact] = [];
        chatThreads[m.contact].push(toUi(m.msg));
        refreshUi();
        break;
      case 'contacts':
        contactsList = Array.from(m.contacts || []).map((c) => ({ id: c.id, name: c.name, phone: c.phone, role: c.role || 'Phone contact' }));
        // Refresh visible contact/dialer views after permission-backed data arrives.
        if (typeof updateDialPadDisplay === 'function') updateDialPadDisplay(false);
        const modalTitle = (document.getElementById('modal-title') || {}).innerText || '';
        if (modalTitle.includes('DIRECTORY')) {
          const closeBtn = document.querySelector('#app-modal [onclick="closeModal()"]');
          if (closeBtn) closeBtn.click();
          if (typeof openModal === 'function') openModal('contacts');
        }
        break;
      case 'contactsPermissionDenied':
        if (typeof showToast === 'function') showToast('Contacts permission was denied');
        break;
      case 'nativeError':
        if (typeof showToast === 'function') showToast(m.message || 'Android action failed');
        break;
      case 'sendResult': {
        const cb = pending[m.id];
        delete pending[m.id];
        if (cb) cb(m.ok, m.error);
        break;
      }
    }
  };

  function nativeSend(contact, text) {
    return new Promise((resolve) => {
      const id = ++seq;
      pending[id] = (ok, err) => resolve({ ok: ok, err: err });
      post({ op: 'sendReply', id: id, contact: contact, text: text });
      setTimeout(() => {
        if (pending[id]) { delete pending[id]; resolve({ ok: false, err: 'Reply timed out' }); }
      }, 8000);
    });
  }

  // Replace the mock senders (also used by the AI agent's "reply to ..." command)
  window.sendWhatsAppMessage = function (contactName, messageText) {
    if (!messageText || !messageText.trim()) return Promise.resolve(false);
    return nativeSend(contactName, messageText.trim()).then((r) => {
      if (!r.ok) showToast('✗ ' + r.err);
      return r.ok;
    });
  };

  window.executeWhatsAppReply = async function () {
    const input = document.getElementById('whatsapp-reply-input');
    if (!input || !input.value.trim()) return;
    const ok = await window.sendWhatsAppMessage(activeWhatsAppContact, input.value.trim());
    if (ok) {
      const i2 = document.getElementById('whatsapp-reply-input');
      if (i2) i2.value = '';
      showToast('✓ Replied via WhatsApp');
    }
  };

  // Ask Android for real device contacts; Android will request permission if needed.
  post({ op: 'getContacts' });
  post({ op: 'sync' });

  // Route normal phone calls through the system dialer (the user confirms the call there).
  window.startWhatsAppCall = function (contactName, role) {
    const c = (contactsList || []).find((x) => x.name === contactName);
    if (!c || !c.phone) {
      if (typeof showToast === 'function') showToast('No phone number found for ' + contactName);
      return;
    }
    post({ op: 'dial', number: c.phone });
  };

  // Browser sites often block iframe embedding. Open URLs/searches in Android's browser instead.
  const originalBrowserSearch = window.executeBrowserSearch;
  window.executeBrowserSearch = function (overrideQuery) {
    const input = document.getElementById('browser-url-input');
    let q = String(overrideQuery || (input ? input.value : '') || '').trim();
    if (!q) q = 'https://www.google.com';
    let url;
    if (/^https?:\/\//i.test(q)) url = q;
    else if (/^[^\s.]+\.[^\s]+$/.test(q)) url = 'https://' + q;
    else url = 'https://www.google.com/search?q=' + encodeURIComponent(q);
    if (input) input.value = q;
    post({ op: 'openUrl', url: url });
    const view = document.getElementById('browser-view-content');
    if (view) view.innerHTML = '<div class="p-3 text-xs font-mono text-gray-700">Opened in your phone browser: <span class="break-all">' + esc(url) + '</span><p class="mt-2">Use Back to return to Retro Launcher.</p></div>';
  };
})();
