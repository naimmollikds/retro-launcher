package com.retrolauncher

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.AlarmClock
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.app.NotificationManagerCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private val origin = "https://appassets.androidplatform.net"
    private lateinit var web: WebView
    private var promptedForAccess = false
    private var waitingForContacts = false
    private val contactsRequestCode = 3017

    private val storeListener: (String, MessageStore.Msg) -> Unit = { contact, msg ->
        runOnUiThread {
            push(JSONObject().put("type", "message").put("contact", contact).put("msg", msg.toJson()))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MessageStore.init(this)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Keep the launcher shell local; third-party pages should open in the real browser
            // rather than failing inside a cross-origin iframe.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame || request.url.toString().startsWith(origin)) return false
                openExternalUrl(request.url.toString())
                return true
            }
        }

        // Secure bridge: only exposed to our own https origin, never to iframes
        // (the launcher's built-in browser embeds third-party sites).
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "nativeBridge", setOf(origin)) { _, message, sourceOrigin, isMainFrame, _ ->
                if (isMainFrame && sourceOrigin.toString() == origin) {
                    message.data?.let { handleMessage(it) }
                }
            }
        } else {
            AlertDialog.Builder(this)
                .setMessage("Please update Android System WebView / Chrome. This launcher needs a newer WebView.")
                .setPositiveButton("OK", null).show()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
            }
        })

        web.loadUrl("$origin/assets/www/index.html")
    }

    override fun onStart() {
        super.onStart()
        MessageStore.addListener(storeListener)
    }

    override fun onStop() {
        MessageStore.removeListener(storeListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (!hasAccess() && !promptedForAccess) {
            promptedForAccess = true
            AlertDialog.Builder(this)
                .setTitle("Allow notification access")
                .setMessage("To show your WhatsApp messages and send replies, enable Notification access for Retro Launcher.\n\nOn Android 13+, if the switch is greyed out: App info → ⋮ menu → \"Allow restricted settings\", then try again.")
                .setPositiveButton("Open settings") { _, _ -> openAccessSettings() }
                .setNegativeButton("Later", null)
                .show()
        }
        if (hasAccess()) promptedForAccess = false
    }

    // Home button pressed while launcher is already showing -> back to home screen
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
    }

    private fun hasAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openAccessSettings() =
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun handleMessage(data: String) {
        try {
            val o = JSONObject(data)
            when (o.getString("op")) {
                "sync" -> push(JSONObject().put("type", "threads")
                    .put("threads", MessageStore.snapshotJson()).put("access", hasAccess()))

                "sendReply" -> {
                    val id = o.getInt("id")
                    val contact = o.getString("contact")
                    val text = o.getString("text")
                    val err = ReplyRegistry.send(this, contact, text)
                    if (err == null) {
                        MessageStore.add(contact, MessageStore.Msg("Me", text, System.currentTimeMillis(), "sent", false))
                    }
                    push(JSONObject().put("type", "sendResult").put("id", id)
                        .put("ok", err == null).put("error", err ?: ""))
                }

                "openAccessSettings" -> openAccessSettings()
                "getContacts" -> loadContactsOrRequestPermission()
                "dial" -> dialNumber(o.optString("number"))
                "openUrl" -> openExternalUrl(o.optString("url"))
                "setAlarm" -> setNextAlarm(o.optInt("hour", -1), o.optInt("minute", -1), o.optString("label", "Retro Launcher alarm"))
            }
        } catch (_: Exception) { /* ignore malformed messages */ }
    }

    private fun loadContactsOrRequestPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            pushContacts()
        } else {
            waitingForContacts = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), contactsRequestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == contactsRequestCode && waitingForContacts) {
            waitingForContacts = false
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) pushContacts()
            else push(JSONObject().put("type", "contactsPermissionDenied"))
        }
    }

    private fun pushContacts() {
        val array = org.json.JSONArray()
        val seen = HashSet<String>()
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { c ->
            val nameCol = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneCol = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val name = c.getString(nameCol)?.trim().orEmpty()
                val phone = c.getString(phoneCol)?.trim().orEmpty()
                if (name.isNotEmpty() && phone.isNotEmpty() && seen.add(name + "|" + phone)) {
                    array.put(JSONObject().put("id", array.length() + 1).put("name", name).put("phone", phone).put("role", "Phone contact"))
                }
            }
        }
        push(JSONObject().put("type", "contacts").put("contacts", array))
    }

    private fun dialNumber(raw: String) {
        val number = raw.trim()
        if (number.isEmpty()) return
        try { startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))) }
        catch (_: Exception) { push(JSONObject().put("type", "nativeError").put("message", "No dialer app is available")) }
    }

    private fun openExternalUrl(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = if (value.matches(Regex("(?i)^https?://.*"))) value else "https://$value"
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { push(JSONObject().put("type", "nativeError").put("message", "No browser app can open this URL")) }
    }

    private fun setNextAlarm(hour: Int, minute: Int, label: String) {
        if (hour !in 0..23 || minute !in 0..59) return
        try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            startActivity(intent)
        } catch (_: Exception) {
            push(JSONObject().put("type", "nativeError").put("message", "No clock app can set alarms"))
        }
    }

    private fun push(payload: JSONObject) {
        val js = "window.__nativeIn && window.__nativeIn(${JSONObject.quote(payload.toString())});"
        web.evaluateJavascript(js, null)
    }
}
