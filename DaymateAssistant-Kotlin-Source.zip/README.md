# Daymate — Android personal assistant starter

A Kotlin + Jetpack Compose Android project with offline-first meal and expense tracking.

## Included now
- Monthly meal allowance defaults to ৳3,500 and 60 meals.
- Per-meal allocation is calculated automatically: ৳3,500 / 60 = ৳58.33 (rounded for display).
- Add lunch or dinner entries; monthly used and remaining meal counts update automatically.
- Add and remove expenses with categories and BDT amounts.
- Monthly overview combines meal allocation and recorded expenses.
- Settings allow changing the monthly budget and meal allowance.
- Data is stored locally using Android SharedPreferences; no account or API key is required.

## Build from GitHub / terminal
1. Install Android Studio and a JDK 17.
2. Create a GitHub repository and upload this project, or push this folder:
   ```bash
   git init
   git add .
   git commit -m "Initial Daymate app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. In Android Studio, open the repository folder and let Gradle sync.
4. Build an APK:
   ```bash
   ./gradlew assembleDebug
   ```
   On Windows PowerShell:
   ```powershell
   .\gradlew.bat assembleDebug
   ```
   The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Important scope notes
This is a working starter for the meal and expense ledger, not a finished autonomous device-control product. Voice/AI, WhatsApp/calling, Windows control, smart wake detection, cloud sync, and scheduled background automation are not enabled. They require separate Android permissions, platform-specific Windows software, secure backend/API integration, and careful user confirmation for sensitive actions. The app deliberately does not silently place calls, send messages, monitor microphone audio, or control other apps.

## Meal calculation
- Monthly budget: ৳3,500
- Monthly allowance: 60 meals
- Cost allocation per meal: ৳58.3333...
- Displayed per-meal value: ৳58.33
- Daily target: 2 meals (lunch + dinner)
- The app counts logged meals; it does not assume a meal was eaten unless you add it.
