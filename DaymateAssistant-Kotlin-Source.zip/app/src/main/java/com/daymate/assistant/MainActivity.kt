package com.daymate.assistant

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.UUID

data class Meal(val id:String, val date:String, val type:String)
data class Expense(val id:String, val date:String, val title:String, val category:String, val amount:Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { DaymateApp(this) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DaymateApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("daymate", Context.MODE_PRIVATE) }
    var budget by remember { mutableDoubleStateOf(prefs.getString("budget","3500")?.toDoubleOrNull() ?: 3500.0) }
    var mealLimit by remember { mutableIntStateOf(prefs.getInt("mealLimit",60)) }
    var meals by remember { mutableStateOf(loadMeals(prefs)) }
    var expenses by remember { mutableStateOf(loadExpenses(prefs)) }
    var tab by remember { mutableIntStateOf(0) }
    var showMeal by remember { mutableStateOf(false) }
    var showExpense by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val month = YearMonth.now().toString()
    val monthMeals = meals.filter { it.date.startsWith(month) }
    val monthExpenses = expenses.filter { it.date.startsWith(month) }
    val perMeal = if (mealLimit > 0) budget / mealLimit else 0.0
    val mealSpend = monthMeals.size * perMeal
    val expenseSpend = monthExpenses.sumOf { it.amount }
    val remaining = (mealLimit - monthMeals.size).coerceAtLeast(0)
    val moneyLeft = budget - mealSpend - expenseSpend
    fun persist() {
        prefs.edit().putString("meals", JSONArray().apply { meals.forEach { put(JSONObject().put("id",it.id).put("date",it.date).put("type",it.type)) } }.toString())
            .putString("expenses", JSONArray().apply { expenses.forEach { put(JSONObject().put("id",it.id).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount)) } }.toString()).apply()
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Daymate", fontWeight=FontWeight.Bold) }, actions = {
            IconButton(onClick={showSettings=true}) { Icon(Icons.Default.Settings, "Settings") }
        }) },
        floatingActionButton = {
            if (tab==1 || tab==2) FloatingActionButton(onClick={ if(tab==1) showMeal=true else showExpense=true }) {
                Icon(Icons.Default.Add, "Add")
            }
        },
        bottomBar = {
            NavigationBar {
                listOf("Home","Meals","Expenses","Assistant").forEachIndexed { i, label ->
                    NavigationBarItem(selected=tab==i, onClick={tab=i},
                        icon={ Icon(listOf(Icons.Default.Home,Icons.Default.Restaurant,Icons.Default.AccountBalanceWallet,Icons.Default.AutoAwesome)[i], label) },
                        label={Text(label)})
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when(tab) {
                0 -> HomeScreen(budget, mealLimit, monthMeals.size, remaining, perMeal, mealSpend, expenseSpend, moneyLeft)
                1 -> MealsScreen(monthMeals, perMeal, onDelete={ id -> meals=meals.filterNot{it.id==id}; persist() })
                2 -> ExpensesScreen(monthExpenses, expenseSpend, onDelete={ id -> expenses=expenses.filterNot{it.id==id}; persist() })
                else -> AssistantScreen()
            }
        }
    }
    if(showMeal) MealDialog(onDismiss={showMeal=false}, onSave={ type ->
        meals = meals + Meal(UUID.randomUUID().toString(), LocalDate.now().toString(), type)
        persist(); showMeal=false
    })
    if(showExpense) ExpenseDialog(onDismiss={showExpense=false}, onSave={ title,cat,amount ->
        expenses = expenses + Expense(UUID.randomUUID().toString(),LocalDate.now().toString(),title,cat,amount)
        persist(); showExpense=false
    })
    if(showSettings) SettingsDialog(budget,mealLimit,{b,l ->
        budget=b; mealLimit=l
        prefs.edit().putString("budget",b.toString()).putInt("mealLimit",l).apply()
        showSettings=false
    },{showSettings=false})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun HomeScreen(budget:Double, limit:Int, count:Int, remaining:Int, unit:Double, mealSpend:Double, expenseSpend:Double, left:Double) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMM d")), style=MaterialTheme.typography.titleMedium)
        Text("Monthly overview", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            MetricCard("Meal allowance", "৳${money(budget)}", Modifier.weight(1f))
            MetricCard("Cost per meal", "৳${money(unit)}", Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            MetricCard("Meals used", "$count / $limit", Modifier.weight(1f))
            MetricCard("Meals left", "$remaining", Modifier.weight(1f))
        }
        Card(shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Budget status", fontWeight=FontWeight.Bold)
                Text("Meal allocation: ৳${money(mealSpend)}")
                Text("Other expenses: ৳${money(expenseSpend)}")
                HorizontalProgress(count.toFloat(), limit.coerceAtLeast(1).toFloat())
                Text(if(left>=0) "Estimated remaining: ৳${money(left)}" else "Over budget by: ৳${money(-left)}",
                    color=if(left>=0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    fontWeight=FontWeight.Bold)
                Text("This estimate subtracts meal value and recorded expenses from the monthly allowance.",
                    style=MaterialTheme.typography.bodySmall)
            }
        }
        Card { Column(Modifier.padding(16.dp)) {
            Text("Daily meal plan", fontWeight=FontWeight.Bold)
            Text("Target: 2 meals per day — lunch and dinner")
            Text("Monthly plan: $limit meals")
        } }
        Text("Tip: add each lunch or dinner in the Meals tab. Add transport, snacks, groceries, or any other spending in Expenses.")
    }
}
@Composable fun HorizontalProgress(value:Float,max:Float) {
    LinearProgressIndicator(progress={ (value/max).coerceIn(0f,1f) }, modifier=Modifier.fillMaxWidth())
}
@Composable fun MetricCard(label:String,value:String,modifier:Modifier=Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
        Text(label, style=MaterialTheme.typography.bodySmall)
        Text(value, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
    } }
}
@Composable fun MealsScreen(items:List<Meal>, unit:Double, onDelete:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Meal log", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("Each logged meal is valued at ৳${money(unit)}.")
        Spacer(Modifier.height(8.dp))
        if(items.isEmpty()) Text("No meals logged this month yet.")
        LazyColumn { items(items.reversed(), key={it.id}) { meal ->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Restaurant, null)
                    Column(Modifier.weight(1f).padding(start=10.dp)) {
                        Text(meal.type, fontWeight=FontWeight.SemiBold)
                        Text(meal.date, style=MaterialTheme.typography.bodySmall)
                    }
                    Text("৳${money(unit)}")
                    IconButton(onClick={onDelete(meal.id)}) { Icon(Icons.Default.Delete,"Remove meal") }
                }
            }
        } }
    }
}
@Composable fun ExpensesScreen(items:List<Expense>, total:Double, onDelete:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Money tracking", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("Recorded this month: ৳${money(total)}")
        Spacer(Modifier.height(8.dp))
        if(items.isEmpty()) Text("No expenses recorded this month.")
        LazyColumn { items(items.reversed(), key={it.id}) { e ->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.title, fontWeight=FontWeight.SemiBold)
                        Text("${e.category} • ${e.date}", style=MaterialTheme.typography.bodySmall)
                    }
                    Text("৳${money(e.amount)}")
                    IconButton(onClick={onDelete(e.id)}) { Icon(Icons.Default.Delete,"Remove expense") }
                }
            }
        } }
    }
}
@Composable fun AssistantScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Personal assistant", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("This starter keeps your finance and meal tracking fully local and offline.")
        Card { Column(Modifier.padding(16.dp)) {
            Text("Planned integrations", fontWeight=FontWeight.Bold)
            Text("• Voice and text assistant")
            Text("• Structured, allowlisted device commands")
            Text("• Smart wake / alarm routines")
            Text("• Windows 11 companion")
            Text("• Optional AI provider connection")
        } }
        Text("AI/API integration is intentionally not enabled yet. Add a provider and secure backend before sending personal data to an external service.")
    }
}
@Composable fun MealDialog(onDismiss:()->Unit,onSave:(String)->Unit) {
    var type by remember { mutableStateOf("Lunch") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Add meal")},
        text={ Column { Text("Choose meal type"); Row(verticalAlignment=Alignment.CenterVertically) {
            RadioButton(type=="Lunch",{type="Lunch"}); Text("Lunch")
            Spacer(Modifier.width(12.dp)); RadioButton(type=="Dinner",{type="Dinner"}); Text("Dinner")
        } } },
        confirmButton={TextButton(onClick={onSave(type)}){Text("Add meal")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable fun ExpenseDialog(onDismiss:()->Unit,onSave:(String,String,Double)->Unit) {
    var title by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Other") }; var amount by remember { mutableStateOf("") }
    val categories=listOf("Transport","Snacks","Groceries","Mobile/Data","Study","Personal","Other")
    AlertDialog(onDismissRequest=onDismiss, title={Text("Add expense")},
        text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title,{title=it},label={Text("Expense name")},singleLine=true)
            OutlinedTextField(amount,{amount=it},label={Text("Amount (BDT)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
            Text("Category")
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                categories.take(4).forEach { FilterChip(selected=category==it,onClick={category=it},label={Text(it)}) }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                categories.drop(4).forEach { FilterChip(selected=category==it,onClick={category=it},label={Text(it)}) }
            }
        } },
        confirmButton={TextButton(enabled=title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0)>0,onClick={onSave(title.trim(),category,amount.toDouble())}){Text("Save")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable fun SettingsDialog(budget:Double,limit:Int,onSave:(Double,Int)->Unit,onDismiss:()->Unit) {
    var b by remember { mutableStateOf(budget.toString()) }; var l by remember { mutableStateOf(limit.toString()) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Monthly settings")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(b,{b=it},label={Text("Monthly meal budget (BDT)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedTextField(l,{l=it},label={Text("Monthly meal allowance")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
            Text("Default: ৳3,500 for 60 meals = ৳58.33 per meal.",style=MaterialTheme.typography.bodySmall)
        }},
        confirmButton={TextButton(enabled=(b.toDoubleOrNull() ?: 0.0)>0 && (l.toIntOrNull() ?: 0)>0,onClick={onSave(b.toDouble(),l.toInt())}){Text("Save")}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
fun money(v:Double)=String.format(java.util.Locale.US,"%.2f",v)
fun loadMeals(prefs:android.content.SharedPreferences):List<Meal> = try {
    val a=JSONArray(prefs.getString("meals","[]"))
    (0 until a.length()).map { val o=a.getJSONObject(it); Meal(o.getString("id"),o.getString("date"),o.getString("type")) }
} catch(_:Exception){ emptyList() }
fun loadExpenses(prefs:android.content.SharedPreferences):List<Expense> = try {
    val a=JSONArray(prefs.getString("expenses","[]"))
    (0 until a.length()).map { val o=a.getJSONObject(it); Expense(o.getString("id"),o.getString("date"),o.getString("title"),o.getString("category"),o.getDouble("amount")) }
} catch(_:Exception){ emptyList() }
