package com.retrolauncher

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

class WhatsAppListenerService : NotificationListenerService() {

    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val urgentRegex =
        Regex("\\b(urgent|asap|important|deadline|notice|emergency|immediately)\\b", RegexOption.IGNORE_CASE)
    private val BAD_CHARS = "\\'\"`<>&\${}"
    private val countSuffix = Regex("\\s*\\(\\d+ messages?\\)$")

    override fun onCreate() {
        super.onCreate()
        MessageStore.init(this)
    }

    override fun onListenerConnected() {
        // Rebuild reply handles and pick up anything posted while we were disconnected.
        try { activeNotifications?.forEach { handle(it) } } catch (_: Exception) {}
    }

    override fun onListenerDisconnected() {
        requestRebind(ComponentName(this, WhatsAppListenerService::class.java))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn)

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName !in packages) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        if (style == null && n.category != Notification.CATEGORY_MESSAGE) return

        val extras = n.extras
        val rawTitle = style?.conversationTitle
            ?: extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)
            ?: return
        val title = sanitizeKey(rawTitle.toString().replace(countSuffix, ""))
        if (title.isEmpty() || title.equals("WhatsApp", ignoreCase = true)) return

        findReply(n)?.let { (pi, inputs) -> ReplyRegistry.put(title, pi, inputs) }

        val msgs = style?.messages
        if (msgs.isNullOrEmpty()) {
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
            store(title, title, text, sbn.postTime)
        } else {
            for (m in msgs) {
                val sender = m.person?.name?.toString() ?: continue      // null person = my own message
                if (sender.equals("You", true) || sender.equals("Me", true)) continue
                val text = m.text?.toString() ?: continue
                store(title, sender, text, if (m.timestamp > 0) m.timestamp else sbn.postTime)
            }
        }
    }

    /**
     * Contact/group names end up inside inline onclick="fn('NAME')" handlers in the UI,
     * so strip anything that could break out of a JS string or HTML attribute.
     */
    private fun sanitizeKey(raw: String): String =
        raw.filter { it !in BAD_CHARS && !it.isISOControl() }.trim().take(40)

    private fun store(contact: String, sender: String, text: String, time: Long) {
        MessageStore.add(contact, MessageStore.Msg(sender, text, time, "received", urgentRegex.containsMatchIn(text)))
    }

    private fun findReply(n: Notification): Pair<android.app.PendingIntent, Array<androidx.core.app.RemoteInput>>? {
        for (i in 0 until NotificationCompat.getActionCount(n)) {
            val a = NotificationCompat.getAction(n, i) ?: continue
            val ri = a.remoteInputs
            val pi = a.actionIntent
            if (!ri.isNullOrEmpty() && pi != null) return pi to ri
        }
        // Older WhatsApp versions expose Reply through the Wearable extender
        for (a in NotificationCompat.WearableExtender(n).actions) {
            val ri = a.remoteInputs
            val pi = a.actionIntent
            if (!ri.isNullOrEmpty() && pi != null) return pi to ri
        }
        return null
    }
}
