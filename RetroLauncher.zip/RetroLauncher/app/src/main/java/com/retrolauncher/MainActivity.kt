package com.retrolauncher

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.app.NotificationManagerCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private val origin = "https://appassets.androidplatform.net"
    private lateinit var web: WebView
    private var promptedForAccess = false

    private val storeListener: (String, MessageStore.Msg) -> Unit = { contact, msg ->
        runOnUiThread {
            push(JSONObject().put("type", "message").put("contact", contact).put("msg", msg.toJson()))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MessageStore.init(this)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            // Never let the top-level page navigate away from our bundled UI.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.isForMainFrame && !request.url.toString().startsWith(origin)
        }

        // Secure bridge: only exposed to our own https origin, never to iframes
        // (the launcher's built-in browser embeds third-party sites).
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "nativeBridge", setOf(origin)) { _, message, sourceOrigin, isMainFrame, _ ->
                if (isMainFrame && sourceOrigin.toString() == origin) {
                    message.data?.let { handleMessage(it) }
                }
            }
        } else {
            AlertDialog.Builder(this)
                .setMessage("Please update Android System WebView / Chrome. This launcher needs a newer WebView.")
                .setPositiveButton("OK", null).show()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
            }
        })

        web.loadUrl("$origin/assets/www/index.html")
    }

    override fun onStart() {
        super.onStart()
        MessageStore.addListener(storeListener)
    }

    override fun onStop() {
        MessageStore.removeListener(storeListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (!hasAccess() && !promptedForAccess) {
            promptedForAccess = true
            AlertDialog.Builder(this)
                .setTitle("Allow notification access")
                .setMessage("To show your WhatsApp messages and send replies, enable Notification access for Retro Launcher.\n\nOn Android 13+, if the switch is greyed out: App info → ⋮ menu → \"Allow restricted settings\", then try again.")
                .setPositiveButton("Open settings") { _, _ -> openAccessSettings() }
                .setNegativeButton("Later", null)
                .show()
        }
        if (hasAccess()) promptedForAccess = false
    }

    // Home button pressed while launcher is already showing -> back to home screen
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        web.evaluateJavascript("if(typeof closeModal==='function')closeModal();", null)
    }

    private fun hasAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openAccessSettings() =
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    private fun handleMessage(data: String) {
        try {
            val o = JSONObject(data)
            when (o.getString("op")) {
                "sync" -> push(JSONObject().put("type", "threads")
                    .put("threads", MessageStore.snapshotJson()).put("access", hasAccess()))

                "sendReply" -> {
                    val id = o.getInt("id")
                    val contact = o.getString("contact")
                    val text = o.getString("text")
                    val err = ReplyRegistry.send(this, contact, text)
                    if (err == null) {
                        MessageStore.add(contact, MessageStore.Msg("Me", text, System.currentTimeMillis(), "sent", false))
                    }
                    push(JSONObject().put("type", "sendResult").put("id", id)
                        .put("ok", err == null).put("error", err ?: ""))
                }

                "openAccessSettings" -> openAccessSettings()
            }
        } catch (_: Exception) { /* ignore malformed messages */ }
    }

    private fun push(payload: JSONObject) {
        val js = "window.__nativeIn && window.__nativeIn(${JSONObject.quote(payload.toString())});"
        web.evaluateJavascript(js, null)
    }
}
