# Retro Launcher (Android)

Your `v1.html` UI, wrapped in a WebView launcher, with real WhatsApp notifications
and notification-based quick replies.

## Build
1. Install Android Studio (Koala or newer). File → Open → this folder. Let Gradle sync
   (it generates the Gradle wrapper for you).
2. Plug in your phone (USB debugging on) → Run ▶, or Build → Build APK(s) and sideload.

## First-run setup on the phone
1. **Notification access**: the app prompts you. On Android 13+ the switch may be greyed out
   for sideloaded apps: Settings → Apps → Retro Launcher → ⋮ → *Allow restricted settings*,
   then enable it in Notification access.
2. **Default home app**: press Home → choose Retro Launcher → Always.
   (Or Settings → Apps → Default apps → Home app.)
3. **Battery**: set Retro Launcher to *Unrestricted* so the system doesn't kill the listener.

## Layout
- `assets/www/index.html`  your original file + one `<script src="bridge.js">` line
- `assets/www/bridge.js`   swaps mock data for native data, routes replies
- `WhatsAppListenerService.kt`  reads WhatsApp (com.whatsapp / w4b) notifications
- `ReplyRegistry.kt`       keeps each chat's Reply action (PendingIntent + RemoteInput)
- `MessageStore.kt`        conversation storage (app-private SharedPreferences)
- `MainActivity.kt`        HOME activity, WebView, secure JS bridge

## How replies work
WhatsApp attaches a "Reply" action to each message notification. The listener caches it per
chat; when you send from the UI, the app fills the RemoteInput with your text and fires it.
So a reply is only possible while WhatsApp still has a notification for that chat.

## Known limits
- Only messages that arrive after install (no history import). Media shows as WhatsApp's
  placeholder text ("📷 Photo").
- Muted chats / DND may not produce notifications -> won't appear.
- If you open the chat in WhatsApp (or dismiss the notification), the Reply action can
  disappear; you can reply again after the next incoming message.
- Still mock in the UI: contacts, calls, apps list, battery/signal, calc is local JS.
- UI loads Tailwind/FontAwesome/Google Fonts from CDNs, so it needs internet on first
  load. For fully offline use, download those files into `assets/www/` and change the tags.
- Messages are stored unencrypted in app-private storage. `allowBackup` is off.
